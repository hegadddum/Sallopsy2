import React from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function RevenueChart({ appointments }) {
  // Group completed appointments by date for last 7 days
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split("T")[0];
    const dayAppts = appointments.filter(
      (a) => a.date === dateStr && a.status === "voltooid"
    );
    const revenue = dayAppts.reduce((sum, a) => sum + (a.price || 0), 0);
    last7Days.push({
      dag: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"][d.getDay()],
      omzet: revenue,
    });
  }

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded-xl px-4 py-3 shadow-lg">
          <p className="text-sm font-semibold text-foreground">€{payload[0].value.toFixed(2)}</p>
          <p className="text-xs text-muted-foreground">{payload[0].payload.dag}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-card rounded-2xl border border-border/50 p-6">
      <h3 className="text-lg font-semibold text-foreground mb-1">Omzet deze week</h3>
      <p className="text-sm text-muted-foreground mb-6">Afgeronde afspraken</p>
      <ResponsiveContainer width="100%" height={220}>
        <AreaChart data={last7Days}>
          <defs>
            <linearGradient id="omzetGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(230, 65%, 28%)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="hsl(230, 65%, 28%)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(220, 15%, 90%)" />
          <XAxis dataKey="dag" tick={{ fontSize: 12 }} stroke="hsl(220, 10%, 46%)" />
          <YAxis tick={{ fontSize: 12 }} stroke="hsl(220, 10%, 46%)" tickFormatter={(v) => `€${v}`} />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="omzet"
            stroke="hsl(230, 65%, 28%)"
            strokeWidth={2.5}
            fill="url(#omzetGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}