import React from "react";
import { cn } from "@/lib/utils";

export default function StatsCard({ icon: Icon, label, value, change, gradient }) {
  return (
    <div className="bg-card rounded-2xl border border-border/50 p-6 hover:shadow-lg hover:shadow-black/5 transition-all duration-300">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{label}</p>
          <p className="text-3xl font-bold text-foreground mt-2">{value}</p>
          {change && (
            <p className={cn(
              "text-sm font-medium mt-2",
              change.startsWith("+") ? "text-emerald-500" : "text-destructive"
            )}>
              {change} vs vorige maand
            </p>
          )}
        </div>
        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-br", gradient)}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );
}