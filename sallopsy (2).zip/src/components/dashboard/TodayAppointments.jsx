import React from "react";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, User, ArrowRight } from "lucide-react";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

const statusColors = {
  gepland: "bg-blue-100 text-blue-700",
  bevestigd: "bg-emerald-100 text-emerald-700",
  voltooid: "bg-muted text-muted-foreground",
  geannuleerd: "bg-red-100 text-red-700",
  no_show: "bg-amber-100 text-amber-700",
};

export default function TodayAppointments({ appointments, isLoading }) {
  const today = format(new Date(), "yyyy-MM-dd");
  const todayAppointments = appointments
    .filter((a) => a.date === today)
    .sort((a, b) => (a.time || "").localeCompare(b.time || ""));

  if (isLoading) {
    return (
      <div className="bg-card rounded-2xl border border-border/50 p-6">
        <div className="h-6 w-40 bg-muted rounded animate-pulse mb-6" />
        {[1, 2, 3].map((i) => (
          <div key={i} className="flex items-center gap-4 py-4 border-b border-border/30 last:border-0">
            <div className="w-12 h-12 bg-muted rounded-xl animate-pulse" />
            <div className="flex-1 space-y-2">
              <div className="h-4 w-32 bg-muted rounded animate-pulse" />
              <div className="h-3 w-24 bg-muted rounded animate-pulse" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="bg-card rounded-2xl border border-border/50 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Afspraken vandaag</h3>
          <p className="text-sm text-muted-foreground">
            {format(new Date(), "EEEE d MMMM", { locale: nl })}
          </p>
        </div>
        <Link to="/appointments">
          <Button variant="ghost" size="sm" className="text-primary">
            Alles bekijken <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </Link>
      </div>

      {todayAppointments.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-sm text-muted-foreground">Geen afspraken vandaag</p>
        </div>
      ) : (
        <div className="space-y-1">
          {todayAppointments.map((appt) => (
            <div key={appt.id} className="flex items-center gap-4 p-3 rounded-xl hover:bg-secondary/50 transition-colors">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Clock className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-semibold text-foreground truncate">{appt.client_name}</p>
                  <Badge className={`text-xs ${statusColors[appt.status] || "bg-muted text-muted-foreground"}`}>
                    {appt.status}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {appt.time} — {appt.service_name} {appt.duration ? `(${appt.duration} min)` : ""}
                </p>
              </div>
              <p className="text-sm font-semibold text-foreground">
                {appt.price ? `€${appt.price}` : ""}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}