import React, { useMemo } from "react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { nl } from "date-fns/locale";
import { TrendingUp, TrendingDown } from "lucide-react";

const COLORS = ["hsl(230,65%,28%)", "hsl(38,92%,50%)", "hsl(160,60%,45%)", "hsl(280,65%,60%)", "hsl(340,75%,55%)"];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload?.length) {
    return (
      <div className="bg-card border border-border rounded-xl px-4 py-3 shadow-lg text-sm">
        <p className="font-semibold text-foreground">{label}</p>
        {payload.map((p, i) => (
          <p key={i} style={{ color: p.color }} className="mt-1">
            {p.name}: <span className="font-bold">€{Number(p.value).toFixed(0)}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

export default function RevenueStats({ appointments }) {
  const { monthlyData, categoryData, trend } = useMemo(() => {
    // Last 6 months revenue
    const monthly = [];
    for (let i = 5; i >= 0; i--) {
      const d = subMonths(new Date(), i);
      const monthStr = format(d, "yyyy-MM");
      const monthAppts = appointments.filter(
        (a) => a.date?.startsWith(monthStr) && a.status === "voltooid"
      );
      monthly.push({
        maand: format(d, "MMM", { locale: nl }),
        omzet: monthAppts.reduce((s, a) => s + (a.price || 0), 0),
        afspraken: monthAppts.length,
      });
    }

    // Revenue by service category
    const catMap = {};
    appointments
      .filter((a) => a.status === "voltooid")
      .forEach((a) => {
        const key = a.service_name || "Overig";
        catMap[key] = (catMap[key] || 0) + (a.price || 0);
      });
    const cats = Object.entries(catMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, value }));

    // Trend: compare current vs previous month
    const thisM = format(new Date(), "yyyy-MM");
    const prevM = format(subMonths(new Date(), 1), "yyyy-MM");
    const thisRev = appointments
      .filter((a) => a.date?.startsWith(thisM) && a.status === "voltooid")
      .reduce((s, a) => s + (a.price || 0), 0);
    const prevRev = appointments
      .filter((a) => a.date?.startsWith(prevM) && a.status === "voltooid")
      .reduce((s, a) => s + (a.price || 0), 0);
    const pct = prevRev > 0 ? ((thisRev - prevRev) / prevRev) * 100 : 0;

    return { monthlyData: monthly, categoryData: cats, trend: pct };
  }, [appointments]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Monthly trend */}
      <div className="lg:col-span-2 bg-card rounded-2xl border border-border/50 p-6">
        <div className="flex items-start justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Omzet per maand</h3>
            <p className="text-sm text-muted-foreground">Afgelopen 6 maanden</p>
          </div>
          <div className={`flex items-center gap-1.5 text-sm font-semibold px-3 py-1.5 rounded-xl ${
            trend >= 0 ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"
          }`}>
            {trend >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
            {Math.abs(trend).toFixed(1)}% vs vorige maand
          </div>
        </div>
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={monthlyData}>
            <defs>
              <linearGradient id="grad1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(230,65%,28%)" stopOpacity={0.25} />
                <stop offset="95%" stopColor="hsl(230,65%,28%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
            <XAxis dataKey="maand" tick={{ fontSize: 12 }} stroke="hsl(220,10%,60%)" />
            <YAxis tick={{ fontSize: 12 }} stroke="hsl(220,10%,60%)" tickFormatter={(v) => `€${v}`} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="omzet" name="Omzet" stroke="hsl(230,65%,28%)" strokeWidth={2.5} fill="url(#grad1)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* By service */}
      <div className="bg-card rounded-2xl border border-border/50 p-6">
        <h3 className="text-lg font-semibold text-foreground mb-1">Omzet per dienst</h3>
        <p className="text-sm text-muted-foreground mb-4">Top diensten</p>
        {categoryData.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Geen data beschikbaar</p>
        ) : (
          <>
            <ResponsiveContainer width="100%" height={180}>
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="value" paddingAngle={3}>
                  {categoryData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v) => `€${v.toFixed(0)}`} />
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2 mt-3">
              {categoryData.map((d, i) => (
                <div key={d.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-full" style={{ background: COLORS[i % COLORS.length] }} />
                    <span className="text-muted-foreground truncate max-w-[100px]">{d.name}</span>
                  </div>
                  <span className="font-semibold text-foreground">€{d.value.toFixed(0)}</span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Appointments bar chart */}
      <div className="lg:col-span-3 bg-card rounded-2xl border border-border/50 p-6">
        <h3 className="text-lg font-semibold text-foreground mb-1">Aantal afspraken per maand</h3>
        <p className="text-sm text-muted-foreground mb-6">Afgelopen 6 maanden</p>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={monthlyData} barSize={32}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
            <XAxis dataKey="maand" tick={{ fontSize: 12 }} stroke="hsl(220,10%,60%)" />
            <YAxis tick={{ fontSize: 12 }} stroke="hsl(220,10%,60%)" allowDecimals={false} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="afspraken" name="Afspraken" fill="hsl(38,92%,50%)" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}