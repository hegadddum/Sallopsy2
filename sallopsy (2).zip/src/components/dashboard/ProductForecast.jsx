import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingBag, Zap, AlertTriangle, Loader2, Check } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function ProductForecast() {
  const [forecast, setForecast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchForecast = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('productForecasting', {});
      if (res.data.productForecast) {
        setForecast(res.data.productForecast);
      } else {
        setError(res.data.message);
      }
    } catch (err) {
      setError('Kon prognose niet laden');
    }
    setLoading(false);
  };

  if (!forecast && !loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Productanalyse</h3>
            <p className="text-sm text-muted-foreground">AI-voorspelling voor webshop en voorraadbeheer</p>
          </div>
          <ShoppingBag className="w-6 h-6 text-accent" />
        </div>
        <Button onClick={fetchForecast} className="w-full" variant="outline">
          <Zap className="w-4 h-4 mr-2" />
          Analyseer producten
        </Button>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-accent animate-spin" />
          <span className="ml-3 text-muted-foreground">Data aan het analyseren...</span>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6 border-border/50 border-red-500/30 bg-red-500/5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-700">{error}</h3>
            <Button onClick={fetchForecast} variant="ghost" size="sm" className="mt-2">
              Opnieuw proberen
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const demandColors = {
    'Laag': 'bg-secondary text-secondary-foreground',
    'Gemiddeld': 'bg-amber-500/10 text-amber-700',
    'Hoog': 'bg-emerald-500/10 text-emerald-700'
  };

  return (
    <Card className="p-6 border-border/50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Productanalyse & Voorraad</h3>
          <p className="text-sm text-muted-foreground">Gebaseerd op afspraken en trends</p>
        </div>
        <Button onClick={fetchForecast} size="sm" variant="ghost">
          Vernieuwen
        </Button>
      </div>

      <div className="mb-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Verwachte vraag</p>
            <p className="text-2xl font-bold text-accent mt-1">{forecast.demandRating}</p>
          </div>
          <ShoppingBag className="w-8 h-8 text-accent opacity-50" />
        </div>
      </div>

      <div className="space-y-6">
        {/* Top Products */}
        {forecast.topProducts.length > 0 && (
          <div>
            <h4 className="font-semibold text-foreground text-sm mb-3">Top 5 Producten (Groeiende Vraag)</h4>
            <ul className="space-y-2">
              {forecast.topProducts.map((product, i) => (
                <li key={i} className="flex items-center gap-3 p-3 bg-secondary/50 rounded-lg">
                  <Check className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                  <span className="text-sm text-foreground">{product}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Low Stock Warnings */}
        {forecast.lowStockWarnings.length > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-4">
            <h4 className="font-semibold text-amber-700 text-sm mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Lage Voorraden - Let Op!
            </h4>
            <ul className="space-y-2">
              {forecast.lowStockWarnings.map((warn, i) => (
                <li key={i} className="text-sm text-amber-700 flex items-start gap-2">
                  <span>•</span>
                  <span>{warn}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Recommended New Products */}
        {forecast.recommendedNewProducts.length > 0 && (
          <div>
            <h4 className="font-semibold text-foreground text-sm mb-3">Aanbevolen Nieuwe Producten</h4>
            <ul className="space-y-2">
              {forecast.recommendedNewProducts.map((product, i) => (
                <li key={i} className="flex items-center gap-3 p-3 bg-blue-500/10 rounded-lg border border-blue-500/20">
                  <Badge variant="outline" className="text-blue-700">Nieuw</Badge>
                  <span className="text-sm text-foreground">{product}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Webshop Focus */}
        {forecast.webshopFocus.length > 0 && (
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <h4 className="font-semibold text-primary text-sm mb-3">Webshop Marketing Focus</h4>
            <ul className="space-y-2">
              {forecast.webshopFocus.map((rec, i) => (
                <li key={i} className="text-sm text-primary flex items-start gap-2">
                  <span>→</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </Card>
  );
}