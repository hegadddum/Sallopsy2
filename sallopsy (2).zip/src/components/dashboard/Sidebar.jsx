import React from "react";
import { Link, useLocation } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import {
  LayoutDashboard, Calendar, Users, ShoppingBag,
  Settings, LogOut, Scissors, ChevronLeft, ChevronRight, Package, Gift, BarChart2, Home,
  UserCheck, Euro, ExternalLink
} from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", path: "/dashboard" },
  { icon: Calendar, label: "Afspraken", path: "/appointments" },
  { icon: Euro, label: "Kassa", path: "/checkout" },
  { icon: Users, label: "Klanten", path: "/clients" },
  { icon: UserCheck, label: "Medewerkers", path: "/staff" },
  { icon: ShoppingBag, label: "Diensten", path: "/services" },
  { icon: Package, label: "Voorraad", path: "/inventory" },
  { icon: Gift, label: "Loyaliteit", path: "/loyalty" },
  { icon: BarChart2, label: "Marketing", path: "/marketing" },
  { icon: Settings, label: "Instellingen", path: "/settings" },
];

export default function Sidebar({ collapsed, onToggle }) {
  const location = useLocation();

  const handleLogout = () => {
    base44.auth.logout("/");
  };

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 h-screen bg-sidebar border-r border-sidebar-border flex flex-col z-40 transition-all duration-300",
        collapsed ? "w-20" : "w-64"
      )}
    >
      {/* Logo */}
      <div className="h-20 flex items-center px-5 border-b border-sidebar-border">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-sidebar-primary flex items-center justify-center flex-shrink-0">
            <Scissors className="w-5 h-5 text-sidebar-primary-foreground" />
          </div>
          {!collapsed && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="overflow-hidden">
              <span className="font-display text-lg font-bold text-sidebar-foreground">Sallopsy</span>
              <p className="text-[10px] text-sidebar-foreground/50 tracking-wider">SALON OPERATING SYSTEM</p>
            </motion.div>
          )}
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-6 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium transition-all duration-200",
                active
                  ? "bg-sidebar-accent text-sidebar-primary"
                  : "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              <item.icon className={cn("w-5 h-5 flex-shrink-0", active && "text-sidebar-primary")} />
              {!collapsed && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="p-3 border-t border-sidebar-border space-y-1">
        <Link
          to="/boeken"
          target="_blank"
          className="flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-sidebar-foreground/50 hover:text-sidebar-primary hover:bg-sidebar-accent/50 transition-all w-full"
        >
          <ExternalLink className="w-5 h-5" />
          {!collapsed && <span>Boekingspagina</span>}
        </Link>
        <Link
          to="/"
          className="flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent/50 transition-all w-full"
        >
          <Home className="w-5 h-5" />
          {!collapsed && <span>Home</span>}
        </Link>
        <button
          onClick={onToggle}
          className="flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-sidebar-foreground/50 hover:text-sidebar-foreground hover:bg-sidebar-accent/50 transition-all w-full"
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          {!collapsed && <span>Inklappen</span>}
        </button>
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-3 rounded-xl text-sm font-medium text-sidebar-foreground/50 hover:text-red-400 hover:bg-red-500/10 transition-all w-full"
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span>Uitloggen</span>}
        </button>
      </div>
    </aside>
  );
}