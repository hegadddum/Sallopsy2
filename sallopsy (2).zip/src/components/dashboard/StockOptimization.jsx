import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Zap, Loader2, Package, TrendingUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function StockOptimization() {
  const [stockData, setStockData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchStockData = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('optimizedStockAlerts', {});
      setStockData(res.data);
    } catch (err) {
      setError('Kon voorraadbeheer niet laden');
    }
    setLoading(false);
  };

  if (!stockData && !loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Voorraadbeheer</h3>
            <p className="text-sm text-muted-foreground">Geoptimaliseerde voorraadanalyse</p>
          </div>
          <Package className="w-6 h-6 text-accent" />
        </div>
        <Button onClick={fetchStockData} className="w-full" variant="outline">
          <Zap className="w-4 h-4 mr-2" />
          Check voorraden
        </Button>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 text-accent animate-spin" />
          <span className="ml-3 text-muted-foreground">Analyse wordt uitgevoerd...</span>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6 border-border/50 border-red-500/30 bg-red-500/5">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-700">{error}</h3>
            <Button onClick={fetchStockData} variant="ghost" size="sm" className="mt-2">
              Opnieuw proberen
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const { stockStatus, alerts, recommendations } = stockData;

  return (
    <Card className="p-6 border-border/50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Voorraadbeheer</h3>
          <p className="text-sm text-muted-foreground">{stockStatus.totalProducts} producten</p>
        </div>
        <Button onClick={fetchStockData} size="sm" variant="ghost">
          Vernieuwen
        </Button>
      </div>

      {/* Stock Status Summary */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="bg-red-500/10 rounded-lg p-3 border border-red-500/20">
          <p className="text-xs text-red-700 font-semibold mb-1">KRITIEK</p>
          <p className="text-2xl font-bold text-red-700">{stockStatus.critical}</p>
        </div>
        <div className="bg-amber-500/10 rounded-lg p-3 border border-amber-500/20">
          <p className="text-xs text-amber-700 font-semibold mb-1">WAARSCHUWING</p>
          <p className="text-2xl font-bold text-amber-700">{stockStatus.warning}</p>
        </div>
        <div className="bg-emerald-500/10 rounded-lg p-3 border border-emerald-500/20">
          <p className="text-xs text-emerald-700 font-semibold mb-1">OPTIMAL</p>
          <p className="text-2xl font-bold text-emerald-700">{stockStatus.optimal}</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Critical Items */}
        {alerts.critical.length > 0 && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-4">
            <h4 className="font-semibold text-red-700 text-sm mb-3 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Kritieke Voorraden ({alerts.critical.length})
            </h4>
            <div className="space-y-2">
              {alerts.critical.map((item, i) => (
                <div key={i} className="text-xs text-red-700 bg-red-500/5 p-2 rounded border border-red-500/10">
                  <div className="font-semibold">{item.name}</div>
                  <div className="mt-1 flex justify-between">
                    <span>Voorraad: {item.current}/{item.minimum}</span>
                    <Badge variant="outline" className="text-red-700 h-5">{item.recommendation}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Warning Items */}
        {alerts.warning.length > 0 && (
          <div>
            <h4 className="font-semibold text-foreground text-sm mb-2 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-amber-600" />
              Voorraden ter Hoogte ({alerts.warning.length})
            </h4>
            <div className="space-y-1">
              {alerts.warning.slice(0, 3).map((item, i) => (
                <div key={i} className="text-xs text-muted-foreground flex justify-between items-center p-2 bg-secondary/50 rounded">
                  <span>{item.name}</span>
                  <Badge variant="outline">{item.current}/{item.minimum}</Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Purchase Recommendations */}
        {recommendations.immediateOrders.length > 0 && (
          <div className="bg-primary/10 border border-primary/20 rounded-lg p-3">
            <h4 className="font-semibold text-primary text-sm mb-2">Onmiddellijke Bestellingen</h4>
            <div className="space-y-1">
              {recommendations.immediateOrders.map((order, i) => (
                <div key={i} className="text-xs text-primary">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">{order.product}</span>
                    <span>€{order.estimatedCost.toFixed(2)}</span>
                  </div>
                  <span className="text-primary/70">Hoeveelheid: {order.suggestedQuantity}</span>
                </div>
              ))}
            </div>
            <div className="mt-2 pt-2 border-t border-primary/20 text-sm font-semibold text-primary">
              Totaal: €{recommendations.totalEstimatedCost}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}