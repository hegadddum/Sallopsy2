import React, { useState, useMemo } from "react";
import { format, addDays, startOfWeek } from "date-fns";
import { nl } from "date-fns/locale";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const statusColors = {
  gepland: "bg-blue-500/10 border-blue-500/30 text-blue-700",
  bevestigd: "bg-emerald-500/10 border-emerald-500/30 text-emerald-700",
  voltooid: "bg-slate-500/10 border-slate-500/30 text-slate-600",
  geannuleerd: "bg-red-500/10 border-red-500/30 text-red-700 line-through opacity-60",
  no_show: "bg-amber-500/10 border-amber-500/30 text-amber-700",
};

export default function CalendarByStaff({ appointments = [], staffMembers = [], onAppointmentUpdate, onAppointmentClick }) {
  const [weekOffset, setWeekOffset] = useState(0);

  const weekStart = startOfWeek(addDays(new Date(), weekOffset * 7));
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  // Group appointments by staff member and day
  const apptsByStaffAndDay = useMemo(() => {
    const map = {};
    
    // Initialize all staff members
    staffMembers.forEach(staff => {
      map[staff.id] = {};
      days.forEach(day => {
        const key = format(day, "yyyy-MM-dd");
        map[staff.id][key] = [];
      });
    });

    // Fill in appointments
    appointments.forEach(appt => {
      if (appt.staff_member && map[appt.staff_member]) {
        const key = format(new Date(appt.date), "yyyy-MM-dd");
        if (map[appt.staff_member][key]) {
          map[appt.staff_member][key].push(appt);
        }
      }
    });

    return map;
  }, [appointments, staffMembers, weekStart]);

  const handleDragEnd = (result) => {
    const { source, destination, draggableId } = result;
    
    if (!destination) return;
    
    const appointment = appointments.find(a => a.id === draggableId);
    if (!appointment) return;

    // Extract staff member and date from destination
    const [staffId, newDate] = destination.droppableId.split("__");
    
    if (staffId === appointment.staff_member && newDate === appointment.date) {
      return; // No change
    }

    onAppointmentUpdate?.(appointment.id, {
      staff_member: staffId,
      date: newDate,
    });
  };

  const today = format(new Date(), "yyyy-MM-dd");

  return (
    <div className="bg-card rounded-2xl border border-border/50 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Agenda per medewerker</h3>
          <p className="text-sm text-muted-foreground mt-1">
            {format(days[0], "d MMMM", { locale: nl })} — {format(days[6], "d MMMM yyyy", { locale: nl })}
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setWeekOffset(weekOffset - 1)}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setWeekOffset(0)}
          >
            Vandaag
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setWeekOffset(weekOffset + 1)}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="overflow-x-auto">
          <div className="grid gap-6" style={{ gridTemplateColumns: `repeat(${Math.min(7, days.length)}, 280px)` }}>
            {/* Day columns */}
            {days.map((day) => {
              const dayKey = format(day, "yyyy-MM-dd");
              const isToday = dayKey === today;
              
              return (
                <div key={dayKey} className={cn(
                  "rounded-lg border",
                  isToday ? "border-primary/50 bg-primary/5" : "border-border/30 bg-secondary/10"
                )}>
                  {/* Day header */}
                  <div className={cn(
                    "px-4 py-3 border-b border-border/20",
                    isToday && "bg-primary/10"
                  )}>
                    <p className="text-xs font-semibold uppercase text-muted-foreground">
                      {format(day, "EEE", { locale: nl })}
                    </p>
                    <p className={cn(
                      "text-lg font-bold mt-1",
                      isToday ? "text-primary" : "text-foreground"
                    )}>
                      {format(day, "d")}
                    </p>
                  </div>

                  {/* Staff rows */}
                  <div className="flex flex-col">
                    {staffMembers.map((staff) => {
                      const dropId = `${staff.id}__${dayKey}`;
                      const staffAppts = apptsByStaffAndDay[staff.id]?.[dayKey] || [];
                      
                      return (
                        <Droppable key={dropId} droppableId={dropId} type="APPOINTMENT">
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.droppableProps}
                              className={cn(
                                "px-3 py-2 border-t border-border/10 min-h-[60px] flex flex-col gap-1.5",
                                snapshot.isDraggingOver && "bg-accent/20"
                              )}
                            >
                              {/* Staff name */}
                              <p className="text-xs font-medium text-muted-foreground truncate">
                                {staff.name}
                              </p>

                              {/* Appointments */}
                              {staffAppts.map((appt, idx) => (
                                <Draggable
                                  key={appt.id}
                                  draggableId={appt.id}
                                  index={idx}
                                  type="APPOINTMENT"
                                >
                                  {(provided, snapshot) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      {...provided.dragHandleProps}
                                      className={cn(
                                        "rounded border px-2 py-1.5 text-xs cursor-grab active:cursor-grabbing transition-all",
                                        statusColors[appt.status] || "bg-blue-500/10 border-blue-500/30",
                                        snapshot.isDragging && "shadow-lg opacity-90"
                                      )}
                                      onClick={() => onAppointmentClick?.(appt)}
                                    >
                                      <p className="font-semibold truncate leading-tight">
                                        {appt.client_name}
                                      </p>
                                      <p className="text-[10px] opacity-75 truncate">
                                        {appt.time} · {appt.service_name}
                                      </p>
                                    </div>
                                  )}
                                </Draggable>
                              ))}

                              {provided.placeholder}

                              {staffAppts.length === 0 && (
                                <div className="text-[10px] text-muted-foreground/40 py-1">
                                  Geen afspraken
                                </div>
                              )}
                            </div>
                          )}
                        </Droppable>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </DragDropContext>
    </div>
  );
}