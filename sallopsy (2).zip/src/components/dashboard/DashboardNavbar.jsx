import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const routeLabels = {
  "/dashboard": "Dashboard",
  "/appointments": "Afspraken",
  "/clients": "Klanten",
  "/services": "Diensten",
  "/inventory": "Voorraad",
  "/loyalty": "Loyaliteit",
  "/marketing": "Marketing",
  "/settings": "Instellingen",
};

export default function DashboardNavbar() {
  const location = useLocation();
  const label = routeLabels[location.pathname] || "Pagina";

  return (
    <div className="flex items-center justify-between mb-6 pb-4 border-b border-border">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span className="font-medium text-foreground">{label}</span>
      </div>

      {/* Home button */}
      <Link to="/">
        <Button variant="outline" size="sm" className="gap-2 text-sm font-medium">
          <Home className="w-4 h-4" />
          <span className="hidden sm:inline">Home</span>
        </Button>
      </Link>
    </div>
  );
}