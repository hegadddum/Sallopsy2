import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Zap, AlertCircle, Loader2, TrendingDown } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function CustomerInsights() {
  const [insights, setInsights] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchInsights = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('analyzeCustomerInsights', {});
      if (res.data.insights) {
        setInsights(res.data);
      } else {
        setError(res.data.message);
      }
    } catch (err) {
      setError('Kon inzichten niet laden');
    }
    setLoading(false);
  };

  if (!insights && !loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Klantinzichten</h3>
            <p className="text-sm text-muted-foreground">AI-analyse van klantgegevens</p>
          </div>
          <Users className="w-6 h-6 text-primary" />
        </div>
        <Button onClick={fetchInsights} className="w-full" variant="outline">
          <Zap className="w-4 h-4 mr-2" />
          Analyseer klanten
        </Button>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 text-primary animate-spin" />
          <span className="ml-3 text-muted-foreground">Analyse in progress...</span>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6 border-border/50 border-red-500/30 bg-red-500/5">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-700">{error}</h3>
            <Button onClick={fetchInsights} variant="ghost" size="sm" className="mt-2">
              Opnieuw proberen
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const { clientStats, insights: data } = insights;

  return (
    <Card className="p-6 border-border/50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Klantinzichten</h3>
          <p className="text-sm text-muted-foreground">Basis: {clientStats.totalClients} klanten</p>
        </div>
        <Button onClick={fetchInsights} size="sm" variant="ghost">
          Vernieuwen
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-primary/10 rounded-lg p-3">
          <p className="text-xs text-muted-foreground">VIP Klanten</p>
          <p className="text-2xl font-bold text-primary mt-1">{clientStats.vipCount}</p>
        </div>
        <div className="bg-amber-500/10 rounded-lg p-3">
          <p className="text-xs text-muted-foreground">Risicogroep</p>
          <p className="text-2xl font-bold text-amber-700 mt-1">{clientStats.atRiskCount}</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Retention Focus */}
        {data.retentionFocus.length > 0 && (
          <div>
            <h4 className="font-semibold text-foreground text-sm mb-2">Retentie Focus</h4>
            <ul className="space-y-1">
              {data.retentionFocus.map((item, i) => (
                <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                  <span className="text-primary">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Marketing Segments */}
        {data.marketingSegments.length > 0 && (
          <div className="bg-secondary/50 rounded-lg p-3">
            <h4 className="font-semibold text-foreground text-sm mb-3">Marketing Segmenten</h4>
            <div className="space-y-2">
              {data.marketingSegments.map((seg, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-foreground">{seg.segment}</span>
                    <Badge variant="outline" className="text-xs">{seg.estimatedValue}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{seg.strategy}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Churn Risk */}
        {data.churnRisk.length > 0 && (
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
            <h4 className="font-semibold text-red-700 text-sm mb-2 flex items-center gap-2">
              <TrendingDown className="w-4 h-4" />
              Churn Risico
            </h4>
            <ul className="space-y-1">
              {data.churnRisk.map((item, i) => (
                <li key={i} className="text-xs text-red-700">{item}</li>
              ))}
            </ul>
          </div>
        )}

        {/* Next Actions */}
        {data.nextActions.length > 0 && (
          <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3">
            <h4 className="font-semibold text-emerald-700 text-sm mb-2">Aanbevolen Acties</h4>
            <ol className="text-xs text-emerald-700 space-y-1 ml-4 list-decimal">
              {data.nextActions.map((action, i) => (
                <li key={i}>{action}</li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </Card>
  );
}