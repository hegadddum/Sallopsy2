import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Zap, AlertCircle, Loader2 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function RevenueForecast() {
  const [forecast, setForecast] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const fetchForecast = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('revenueForecasting', {});
      if (res.data.forecast) {
        setForecast(res.data.forecast);
      } else {
        setError(res.data.message);
      }
    } catch (err) {
      setError('Kon prognose niet laden');
    }
    setLoading(false);
  };

  if (!forecast && !loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Omzetprognose</h3>
            <p className="text-sm text-muted-foreground">AI-gestuurde voorspelling voor komende 3 maanden</p>
          </div>
          <TrendingUp className="w-6 h-6 text-primary" />
        </div>
        <Button onClick={fetchForecast} className="w-full" variant="outline">
          <Zap className="w-4 h-4 mr-2" />
          Genereer prognose
        </Button>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card className="p-6 border-border/50">
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-6 h-6 text-primary animate-spin" />
          <span className="ml-3 text-muted-foreground">Prognose aan het analyseren...</span>
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-6 border-border/50 border-red-500/30 bg-red-500/5">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-700">{error}</h3>
            <Button onClick={fetchForecast} variant="ghost" size="sm" className="mt-2">
              Opnieuw proberen
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  const chartData = [
    { month: 'Volgende', omzet: forecast.nextMonth },
    { month: 'Maand 2', omzet: forecast.month2 },
    { month: 'Maand 3', omzet: forecast.month3 }
  ];

  return (
    <Card className="p-6 border-border/50">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Omzetprognose</h3>
          <p className="text-sm text-muted-foreground">Komende 3 maanden (AI-analyse)</p>
        </div>
        <Button onClick={fetchForecast} size="sm" variant="ghost">
          Vernieuwen
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        {chartData.map((d, i) => (
          <div key={i} className="bg-secondary/50 rounded-lg p-4">
            <p className="text-xs text-muted-foreground font-medium mb-1">{d.month}</p>
            <p className="text-2xl font-bold text-primary">€{d.omzet.toLocaleString('nl-NL', { maximumFractionDigits: 0 })}</p>
          </div>
        ))}
      </div>

      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => `€${(v / 1000).toFixed(0)}k`} />
          <Tooltip formatter={(value) => `€${value.toFixed(0)}`} contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }} />
          <Bar dataKey="omzet" fill="hsl(230,65%,28%)" radius={[8, 8, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>

      <div className="mt-6 space-y-4">
        <div>
          <h4 className="font-semibold text-foreground text-sm mb-2">Seizoenspatroon</h4>
          <p className="text-sm text-muted-foreground">{forecast.seasonalPattern}</p>
        </div>

        {forecast.recommendations.length > 0 && (
          <div>
            <h4 className="font-semibold text-foreground text-sm mb-2 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Aanbevelingen
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {forecast.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-primary font-bold">•</span>
                  <span>{rec}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {forecast.warnings.length > 0 && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3">
            <h4 className="font-semibold text-amber-700 text-sm mb-2 flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              Waarschuwingen
            </h4>
            <ul className="text-sm text-amber-700 space-y-1">
              {forecast.warnings.map((warn, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span>•</span>
                  <span>{warn}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </Card>
  );
}