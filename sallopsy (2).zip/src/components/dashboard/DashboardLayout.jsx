import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import Sidebar from "./Sidebar";
import DashboardNavbar from "./DashboardNavbar";
import { cn } from "@/lib/utils";

export default function DashboardLayout() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Sidebar collapsed={collapsed} onToggle={() => setCollapsed(!collapsed)} />
      <main className={cn(
        "transition-all duration-300 min-h-screen",
        collapsed ? "ml-20" : "ml-64"
      )}>
        <div className="p-6 lg:p-8 max-w-[1400px] mx-auto">
          <DashboardNavbar />
          <Outlet />
        </div>
      </main>
    </div>
  );
}