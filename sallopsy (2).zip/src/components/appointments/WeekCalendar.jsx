import React, { useMemo } from "react";
import { format, startOfWeek, addDays, isSameDay, parseISO } from "date-fns";
import { nl } from "date-fns/locale";
import { cn } from "@/lib/utils";

const statusColors = {
  gepland: "bg-blue-100 border-blue-300 text-blue-800",
  bevestigd: "bg-emerald-100 border-emerald-300 text-emerald-800",
  voltooid: "bg-slate-100 border-slate-300 text-slate-600",
  geannuleerd: "bg-red-100 border-red-300 text-red-700 line-through opacity-60",
  no_show: "bg-amber-100 border-amber-300 text-amber-800",
};

const HOUR_HEIGHT = 60; // px per hour
const START_HOUR = 8;
const END_HOUR = 20;

export default function WeekCalendar({ appointments, weekStart, onAppointmentClick, onSlotClick }) {
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));
  const hours = Array.from({ length: END_HOUR - START_HOUR }, (_, i) => START_HOUR + i);

  const apptsByDay = useMemo(() => {
    const map = {};
    days.forEach((d) => {
      const key = format(d, "yyyy-MM-dd");
      map[key] = appointments.filter((a) => a.date === key);
    });
    return map;
  }, [appointments, weekStart]);

  const getApptStyle = (appt) => {
    const [h, m] = (appt.time || "09:00").split(":").map(Number);
    const top = ((h - START_HOUR) + m / 60) * HOUR_HEIGHT;
    const height = Math.max(((appt.duration || 30) / 60) * HOUR_HEIGHT, 28);
    return { top, height };
  };

  const today = format(new Date(), "yyyy-MM-dd");

  return (
    <div className="bg-card rounded-2xl border border-border/50 overflow-hidden">
      {/* Day headers */}
      <div className="grid border-b border-border/50" style={{ gridTemplateColumns: "56px repeat(7, 1fr)" }}>
        <div className="border-r border-border/30" />
        {days.map((day) => {
          const key = format(day, "yyyy-MM-dd");
          const isToday = key === today;
          return (
            <div key={key} className={cn(
              "py-3 text-center border-r border-border/30 last:border-0",
              isToday && "bg-primary/5"
            )}>
              <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                {format(day, "EEE", { locale: nl })}
              </p>
              <p className={cn(
                "text-sm font-bold mt-0.5",
                isToday ? "text-primary" : "text-foreground"
              )}>
                {format(day, "d")}
              </p>
            </div>
          );
        })}
      </div>

      {/* Time grid */}
      <div className="overflow-y-auto" style={{ maxHeight: "600px" }}>
        <div className="relative grid" style={{ gridTemplateColumns: "56px repeat(7, 1fr)" }}>
          {/* Hour labels */}
          <div className="relative">
            {hours.map((h) => (
              <div key={h} style={{ height: HOUR_HEIGHT }} className="border-b border-border/20 flex items-start justify-end pr-2 pt-1">
                <span className="text-[10px] text-muted-foreground">{h}:00</span>
              </div>
            ))}
          </div>

          {/* Day columns */}
          {days.map((day) => {
            const key = format(day, "yyyy-MM-dd");
            const dayAppts = apptsByDay[key] || [];
            const isToday = key === today;
            return (
              <div
                key={key}
                className={cn("relative border-r border-border/30 last:border-0", isToday && "bg-primary/[0.02]")}
                style={{ height: hours.length * HOUR_HEIGHT }}
                onClick={(e) => {
                  if (e.target === e.currentTarget) {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const clickY = e.clientY - rect.top;
                    const totalMinutes = (clickY / HOUR_HEIGHT) * 60 + START_HOUR * 60;
                    const h = Math.floor(totalMinutes / 60);
                    const m = Math.round((totalMinutes % 60) / 15) * 15;
                    onSlotClick?.(key, `${String(h).padStart(2, "0")}:${String(m % 60).padStart(2, "0")}`);
                  }
                }}
              >
                {/* Hour lines */}
                {hours.map((h) => (
                  <div key={h} style={{ top: (h - START_HOUR) * HOUR_HEIGHT, height: HOUR_HEIGHT }}
                    className="absolute inset-x-0 border-b border-border/20" />
                ))}

                {/* Appointments */}
                {dayAppts.map((appt) => {
                  const { top, height } = getApptStyle(appt);
                  return (
                    <div
                      key={appt.id}
                      className={cn(
                        "absolute inset-x-1 rounded-lg border px-2 py-1 cursor-pointer hover:opacity-90 hover:shadow-md transition-all text-xs overflow-hidden z-10",
                        statusColors[appt.status] || "bg-blue-100 border-blue-300 text-blue-800"
                      )}
                      style={{ top: top + 1, height: height - 2 }}
                      onClick={(e) => { e.stopPropagation(); onAppointmentClick?.(appt); }}
                    >
                      <p className="font-semibold truncate leading-tight">{appt.client_name}</p>
                      {height > 36 && (
                        <p className="truncate leading-tight opacity-75">{appt.service_name}</p>
                      )}
                      {height > 50 && (
                        <p className="opacity-60">{appt.time} · {appt.duration}m</p>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}