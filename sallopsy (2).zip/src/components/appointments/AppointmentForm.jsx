import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";

export default function AppointmentForm({ appointment, onSave, onCancel }) {
  const { data: clients = [] } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list("first_name", 200),
  });
  const { data: services = [] } = useQuery({
    queryKey: ["services"],
    queryFn: () => base44.entities.Service.list("name", 200),
  });

  const [form, setForm] = useState({
    client_id: "",
    client_name: "",
    client_email: "",
    service_id: "",
    service_name: "",
    date: "",
    time: "",
    duration: 30,
    price: 0,
    status: "gepland",
    notes: "",
    staff_member: "",
    ...appointment,
  });
  const [saving, setSaving] = useState(false);

  const handleServiceChange = (serviceId) => {
    const service = services.find((s) => s.id === serviceId);
    if (service) {
      setForm((f) => ({
        ...f,
        service_id: serviceId,
        service_name: service.name,
        duration: service.duration,
        price: service.price,
      }));
    }
  };

  const handleClientChange = (clientId) => {
    const client = clients.find((c) => c.id === clientId);
    if (client) {
      setForm((f) => ({
        ...f,
        client_id: clientId,
        client_name: `${client.first_name} ${client.last_name || ""}`.trim(),
        client_email: client.email || "",
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Klant</Label>
          <Select value={form.client_id} onValueChange={handleClientChange}>
            <SelectTrigger><SelectValue placeholder="Selecteer klant" /></SelectTrigger>
            <SelectContent>
              {clients.map((c) => (
                <SelectItem key={c.id} value={c.id}>
                  {c.first_name} {c.last_name || ""}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Dienst</Label>
          <Select value={form.service_id} onValueChange={handleServiceChange}>
            <SelectTrigger><SelectValue placeholder="Selecteer dienst" /></SelectTrigger>
            <SelectContent>
              {services.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.name} — €{s.price} ({s.duration} min)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Datum</Label>
          <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} required />
        </div>
        <div className="space-y-2">
          <Label>Tijd</Label>
          <Input type="time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} required />
        </div>
        <div className="space-y-2">
          <Label>Status</Label>
          <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="gepland">Gepland</SelectItem>
              <SelectItem value="bevestigd">Bevestigd</SelectItem>
              <SelectItem value="voltooid">Voltooid</SelectItem>
              <SelectItem value="geannuleerd">Geannuleerd</SelectItem>
              <SelectItem value="no_show">No-show</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Prijs (€)</Label>
          <Input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) || 0 })} />
        </div>
        <div className="space-y-2">
          <Label>Medewerker</Label>
          <Input value={form.staff_member} onChange={(e) => setForm({ ...form, staff_member: e.target.value })} placeholder="Naam medewerker" />
        </div>
      </div>

      <div className="space-y-2">
        <Label>E-mail klant</Label>
        <Input type="email" value={form.client_email} onChange={(e) => setForm({ ...form, client_email: e.target.value })} placeholder="Voor bevestigingsmail (optioneel)" />
      </div>

      <div className="space-y-2">
        <Label>Notities</Label>
        <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Optionele notities..." />
      </div>

      <div className="flex justify-end gap-3 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>Annuleren</Button>
        <Button type="submit" disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
          {appointment ? "Bijwerken" : "Afspraak maken"}
        </Button>
      </div>
    </form>
  );
}