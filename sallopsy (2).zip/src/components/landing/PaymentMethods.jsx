import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck } from "lucide-react";
import { useLanguage } from "@/lib/LanguageContext";

const methods = [
  { name: "iDEAL", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Ideal-logo.svg/320px-Ideal-logo.svg.png", bg: "bg-white" },
  { name: "Mastercard", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/320px-Mastercard-logo.svg.png", bg: "bg-white" },
  { name: "Visa", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/320px-Visa_Inc._logo.svg.png", bg: "bg-white" },
  { name: "PayPal", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b5/PayPal.svg/320px-PayPal.svg.png", bg: "bg-white" },
  { name: "Apple Pay", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b0/Apple_Pay_logo.svg/320px-Apple_Pay_logo.svg.png", bg: "bg-black" },
  { name: "Google Pay", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Google_Pay_Logo.svg/320px-Google_Pay_Logo.svg.png", bg: "bg-white" },
  { name: "Bancontact", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Bancontact_logo.svg/320px-Bancontact_logo.svg.png", bg: "bg-white" },
  { name: "Klarna", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/40/Klarna_Payment_Badge.svg/320px-Klarna_Payment_Badge.svg.png", bg: "bg-[#FFB3C7]" },
  { name: "Stripe", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/ba/Stripe_Logo%2C_revised_2016.svg/320px-Stripe_Logo%2C_revised_2016.svg.png", bg: "bg-white" },
  { name: "Mollie", logo: "https://www.mollie.com/images/mollie-logo-2022-dark.svg", bg: "bg-white" },
  { name: "SEPA", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/56/SEPA_logo.svg/320px-SEPA_logo.svg.png", bg: "bg-white" },
  { name: "Sofort", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Sofort_logo.svg/320px-Sofort_logo.svg.png", bg: "bg-white" },
  { name: "American Express", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/American_Express_logo_%282018%29.svg/320px-American_Express_logo_%282018%29.svg.png", bg: "bg-[#006FCF]" },
  { name: "Maestro", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Maestro_2016.svg/320px-Maestro_2016.svg.png", bg: "bg-white" },
  { name: "V PAY", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/7/78/V_Pay_logo.svg/320px-V_Pay_logo.svg.png", bg: "bg-white" },
  { name: "Giropay", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/Giropay_Logo.svg/320px-Giropay_Logo.svg.png", bg: "bg-white" },
  { name: "EPS", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/EPS_%C3%9Cberweisung_logo.svg/320px-EPS_%C3%9Cberweisung_logo.svg.png", bg: "bg-white" },
  { name: "Przelewy24", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Przelewy24_logo.svg/320px-Przelewy24_logo.svg.png", bg: "bg-white" },
  { name: "Twint", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/TWINT_Logo.svg/320px-TWINT_Logo.svg.png", bg: "bg-white" },
  { name: "Belfius", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Belfius_logo.svg/320px-Belfius_logo.svg.png", bg: "bg-white" },
  { name: "KBC/CBC", logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/be/KBC_logo.svg/320px-KBC_logo.svg.png", bg: "bg-white" },
];

export default function PaymentMethods() {
  const { t } = useLanguage();

  return (
    <section className="py-20 bg-gradient-to-b from-background to-secondary/20">
      <div className="max-w-5xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 text-sm font-semibold px-4 py-2 rounded-full mb-4">
            <ShieldCheck className="w-4 h-4" />
            PCI DSS Compliant · 256-bit SSL
          </div>
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground">{t.payTitle}</h2>
          <p className="mt-3 text-muted-foreground text-lg">{t.paySubtitle}</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="flex flex-wrap justify-center gap-4"
        >
          {methods.map((m, i) => (
            <motion.div
              key={m.name}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -4, scale: 1.05 }}
              className={`${m.bg} rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all duration-300 flex items-center justify-center p-4 w-28 h-16`}
              title={m.name}
            >
              <img
                src={m.logo}
                alt={m.name}
                className="max-h-8 max-w-full object-contain"
                onError={(e) => {
                  e.target.style.display = "none";
                  e.target.parentElement.innerHTML = `<span class="text-xs font-bold text-foreground">${m.name}</span>`;
                }}
              />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}