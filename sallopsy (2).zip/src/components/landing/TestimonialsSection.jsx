import React from "react";
import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Fatima El Amrani",
    salon: "Studio F – Amsterdam",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=80&h=80&fit=crop&q=80",
    text: "Sallopsy heeft mijn salon compleet getransformeerd. Ik beheer nu afspraken, voorraad én marketing vanuit één plek. Mijn omzet groeide 34% in het eerste kwartaal.",
    stars: 5,
    highlight: "+34% omzet",
  },
  {
    name: "Jelle van der Berg",
    salon: "Barbers Deluxe – Rotterdam",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&q=80",
    text: "Eindelijk een systeem dat alles aan elkaar koppelt. De automatische herinneringen per e-mail zorgen dat klanten niet meer vergeten te komen. No-shows zijn met 60% gedaald.",
    stars: 5,
    highlight: "-60% no-shows",
  },
  {
    name: "Sandra Koopman",
    salon: "Hair & Soul – Utrecht",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=80&h=80&fit=crop&q=80",
    text: "De webshop is een gamechanger. Klanten bestellen nu ook thuis producten. Dat is pure extra omzet bovenop de salon zonder extra werk.",
    stars: 5,
    highlight: "Extra webshop omzet",
  },
  {
    name: "Marcus Diallo",
    salon: "The Cut – Den Haag",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=80&h=80&fit=crop&q=80",
    text: "Het loyaliteitssysteem houdt mijn vaste klanten betrokken. Ze komen vaker terug om punten te sparen. Klantenbinding is enorm verbeterd.",
    stars: 5,
    highlight: "Hogere klantenbinding",
  },
  {
    name: "Nathalie Berger",
    salon: "Coloriste – Antwerpen",
    avatar: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=80&h=80&fit=crop&q=80",
    text: "Als Belgische salon is iDEAL en Bancontact onmisbaar. Sallopsy ondersteunt alles. Setup duurde letterlijk 20 minuten en ik was live.",
    stars: 5,
    highlight: "20 min. live",
  },
  {
    name: "Thomas Koster",
    salon: "Koster Kapper – Eindhoven",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop&q=80",
    text: "De AI-forecasting vertelt me precies wanneer ik nieuwe voorraad moet bestellen. Nooit meer te laat of te veel inkopen. Bespaart me echt geld.",
    stars: 5,
    highlight: "Slimmere inkoop",
  },
];

export default function TestimonialsSection() {
  return (
    <section className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-semibold mb-6">
            <Star className="w-4 h-4 fill-accent" />
            Wat saloneigenaren zeggen
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Echte resultaten, echte salons
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Meer dan 500 salons in Nederland en België vertrouwen dagelijks op Sallopsy.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-card border border-border rounded-2xl p-6 flex flex-col gap-4 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-center justify-between">
                <div className="flex gap-0.5">
                  {Array.from({ length: t.stars }).map((_, s) => (
                    <Star key={s} className="w-4 h-4 fill-accent text-accent" />
                  ))}
                </div>
                <span className="text-xs font-semibold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full">
                  {t.highlight}
                </span>
              </div>

              <div className="relative">
                <Quote className="w-6 h-6 text-primary/20 absolute -top-1 -left-1" />
                <p className="text-sm text-muted-foreground leading-relaxed pl-5">{t.text}</p>
              </div>

              <div className="flex items-center gap-3 mt-auto pt-2 border-t border-border/50">
                <img
                  src={t.avatar}
                  alt={t.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <p className="text-sm font-semibold text-foreground">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.salon}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Aggregate rating */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-8 text-center"
        >
          <div>
            <p className="text-4xl font-bold text-foreground">4.9</p>
            <div className="flex gap-0.5 justify-center mt-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-accent text-accent" />
              ))}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Gemiddelde beoordeling</p>
          </div>
          <div className="hidden sm:block w-px h-12 bg-border" />
          <div>
            <p className="text-4xl font-bold text-foreground">500+</p>
            <p className="text-xs text-muted-foreground mt-1">Actieve salons</p>
          </div>
          <div className="hidden sm:block w-px h-12 bg-border" />
          <div>
            <p className="text-4xl font-bold text-foreground">98%</p>
            <p className="text-xs text-muted-foreground mt-1">Klanttevredenheid</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}