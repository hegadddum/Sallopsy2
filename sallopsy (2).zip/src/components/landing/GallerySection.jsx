import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronLeft, ChevronRight, Sparkles } from "lucide-react";

const images = [
  {
    url: "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=1200&q=95&fit=crop",
    alt: "Professionele barber aan het werk",
    label: "Master Barber",
    category: "Barber"
  },
  {
    url: "https://images.unsplash.com/photo-1605497788044-5a32c7078486?w=1200&q=95&fit=crop",
    alt: "Luxe haarverzorging producten",
    label: "Premium Producten",
    category: "Verzorging"
  },
  {
    url: "https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?w=1200&q=95&fit=crop",
    alt: "Klassiek barbershop interieur",
    label: "Premium Salon",
    category: "Interieur"
  },
  {
    url: "https://images.unsplash.com/photo-1493256338651-d82f7acb2b38?w=1200&q=95&fit=crop",
    alt: "Moderne haarverzorging producten",
    label: "Haar Collectie",
    category: "Verzorging"
  },
  {
    url: "https://images.unsplash.com/photo-1559599101-f09722fb4948?w=1200&q=95&fit=crop",
    alt: "Barber met precisie tools",
    label: "Precision Fade",
    category: "Barber"
  },
  {
    url: "https://images.unsplash.com/photo-1622288432450-277d0fef5ed6?w=1200&q=95&fit=crop",
    alt: "Premium haar styling producten",
    label: "Styling Essentials",
    category: "Verzorging"
  },
  {
    url: "https://images.unsplash.com/photo-1562322140-8baeececf3df?w=1200&q=95&fit=crop",
    alt: "Dame in luxe salon",
    label: "Luxe Behandeling",
    category: "Salon"
  },
  {
    url: "https://images.unsplash.com/photo-1582095133179-bfd08e2fb6b8?w=1200&q=95&fit=crop",
    alt: "Professionele scheerbeurt",
    label: "Classic Shave",
    category: "Barber"
  },
  {
    url: "https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=1200&q=95&fit=crop",
    alt: "Huid- en haarverzorging producten",
    label: "Skincare Line",
    category: "Verzorging"
  },
];

const FILTERS = ["Alle", "Barber", "Verzorging", "Salon", "Interieur"];

const categoryColors = {
  Barber: "bg-primary/90 text-white",
  Verzorging: "bg-emerald-600/90 text-white",
  Salon: "bg-violet-600/90 text-white",
  Interieur: "bg-amber-600/90 text-white",
};

export default function GallerySection() {
  const [filter, setFilter] = useState("Alle");
  const [lightbox, setLightbox] = useState(null);

  const filtered = filter === "Alle" ? images : images.filter(i => i.category === filter);

  const prev = () => setLightbox(i => (i - 1 + filtered.length) % filtered.length);
  const next = () => setLightbox(i => (i + 1) % filtered.length);

  return (
    <section id="gallery" className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/[0.02] to-background" />
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-accent/40 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-6"
        >
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">Galerie</span>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4">
            Vakmanschap & Stijl
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Van klassieke barbershops tot moderne salonbehandelingen — Sallopsy ondersteunt elke salon die het beste wil.
          </p>
        </motion.div>

        {/* Filter tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="flex flex-wrap justify-center gap-2 mb-12"
        >
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-5 py-2 rounded-full text-sm font-semibold transition-all duration-300 ${
                filter === f
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20"
                  : "bg-card border border-border/50 text-muted-foreground hover:text-foreground hover:border-primary/30"
              }`}
            >
              {f}
            </button>
          ))}
        </motion.div>

        {/* Masonry-style grid */}
        <motion.div
          layout
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((img, i) => (
              <motion.div
                key={img.url}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.35, delay: i * 0.05 }}
                className={`group relative overflow-hidden rounded-2xl cursor-pointer ${
                  i % 5 === 0 ? "md:col-span-2 aspect-[16/9]" : "aspect-square"
                }`}
                onClick={() => setLightbox(i)}
              >
                <img
                  src={img.url}
                  alt={img.alt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                />
                {/* Gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                {/* Label */}
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-white font-bold text-base">{img.label}</p>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium mt-1 inline-block ${categoryColors[img.category]}`}>
                        {img.category}
                      </span>
                    </div>
                    <div className="w-9 h-9 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </div>
                {/* Shine effect */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-tr from-transparent via-white/5 to-transparent" />
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {lightbox !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setLightbox(null)}
          >
            <motion.div
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative max-w-5xl max-h-[90vh] w-full"
              onClick={e => e.stopPropagation()}
            >
              <img
                src={filtered[lightbox]?.url}
                alt={filtered[lightbox]?.alt}
                className="w-full h-full object-contain rounded-2xl shadow-2xl"
                style={{ maxHeight: "80vh" }}
              />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div className="bg-black/60 backdrop-blur-sm rounded-xl px-4 py-2">
                  <p className="text-white font-bold">{filtered[lightbox]?.label}</p>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${categoryColors[filtered[lightbox]?.category]}`}>
                    {filtered[lightbox]?.category}
                  </span>
                </div>
                <p className="text-white/60 text-sm">{lightbox + 1} / {filtered.length}</p>
              </div>
              {/* Nav buttons */}
              <button onClick={prev} className="absolute left-3 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/10 hover:bg-white/25 backdrop-blur-sm flex items-center justify-center text-white transition-all">
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button onClick={next} className="absolute right-3 top-1/2 -translate-y-1/2 w-11 h-11 rounded-full bg-white/10 hover:bg-white/25 backdrop-blur-sm flex items-center justify-center text-white transition-all">
                <ChevronRight className="w-6 h-6" />
              </button>
              <button onClick={() => setLightbox(null)} className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/10 hover:bg-white/25 backdrop-blur-sm flex items-center justify-center text-white transition-all">
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}