import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Calendar, Users, TrendingUp, Zap } from "lucide-react";
import { motion } from "framer-motion";

const floatingCards = [
  { icon: Calendar, label: "12 afspraken", sub: "vandaag", color: "bg-primary text-primary-foreground", x: "left-[5%]", y: "top-[20%]" },
  { icon: TrendingUp, label: "€2.847", sub: "deze week", color: "bg-accent text-accent-foreground", x: "right-[8%]", y: "top-[15%]" },
  { icon: Users, label: "94%", sub: "retentie", color: "bg-emerald-500 text-white", x: "right-[5%]", y: "bottom-[30%]" },
  { icon: Zap, label: "AI Actief", sub: "upsell klaar", color: "bg-violet-500 text-white", x: "left-[8%]", y: "bottom-[25%]" },
];

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background: barber/salon collage */}
      <div className="absolute inset-0 grid grid-cols-3 grid-rows-2 opacity-[0.13]">
        {[
          "https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=800&q=80&fit=crop",
          "https://images.unsplash.com/photo-1521590832167-7bcbfaa6381f?w=800&q=80&fit=crop",
          "https://images.unsplash.com/photo-1605497788044-5a32c7078486?w=800&q=80&fit=crop",
          "https://images.unsplash.com/photo-1559599101-f09722fb4948?w=800&q=80&fit=crop",
          "https://images.unsplash.com/photo-1582095133179-bfd08e2fb6b8?w=800&q=80&fit=crop",
          "https://images.unsplash.com/photo-1562322140-8baeececf3df?w=800&q=80&fit=crop",
        ].map((src, i) => (
          <img key={i} src={src} alt="" className="w-full h-full object-cover" />
        ))}
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/85 to-background" />
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-gradient-radial from-primary/10 via-transparent to-transparent rounded-full blur-3xl" />
      
      {/* Floating cards — desktop only */}
      <div className="hidden lg:block">
        {floatingCards.map((card, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.8 + i * 0.15, duration: 0.5 }}
            className={`absolute ${card.x} ${card.y} z-10`}
          >
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3 + i * 0.5, repeat: Infinity, ease: "easeInOut" }}
              className="bg-card/90 backdrop-blur-md rounded-2xl p-4 shadow-xl shadow-black/5 border border-border/50"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl ${card.color} flex items-center justify-center`}>
                  <card.icon className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">{card.label}</p>
                  <p className="text-xs text-muted-foreground">{card.sub}</p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        ))}
      </div>

      <div className="relative z-20 max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-8">
            <Zap className="w-4 h-4" />
            <span>Het besturingssysteem voor moderne salons</span>
          </div>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-display text-5xl sm:text-6xl lg:text-7xl font-bold text-foreground leading-[1.1] tracking-tight"
        >
          Eén intelligent{" "}
          <span className="text-primary">ecosysteem</span>{" "}
          voor jouw salon
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
        >
          Boekingen, CRM, memberships, AI, marketing en analytics — alles verbonden in één slim platform. Bouw aan voorspelbare omzet en schaalbare groei.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link to="/register">
            <Button size="lg" className="h-14 px-8 text-base font-semibold bg-primary hover:bg-primary/90 shadow-lg shadow-primary/20">
              Gratis starten
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          <Link to="/how-it-works">
            <Button size="lg" variant="outline" className="h-14 px-8 text-base font-medium">
              <Play className="w-4 h-4 mr-2" />
              Bekijk hoe het werkt
            </Button>
          </Link>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 1 }}
          className="mt-16 flex items-center justify-center gap-8 text-sm text-muted-foreground"
        >
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Alle betaalmethoden geaccepteerd</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>14 dagen gratis proberen</span>
          </div>
          <div className="hidden sm:flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>Direct aan de slag</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
}