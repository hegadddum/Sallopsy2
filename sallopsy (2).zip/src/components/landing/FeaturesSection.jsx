import React from "react";
import { motion } from "framer-motion";
import {
  Calendar, Users, CreditCard, BarChart3, Brain,
  Megaphone, ShoppingBag, Shield
} from "lucide-react";

const features = [
  {
    icon: Calendar,
    title: "Slim Boekingssysteem",
    description: "Online afspraken, realtime agenda, automatische bevestigingen en no-show reminders.",
    gradient: "from-blue-500 to-indigo-600"
  },
  {
    icon: Users,
    title: "360° Klantbeheer",
    description: "Compleet CRM met klantgeschiedenis, voorkeuren, notities en favoriete behandelingen.",
    gradient: "from-emerald-500 to-teal-600"
  },
  {
    icon: CreditCard,
    title: "Betalingen & Memberships",
    description: "Stripe & Mollie integratie, recurring billing, loyalty en automatische incasso's.",
    gradient: "from-amber-500 to-orange-600"
  },
  {
    icon: BarChart3,
    title: "Realtime Analytics",
    description: "Omzetdashboards, KPI's, forecasting, klantretentie en prestatie-inzichten.",
    gradient: "from-violet-500 to-purple-600"
  },
  {
    icon: Brain,
    title: "AI Engine",
    description: "Omzetvoorspellingen, churn prediction, slimme upsells en prijsoptimalisatie.",
    gradient: "from-rose-500 to-pink-600"
  },
  {
    icon: Megaphone,
    title: "Marketing Automation",
    description: "WhatsApp flows, verjaardagscampagnes, review automation en inactieve klant flows.",
    gradient: "from-cyan-500 to-blue-600"
  },
  {
    icon: ShoppingBag,
    title: "Webshop Integratie",
    description: "Productverkoop, cadeaubonnen, bundelaanbiedingen en voorraadbeheer.",
    gradient: "from-lime-500 to-green-600"
  },
  {
    icon: Shield,
    title: "NIS2 & Enterprise Security",
    description: "NIS2-compliant, AES-256 encryptie, MFA, RBAC, audit logging en EU-datahosting.",
    gradient: "from-slate-500 to-gray-600"
  }
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-32 relative">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">Features</span>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4">
            Alles wat je salon nodig heeft
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Geen losse tools meer. Eén platform dat alles verbindt en je salon slimmer maakt.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="group relative bg-card rounded-2xl p-6 border border-border/50 hover:border-primary/20 hover:shadow-xl hover:shadow-primary/5 transition-all duration-500"
            >
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-5 shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}