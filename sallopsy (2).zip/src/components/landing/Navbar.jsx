import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, Scissors, LayoutDashboard, Globe, ShoppingBag, ChevronRight, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useLanguage } from "@/lib/LanguageContext";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [servicesDropdown, setServicesDropdown] = useState(false);
  const [resourcesDropdown, setResourcesDropdown] = useState(false);
  const { lang, setLang, t } = useLanguage();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = [
    { label: t.features, href: "#features" },
    { label: t.pricing, href: "#pricing" },
    { label: t.why, href: "#why" },
    { label: t.howItWorks, href: "/how-it-works", isRoute: true },
    { label: "Webshop", href: "/shop", isRoute: true },
    { label: "Boeken", href: "/boeken", isRoute: true },
  ];

  return (
    <>
      {/* Navbar */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          scrolled
            ? "bg-white/80 backdrop-blur-xl shadow-lg shadow-black/5 border-b border-border/50"
            : "bg-transparent"
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3 z-50">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
              <Scissors className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <span className="font-display text-xl font-bold text-foreground tracking-tight">Sallopsy</span>
              <span className="hidden sm:block text-[10px] text-muted-foreground tracking-widest uppercase">The Salon Operating System</span>
            </div>
          </Link>

          <div className="hidden lg:flex items-center gap-8">
            {links.map((l) => (
              <div key={l.label} className="relative group">
                {l.submenu ? (
                  <>
                    <button className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                      {l.label}
                    </button>
                    <div className="absolute left-0 mt-2 w-48 bg-card border border-border rounded-lg shadow-lg opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                      {l.submenu.map((item) => (
                        <Link
                          key={item.label}
                          to={item.href}
                          className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors first:rounded-t-lg last:rounded-b-lg"
                        >
                          {item.label}
                        </Link>
                      ))}
                    </div>
                  </>
                ) : l.isRoute ? (
                  <Link to={l.href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                    {l.label}
                  </Link>
                ) : (
                  <a href={l.href} className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                    {l.label}
                  </a>
                )}
              </div>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-3">
            <div className="relative">
              <button
                onMouseEnter={() => setServicesDropdown(true)}
                onMouseLeave={() => setServicesDropdown(false)}
                className="flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors px-3 py-2 rounded-lg hover:bg-secondary"
              >
                Menu
                <ChevronDown className="w-3 h-3" />
              </button>
              {servicesDropdown && (
                <div
                  onMouseEnter={() => setServicesDropdown(true)}
                  onMouseLeave={() => setServicesDropdown(false)}
                  className="absolute right-0 mt-2 w-56 bg-card border border-border rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto"
                >
                  <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-widest border-b border-border">
                    Platform
                  </div>
                  <a href="#features" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Features
                  </a>
                  <a href="#pricing" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Pricing
                  </a>
                  <a href="#why" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Waarom Sallopsy
                  </a>
                  <a href="/how-it-works" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Hoe het werkt
                  </a>

                  <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-widest border-b border-t border-border mt-2">
                    Producten
                  </div>
                  <a href="/shop" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Shampoo
                  </a>
                  <a href="/shop" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Conditioner
                  </a>
                  <a href="/shop" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Styling
                  </a>
                  <a href="/shop" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Kleur
                  </a>
                  <Link to="/shop" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors font-medium border-t border-border">
                    Naar Webshop
                  </Link>

                  <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-widest border-b border-t border-border mt-2">
                    Diensten
                  </div>
                  <a href="#" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Knippen
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Kleuren
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Styling
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Verzorging
                  </a>

                  <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-widest border-b border-t border-border mt-2">
                    Account
                  </div>
                  <Link to="/login" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Inloggen
                  </Link>
                  <Link to="/register" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Registreren
                  </Link>
                  <Link to="/dashboard" className="block px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors">
                    Dashboard
                  </Link>
                  <button
                    onClick={() => setLang(lang === "nl" ? "en" : "nl")}
                    className="block w-full text-left px-4 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary transition-colors rounded-b-lg border-t border-border"
                  >
                    Taal: {lang === "nl" ? "🇳🇱 Nederlands" : "🇬🇧 English"}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Hamburger Button */}
          <button 
            className="lg:hidden p-2 hover:bg-secondary rounded-lg transition-colors"
            onClick={() => setSidebarOpen(!sidebarOpen)}
          >
            {sidebarOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </motion.nav>

      {/* Sidebar Overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/50 z-30 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ x: -400, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -400, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="fixed left-0 top-0 h-full w-80 bg-card border-r border-border z-40 lg:hidden overflow-y-auto pt-24"
          >
            <div className="px-6 py-8 space-y-6">
              {/* Language Selector */}
              <div className="pb-6 border-b border-border">
                <button
                  onClick={() => setLang(lang === "nl" ? "en" : "nl")}
                  className="flex items-center justify-between w-full p-3 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Globe className="w-5 h-5 text-primary" />
                    <span className="font-semibold text-foreground">
                      {lang === "nl" ? "English" : "Nederlands"}
                    </span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </button>
              </div>

              {/* Navigation Links */}
              <div className="space-y-2">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest mb-4">Navigatie</p>
                {links.map((l) => (
                  <div key={l.label}>
                    {l.submenu ? (
                      <>
                        <button className="block w-full text-left p-3 rounded-lg text-foreground font-medium hover:bg-secondary/50 transition-colors">
                          {l.label}
                        </button>
                        <div className="pl-4 space-y-1">
                          {l.submenu.map((item) => (
                            <Link
                              key={item.label}
                              to={item.href}
                              onClick={() => setSidebarOpen(false)}
                              className="block p-2 text-sm text-muted-foreground hover:text-foreground hover:bg-secondary/50 rounded-lg transition-colors"
                            >
                              {item.label}
                            </Link>
                          ))}
                        </div>
                      </>
                    ) : l.isRoute ? (
                      <Link
                        to={l.href}
                        onClick={() => setSidebarOpen(false)}
                        className="block p-3 rounded-lg text-foreground font-medium hover:bg-secondary/50 transition-colors"
                      >
                        {l.label}
                      </Link>
                    ) : (
                      <a
                        href={l.href}
                        onClick={() => setSidebarOpen(false)}
                        className="block p-3 rounded-lg text-foreground font-medium hover:bg-secondary/50 transition-colors"
                      >
                        {l.label}
                      </a>
                    )}
                  </div>
                ))}
              </div>

              {/* Special Links */}
              <div className="pt-6 border-t border-border space-y-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Account</p>
                
                <Link
                  to="/shop"
                  onClick={() => setSidebarOpen(false)}
                  className="flex items-center gap-3 p-3 rounded-lg bg-accent/10 hover:bg-accent/20 transition-colors"
                >
                  <ShoppingBag className="w-5 h-5 text-accent" />
                  <span className="font-semibold text-foreground">Webshop</span>
                </Link>

                <Link
                  to="/login"
                  onClick={() => setSidebarOpen(false)}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors"
                >
                  <span className="font-semibold text-foreground">Inloggen</span>
                </Link>

                <Link
                  to="/dashboard"
                  onClick={() => setSidebarOpen(false)}
                  className="flex items-center gap-3 p-3 rounded-lg hover:bg-secondary/50 transition-colors"
                >
                  <LayoutDashboard className="w-5 h-5 text-primary" />
                  <span className="font-semibold text-foreground">Dashboard</span>
                </Link>
              </div>

              {/* CTA Button */}
              <div className="pt-6 space-y-2">
                <Link
                  to="/register"
                  onClick={() => setSidebarOpen(false)}
                  className="block"
                >
                  <Button className="w-full bg-primary hover:bg-primary/90 font-semibold">
                    Gratis starten
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}