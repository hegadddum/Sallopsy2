import React from "react";
import { motion } from "framer-motion";
import { CheckCircle2, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const results = [
  "Voorspelbare omzet",
  "Terugkerende klanten",
  "Hogere klantwaarde",
  "Volledige automatisering",
  "Schaalbare groei",
  "Meer controle & winstgevendheid",
];

export default function WhySection() {
  return (
    <section id="why" className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />

      <div className="relative max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-sm font-semibold text-accent uppercase tracking-widest">Waarom Sallopsy</span>
            <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4 leading-tight">
              Niet zomaar een booking app
            </h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              De meeste systemen zijn agenda's, kassasystemen of simpele booking apps.
              Sallopsy combineert boekingen, memberships, AI, automatisering, marketing,
              webshop, CRM en omzetanalyse in één slim ecosysteem.
            </p>

            <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {results.map((r, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.08 }}
                  className="flex items-center gap-3"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                  <span className="text-sm font-medium text-foreground">{r}</span>
                </motion.div>
              ))}
            </div>

            <div className="mt-10">
              <Link to="/register">
                <Button size="lg" className="h-14 px-8 text-base font-semibold bg-primary hover:bg-primary/90">
                  Begin vandaag
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="relative"
          >
            {/* Decorative dashboard mockup */}
            <div className="relative bg-card rounded-3xl border border-border/50 shadow-2xl shadow-black/10 p-6 overflow-hidden">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <div className="w-3 h-3 rounded-full bg-amber-400" />
                <div className="w-3 h-3 rounded-full bg-emerald-400" />
                <span className="text-xs text-muted-foreground ml-3">salon-dashboard.sallopsy.nl</span>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-3">
                  {[
                    { label: "Omzet", value: "€12.847", change: "+23%" },
                    { label: "Klanten", value: "342", change: "+12%" },
                    { label: "Retentie", value: "94%", change: "+5%" },
                  ].map((s, i) => (
                    <div key={i} className="bg-secondary/50 rounded-xl p-3">
                      <p className="text-xs text-muted-foreground">{s.label}</p>
                      <p className="text-lg font-bold text-foreground mt-1">{s.value}</p>
                      <span className="text-xs text-emerald-500 font-medium">{s.change}</span>
                    </div>
                  ))}
                </div>

                <div className="bg-secondary/30 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-medium text-foreground">Vandaag</span>
                    <span className="text-xs text-muted-foreground">8 afspraken</span>
                  </div>
                  {["09:00 — Knippen — Lara M.", "10:30 — Kleuren — Sophie V.", "12:00 — Baard — Daan K."].map((a, i) => (
                    <div key={i} className="flex items-center gap-3 py-2 border-b border-border/30 last:border-0">
                      <div className={`w-1.5 h-8 rounded-full ${["bg-primary", "bg-accent", "bg-emerald-500"][i]}`} />
                      <span className="text-xs text-foreground">{a}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center gap-3 bg-primary/5 rounded-xl p-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <span className="text-sm">🤖</span>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-foreground">AI Suggestie</p>
                    <p className="text-xs text-muted-foreground">Sophie V. is klaar voor een membership upsell</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Glow effect */}
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-accent/20 rounded-full blur-3xl" />
            <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-primary/20 rounded-full blur-3xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}