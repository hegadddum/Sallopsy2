import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Star, ShoppingBag, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const products = [
  {
    img: "https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=600&q=95&fit=crop",
    name: "Premium Pomade",
    brand: "Reuzel",
    category: "Styling",
    rating: 4.9,
    price: "€24,95",
    badge: "Bestseller",
    badgeColor: "bg-amber-500",
  },
  {
    img: "https://images.unsplash.com/photo-1585751119414-ef2636f8aede?w=600&q=95&fit=crop",
    name: "Beard Oil",
    brand: "Captain Fawcett",
    category: "Baard",
    rating: 4.8,
    price: "€29,95",
    badge: "Nieuw",
    badgeColor: "bg-emerald-500",
  },
  {
    img: "https://images.unsplash.com/photo-1526045612212-70caf35c14df?w=600&q=95&fit=crop",
    name: "Sea Salt Spray",
    brand: "American Crew",
    category: "Haar",
    rating: 4.7,
    price: "€18,50",
    badge: "Top Rated",
    badgeColor: "bg-violet-500",
  },
  {
    img: "https://images.unsplash.com/photo-1631390010611-618c53e3af41?w=600&q=95&fit=crop",
    name: "Shaving Cream",
    brand: "Proraso",
    category: "Scheer",
    rating: 4.9,
    price: "€14,95",
    badge: "Klassiek",
    badgeColor: "bg-primary",
  },
  {
    img: "https://images.unsplash.com/photo-1576426863848-c21f53c60b19?w=600&q=95&fit=crop",
    name: "After Shave Balsem",
    brand: "Nivea Men",
    category: "Huid",
    rating: 4.6,
    price: "€12,50",
    badge: "Populair",
    badgeColor: "bg-cyan-500",
  },
  {
    img: "https://images.unsplash.com/photo-1556760544-74068565f05c?w=600&q=95&fit=crop",
    name: "Wax & Clay",
    brand: "Layrite",
    category: "Styling",
    rating: 4.8,
    price: "€22,00",
    badge: "Pro Choice",
    badgeColor: "bg-rose-500",
  },
];

export default function ProductsShowcase() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const y1 = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const y2 = useTransform(scrollYProgress, [0, 1], [-40, 40]);

  return (
    <section ref={ref} className="py-32 relative overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
      <motion.div style={{ y: y1 }} className="absolute -top-20 -right-20 w-80 h-80 bg-accent/10 rounded-full blur-3xl pointer-events-none" />
      <motion.div style={{ y: y2 }} className="absolute -bottom-20 -left-20 w-96 h-96 bg-primary/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">Verzorgingsproducten</span>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4">
            Premium producten,{" "}
            <span className="text-primary">één platform</span>
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Beheer en verkoop je producten direct via Sallopsy. Van styling wax tot beard oil — alles in één webshop.
          </p>
        </motion.div>

        {/* Products grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-5 mb-12">
          {products.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
              whileHover={{ y: -8, transition: { duration: 0.25 } }}
              className="group relative bg-card rounded-3xl overflow-hidden border border-border/50 shadow-sm hover:shadow-2xl hover:shadow-black/10 transition-shadow duration-500"
            >
              {/* Product image */}
              <div className="relative aspect-square overflow-hidden">
                <img
                  src={p.img}
                  alt={p.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                />
                {/* Badge */}
                <div className={`absolute top-3 left-3 ${p.badgeColor} text-white text-xs font-bold px-2.5 py-1 rounded-full shadow-lg`}>
                  {p.badge}
                </div>
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <div className="absolute bottom-3 left-0 right-0 flex justify-center opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-3 group-hover:translate-y-0">
                  <span className="bg-white/90 backdrop-blur-sm text-foreground text-xs font-semibold px-3 py-1.5 rounded-full shadow-lg">
                    Bekijk details →
                  </span>
                </div>
              </div>

              {/* Product info */}
              <div className="p-4">
                <p className="text-xs text-muted-foreground font-medium">{p.brand} · {p.category}</p>
                <h3 className="text-base font-bold text-foreground mt-0.5">{p.name}</h3>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span className="text-xs font-semibold text-foreground">{p.rating}</span>
                  </div>
                  <span className="text-base font-bold text-primary">{p.price}</span>
                </div>
              </div>

              {/* Shine effect */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-700 bg-gradient-to-tr from-transparent via-white/[0.04] to-transparent" />
            </motion.div>
          ))}
        </div>

        {/* CTA strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative bg-gradient-to-r from-primary via-primary to-primary/90 rounded-3xl p-8 sm:p-10 overflow-hidden"
        >
          {/* Decorative bokeh circles */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-40 h-40 bg-accent/20 rounded-full blur-2xl pointer-events-none" />
          <div className="relative flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <ShoppingBag className="w-5 h-5 text-accent" />
                <span className="text-accent text-sm font-semibold uppercase tracking-wider">Webshop Integratie</span>
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold text-white">
                Jouw producten, direct te koop
              </h3>
              <p className="text-white/70 text-sm mt-2 max-w-md">
                Voeg producten toe, stel voorraadwaarschuwingen in en verkoop direct aan je klanten — alles vanuit Sallopsy.
              </p>
            </div>
            <Link to="/register" className="flex-shrink-0">
              <Button size="lg" className="h-12 px-8 bg-accent text-accent-foreground hover:bg-accent/90 font-semibold shadow-xl shadow-black/20">
                Start je webshop
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}