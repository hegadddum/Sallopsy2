import React from "react";
import { Link } from "react-router-dom";
import { Scissors } from "lucide-react";

export default function FooterSection() {
  return (
    <footer className="border-t border-border/50 bg-card/50">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center">
                <Scissors className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <span className="font-display text-lg font-bold text-foreground">Sallopsy</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Het complete Salon Operating System voor moderne salons.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">Product</h4>
            <ul className="space-y-3">
              <li><a href="#features" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Features</a></li>
              <li><a href="#pricing" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Pakketten</a></li>
              <li><Link to="/betaalmogelijkheden" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Betaalmogelijkheden</Link></li>
              <li><Link to="/how-it-works" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Hoe het werkt</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">Bedrijf</h4>
            <ul className="space-y-3">
              <li><Link to="/over-ons" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Over ons</Link></li>
              <li><Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Contact</Link></li>
              <li><Link to="/shop" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Webshop</Link></li>
              <li><Link to="/boeken" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Online boeken</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-foreground mb-4">Support</h4>
            <ul className="space-y-3">
              <li><Link to="/contact" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Helpcentrum</Link></li>
              <li><Link to="/privacy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Privacybeleid</Link></li>
              <li><Link to="/voorwaarden" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Voorwaarden</Link></li>
              <li><Link to="/cookies" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Cookiebeleid</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border/50 mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-muted-foreground">© 2026 Sallopsy. Alle rechten voorbehouden.</p>
          <div className="flex items-center gap-6">
            <Link to="/privacy" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Privacy</Link>
            <Link to="/voorwaarden" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Voorwaarden</Link>
            <Link to="/cookies" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Cookies</Link>
            <Link to="/betaalmogelijkheden" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Betaalmogelijkheden</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}