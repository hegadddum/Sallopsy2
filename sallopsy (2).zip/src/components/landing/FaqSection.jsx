import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronDown, HelpCircle } from "lucide-react";

const faqs = [
  {
    q: "Hoe lang duurt het om Sallopsy in te stellen?",
    a: "De meeste salons zijn binnen 20-30 minuten volledig live. Je importeert je diensten, voegt medewerkers toe en deelt de boekingslink. Wij begeleiden je stap voor stap.",
  },
  {
    q: "Welke betaalmethoden worden ondersteund?",
    a: "Sallopsy ondersteunt alle gangbare betaalmethoden: iDEAL, Bancontact, Visa, Mastercard, American Express, Apple Pay, Google Pay, PayPal, Klarna en meer. Bekijk de volledige lijst op onze betaalmogelijkheden pagina.",
  },
  {
    q: "Kan ik Sallopsy gratis uitproberen?",
    a: "Ja! Je kunt Sallopsy 14 dagen volledig gratis proberen, zonder creditcard. Je hebt direct toegang tot alle functies inclusief webshop, boekingssysteem en analytics.",
  },
  {
    q: "Werkt Sallopsy ook voor meerdere medewerkers?",
    a: "Absoluut. Je kunt onbeperkt medewerkers toevoegen, elk met hun eigen agenda, takenpakket en kleurcode in de kalender. Ideaal voor grotere salons.",
  },
  {
    q: "Hoe werkt de online boekingspagina?",
    a: "Je krijgt een persoonlijke boekingslink (bijv. jouwnaam.sallopsy.nl/boeken). Klanten kiezen een dienst, datum en tijdstip, en de afspraak verschijnt direct in jouw dashboard. Klanten ontvangen automatisch een bevestigingsmail.",
  },
  {
    q: "Kan ik mijn eigen producten verkopen via de webshop?",
    a: "Ja. Via het Inventory-beheer voeg je producten toe met foto, prijs en voorraad. Ze verschijnen direct in de publieke webshop. Betalingen verlopen via Stripe of Mollie.",
  },
  {
    q: "Is mijn data veilig?",
    a: "Ja. Alle data wordt versleuteld opgeslagen in Europa (GDPR-compliant). Wij slaan nooit betaalgegevens op onze servers op — dat verloopt via gecertificeerde betalingsproviders met PCI DSS-certificering.",
  },
  {
    q: "Wat als ik stop met Sallopsy?",
    a: "Je kunt op elk moment opzeggen. Al je data (klanten, afspraken, producten) kun je exporteren als CSV of PDF. Geen lock-in, geen verborgen kosten.",
  },
  {
    q: "Is er een app beschikbaar?",
    a: "Sallopsy werkt volledig in je browser op telefoon, tablet en desktop. Er is geen aparte app nodig — de interface is geoptimaliseerd voor elk schermformaat.",
  },
  {
    q: "Bieden jullie ondersteuning aan?",
    a: "Ja. Alle pakketten bevatten e-mailondersteuning. Het Growth- en Premium-pakket bieden prioriteit chat-support. We hebben ook een uitgebreide kennisbank.",
  },
];

export default function FaqSection() {
  const [open, setOpen] = useState(null);

  return (
    <section id="faq" className="py-24 bg-secondary/30">
      <div className="max-w-3xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-semibold mb-6">
            <HelpCircle className="w-4 h-4" />
            Veelgestelde vragen
          </div>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Alles wat je wilt weten
          </h2>
          <p className="text-muted-foreground text-lg">
            Staat jouw vraag er niet bij? Neem dan contact met ons op via de contactpagina.
          </p>
        </motion.div>

        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
              className="bg-card border border-border rounded-2xl overflow-hidden"
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full text-left px-6 py-5 flex items-center justify-between gap-4 hover:bg-secondary/30 transition-colors"
              >
                <span className="font-semibold text-foreground text-sm sm:text-base">{faq.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-muted-foreground flex-shrink-0 transition-transform duration-200 ${open === i ? "rotate-180" : ""}`}
                />
              </button>
              <AnimatePresence>
                {open === i && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="px-6 pb-5 text-sm text-muted-foreground leading-relaxed border-t border-border/50 pt-4">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}