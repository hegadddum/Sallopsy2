import React from "react";
import { motion } from "framer-motion";
import {
  ShieldCheck, Lock, FileText, Bell, Eye, UserCheck,
  Server, RefreshCw, CheckCircle2
} from "lucide-react";

const pillars = [
  {
    icon: Lock,
    title: "End-to-end encryptie",
    desc: "Alle klant- en bedrijfsdata wordt AES-256 versleuteld opgeslagen én in transit (TLS 1.3).",
    color: "from-blue-500 to-indigo-600",
  },
  {
    icon: UserCheck,
    title: "Multi-factor authenticatie",
    desc: "MFA verplicht voor alle gebruikers. Geen account-toegang zonder tweede verificatiestap.",
    color: "from-emerald-500 to-teal-600",
  },
  {
    icon: Eye,
    title: "Audit logging",
    desc: "Elk login, elke datawijziging en elke export wordt gelogd met timestamp en gebruiker-ID.",
    color: "from-violet-500 to-purple-600",
  },
  {
    icon: Bell,
    title: "Incident notificatie",
    desc: "Bij een datalek wordt je binnen 24 uur geïnformeerd — conform NIS2 meldplicht (72u naar autoriteiten).",
    color: "from-amber-500 to-orange-600",
  },
  {
    icon: RefreshCw,
    title: "Business continuïteit",
    desc: "Dagelijkse back-ups, automatisch failover en een gedocumenteerd herstelplan (RTO < 4u).",
    color: "from-cyan-500 to-blue-600",
  },
  {
    icon: FileText,
    title: "GDPR & AVG compliant",
    desc: "Verwerkersovereenkomst, recht op inzage, correctie en verwijdering ingebouwd in het platform.",
    color: "from-rose-500 to-pink-600",
  },
  {
    icon: Server,
    title: "EU-datahosting",
    desc: "Alle data staat uitsluitend op ISO 27001-gecertificeerde servers in de Europese Unie.",
    color: "from-slate-500 to-gray-600",
  },
  {
    icon: ShieldCheck,
    title: "Toegangsbeheer (RBAC)",
    desc: "Rolgebaseerde rechten: medewerkers zien alleen wat ze nodig hebben. Zero-trust principe.",
    color: "from-lime-500 to-green-600",
  },
];

const badges = [
  "NIS2 Ready",
  "GDPR / AVG",
  "ISO 27001 hosting",
  "TLS 1.3",
  "AES-256",
  "EU Data Only",
];

export default function Nis2Section() {
  return (
    <section id="security" className="py-32 relative overflow-hidden bg-gradient-to-b from-background via-primary/[0.03] to-background">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-6"
        >
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">Cybersecurity & Compliance</span>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4">
            NIS2-proof van dag één
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            De EU NIS2-richtlijn verplicht bedrijven tot aantoonbare cyberbeveiliging.
            Sallopsy is gebouwd om aan alle eisen te voldoen — zodat jij je kunt focussen op je salon.
          </p>
        </motion.div>

        {/* Compliance badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="flex flex-wrap justify-center gap-3 mb-16"
        >
          {badges.map((b) => (
            <span
              key={b}
              className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-semibold text-primary"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              {b}
            </span>
          ))}
        </motion.div>

        {/* Pillars grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {pillars.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className="group bg-card rounded-2xl p-6 border border-border/50 hover:border-primary/20 hover:shadow-xl hover:shadow-primary/5 transition-all duration-500"
            >
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${p.color} flex items-center justify-center mb-4 shadow-md group-hover:scale-110 transition-transform duration-300`}>
                <p.icon className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-sm font-semibold text-foreground mb-2">{p.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{p.desc}</p>
            </motion.div>
          ))}
        </div>

        {/* NIS2 checklist banner */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-primary rounded-3xl p-8 sm:p-10 text-primary-foreground"
        >
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-white/10 rounded-full px-4 py-1.5 text-xs font-semibold mb-4">
                <ShieldCheck className="w-4 h-4 text-accent" />
                NIS2 Artikel 21 – Beveiligingsmaatregelen
              </div>
              <h3 className="font-display text-2xl sm:text-3xl font-bold mb-3">
                Voldoe aan alle NIS2-verplichtingen
              </h3>
              <p className="text-primary-foreground/80 text-sm leading-relaxed">
                Sallopsy dekt alle verplichte maatregelen uit NIS2 Artikel 21 af:
                risicoanalyse, incidentbeheer, bedrijfscontinuïteit, beveiliging van de toeleveringsketen,
                toegangsbeleid, encryptie en meldprocedures.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                "Risicoanalyse & beleid",
                "Incidentbeheer & meldplicht",
                "Bedrijfscontinuïteit (BCP)",
                "Supply chain beveiliging",
                "Encryptie in rust & transit",
                "MFA & toegangsbeleid",
                "Bewustzijnstraining medewerkers",
                "Regelmatige audits & tests",
              ].map((item) => (
                <div key={item} className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0" />
                  <span className="text-sm text-primary-foreground/90">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}