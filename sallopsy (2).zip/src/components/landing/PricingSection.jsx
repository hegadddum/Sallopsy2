import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, ArrowRight, Sparkles } from "lucide-react";

const plans = [
  {
    name: "Starter",
    price: "49",
    badge: "🟢",
    badgeColor: "bg-emerald-100 text-emerald-700",
    description: "Voor startende salons & zelfstandige barbers",
    features: [
      "Online afspraken boeken",
      "Realtime agenda",
      "Mobiele boekingspagina",
      "Automatische bevestigingen",
      "Basis CRM & klantgeschiedenis",
      "Stripe & Mollie betalingen",
      "Dag- & maandomzet dashboard",
      "E-mail support",
    ],
    cta: "Start gratis proefperiode",
    popular: false,
  },
  {
    name: "Growth",
    price: "149",
    badge: "🔵",
    badgeColor: "bg-blue-100 text-blue-700",
    description: "Voor salons die willen opschalen",
    features: [
      "Alles uit Starter",
      "Memberships & recurring revenue",
      "Automatische WhatsApp reminders",
      "Marketing automation flows",
      "Medewerkersaccounts & roosters",
      "Omzetanalyse & KPI inzichten",
      "AI aanbevelingen & upsells",
      "Priority support & onboarding",
    ],
    cta: "Start gratis proefperiode",
    popular: true,
  },
  {
    name: "Premium",
    price: "299",
    badge: "🟣",
    badgeColor: "bg-violet-100 text-violet-700",
    description: "Het complete Sallopsy platform",
    features: [
      "Alles uit Growth",
      "AI Business Assistant",
      "Predictive retention & pricing",
      "Multi-channel automation",
      "360° klantprofielen",
      "Multi-location ecosysteem",
      "White label mogelijkheden",
      "Dedicated accountmanager",
    ],
    cta: "Neem contact op",
    popular: false,
  },
];

export default function PricingSection() {
  return (
    <section id="pricing" className="py-32 bg-gradient-to-b from-background via-primary/[0.02] to-background">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <span className="text-sm font-semibold text-accent uppercase tracking-widest">Pakketten</span>
          <h2 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4">
            Kies jouw perfecte plan
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Van zelfstandige barber tot salonketen — er is een plan dat bij jou past.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`relative rounded-3xl p-8 transition-all duration-500 ${
                plan.popular
                  ? "bg-primary text-primary-foreground shadow-2xl shadow-primary/20 scale-[1.02] border-2 border-primary"
                  : "bg-card border border-border/50 hover:shadow-xl hover:shadow-black/5"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <Badge className="bg-accent text-accent-foreground px-4 py-1 text-sm font-semibold shadow-lg">
                    <Sparkles className="w-3.5 h-3.5 mr-1" />
                    Meest gekozen
                  </Badge>
                </div>
              )}

              <div className="mb-6">
                <span className="text-2xl">{plan.badge}</span>
                <h3 className="text-2xl font-bold mt-2">{plan.name}</h3>
                <p className={`text-sm mt-1 ${plan.popular ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                  {plan.description}
                </p>
              </div>

              <div className="mb-8">
                <span className="text-5xl font-bold">€{plan.price}</span>
                <span className={`text-sm ${plan.popular ? "text-primary-foreground/70" : "text-muted-foreground"}`}> /maand</span>
              </div>

              <ul className="space-y-3 mb-8">
                {plan.features.map((f, j) => (
                  <li key={j} className="flex items-start gap-3 text-sm">
                    <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.popular ? "text-accent" : "text-primary"}`} />
                    <span>{f}</span>
                  </li>
                ))}
              </ul>

              <Link to="/register">
                <Button
                  className={`w-full h-12 font-semibold ${
                    plan.popular
                      ? "bg-accent text-accent-foreground hover:bg-accent/90 shadow-lg"
                      : "bg-primary text-primary-foreground hover:bg-primary/90"
                  }`}
                >
                  {plan.cta}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}