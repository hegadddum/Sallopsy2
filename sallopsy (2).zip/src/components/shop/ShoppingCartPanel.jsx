import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, Plus, Minus, Trash2, ShoppingBag } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function ShoppingCartPanel({ cart, onClose, onRemoveItem, onUpdateQuantity, total }) {
  const [email, setEmail] = useState("");
  const [orderPlaced, setOrderPlaced] = useState(false);

  const handleOrder = () => {
    if (email && cart.length > 0) {
      // Here you would typically send the order to a backend
      setOrderPlaced(true);
      setTimeout(() => {
        onClose();
        setOrderPlaced(false);
      }, 3000);
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/50 z-40"
        onClick={onClose}
      />

      {/* Panel */}
      <div className="fixed right-0 top-0 h-full w-full sm:w-96 bg-card border-l border-border shadow-lg z-50 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="border-b border-border p-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">Winkelwagen</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {cart.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingBag className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
              <p className="text-muted-foreground">Je winkelwagen is leeg</p>
            </div>
          ) : (
            cart.map(item => (
              <Card key={item.product.id} className="p-3 border-border/50">
                <div className="flex gap-3">
                  {/* Product Image */}
                  <div className="w-20 h-20 bg-secondary/50 rounded flex items-center justify-center flex-shrink-0">
                    {item.product.image_url ? (
                      <img
                        src={item.product.image_url}
                        alt={item.product.name}
                        className="w-full h-full object-cover rounded"
                      />
                    ) : (
                      <ShoppingBag className="w-6 h-6 text-muted-foreground/30" />
                    )}
                  </div>

                  {/* Product Details */}
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm text-foreground truncate">
                      {item.product.name}
                    </h4>
                    <p className="text-sm text-primary font-semibold mt-1">
                      €{(item.product.price_sell * item.quantity).toFixed(2)}
                    </p>

                    {/* Quantity Controls */}
                    <div className="flex items-center gap-1 mt-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <span className="text-xs font-semibold w-6 text-center">
                        {item.quantity}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7"
                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-7 w-7 text-destructive ml-auto"
                        onClick={() => onRemoveItem(item.product.id)}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>

        {/* Footer */}
        {cart.length > 0 && (
          <div className="border-t border-border p-4 space-y-4">
            {orderPlaced && (
              <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-lg p-3 text-sm text-emerald-700 text-center">
                Bestelling geplaatst! ✓
              </div>
            )}

            <div>
              <label className="text-sm text-muted-foreground mb-2 block">
                Email voor bestelling
              </label>
              <Input
                type="email"
                placeholder="jouw@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="text-sm"
              />
            </div>

            <div className="bg-secondary/50 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-muted-foreground">Subtotaal:</span>
                <span className="font-semibold">€{total.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center mb-3">
                <span className="text-muted-foreground">Verzending:</span>
                <span className="font-semibold text-sm text-emerald-600">Gratis</span>
              </div>
              <div className="border-t border-border pt-2 flex justify-between items-center">
                <span className="font-semibold">Totaal:</span>
                <span className="text-2xl font-bold text-primary">€{total.toFixed(2)}</span>
              </div>
            </div>

            <Button
              onClick={handleOrder}
              disabled={cart.length === 0 || !email || orderPlaced}
              className="w-full"
              size="lg"
            >
              Plaats bestelling
            </Button>

            <Button
              variant="outline"
              onClick={onClose}
              className="w-full"
            >
              Verder winkelen
            </Button>
          </div>
        )}
      </div>
    </>
  );
}