import React from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Package } from "lucide-react";

export default function ShopProductCard({ product, onAddToCart }) {
  const stockStatus = product.stock > product.min_stock ? "in-stock" : "low-stock";
  const stockColor = stockStatus === "in-stock" ? "text-emerald-600" : "text-amber-600";

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-border/50 flex flex-col h-full">
      {/* Product Image Placeholder */}
      <div className="bg-gradient-to-br from-primary/10 to-accent/10 h-64 flex items-center justify-center overflow-hidden">
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <Package className="w-12 h-12 text-muted-foreground/30" />
        )}
      </div>

      {/* Product Info */}
      <div className="p-4 flex flex-col flex-grow">
        {/* Brand */}
        {product.brand && (
          <p className="text-xs text-muted-foreground font-semibold mb-1 uppercase tracking-wider">
            {product.brand}
          </p>
        )}

        {/* Name */}
        <h3 className="font-semibold text-foreground mb-2 line-clamp-2 h-14">
          {product.name}
        </h3>

        {/* Category & Stock */}
        <div className="flex items-center justify-between mb-3">
          <Badge variant="outline" className="text-xs">
            {product.category}
          </Badge>
          <span className={`text-xs font-semibold ${stockColor}`}>
            {product.stock} op voorraad
          </span>
        </div>

        {/* Price */}
        <div className="mb-4 flex-grow">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-primary">
              €{product.price_sell?.toFixed(2)}
            </span>
            {product.price_buy && product.price_buy < product.price_sell && (
              <span className="text-xs text-muted-foreground line-through">
                €{(product.price_sell * 1.2).toFixed(2)}
              </span>
            )}
          </div>
        </div>

        {/* Button */}
        <Button
          onClick={onAddToCart}
          disabled={product.stock === 0}
          className="w-full"
        >
          <ShoppingCart className="w-4 h-4 mr-2" />
          {product.stock === 0 ? "Niet beschikbaar" : "In wagen"}
        </Button>
      </div>
    </Card>
  );
}