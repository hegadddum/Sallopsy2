import React, { useMemo, useState } from "react";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend
} from "recharts";
import { format, subMonths } from "date-fns";
import { nl } from "date-fns/locale";
import { Euro, TrendingUp, Clock, Hash } from "lucide-react";

const DAYS = ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"];
const HOURS = Array.from({ length: 12 }, (_, i) => `${i + 8}:00`);

export default function MarketingChannels({ appointments, clients }) {
  const now = new Date();

  // Revenue per day of week
  const revenueByDay = useMemo(() => {
    const totals = Array(7).fill(0);
    const counts = Array(7).fill(0);
    appointments.filter(a => a.status === "voltooid").forEach(a => {
      if (!a.date) return;
      const day = new Date(a.date).getDay();
      totals[day] += a.price || 0;
      counts[day]++;
    });
    return DAYS.map((dag, i) => ({ dag, omzet: Math.round(totals[i]), afspraken: counts[i] }));
  }, [appointments]);

  // Bookings per hour
  const bookingsByHour = useMemo(() => {
    const counts = {};
    appointments.forEach(a => {
      if (!a.time) return;
      const h = a.time.split(":")[0] + ":00";
      counts[h] = (counts[h] || 0) + 1;
    });
    return HOURS.map(h => ({ uur: h, boekingen: counts[h] || 0 }));
  }, [appointments]);

  // Monthly avg order value trend
  const avgOrderTrend = useMemo(() => {
    return Array.from({ length: 6 }, (_, i) => {
      const d = subMonths(now, 5 - i);
      const key = format(d, "yyyy-MM");
      const completed = appointments.filter(a => a.date?.startsWith(key) && a.status === "voltooid");
      const revenue = completed.reduce((s, a) => s + (a.price || 0), 0);
      const avg = completed.length > 0 ? Math.round(revenue / completed.length) : 0;
      return { maand: format(d, "MMM", { locale: nl }), gem: avg, omzet: Math.round(revenue) };
    });
  }, [appointments]);

  // Staff performance
  const staffStats = useMemo(() => {
    const stats = {};
    appointments.filter(a => a.staff_member && a.status === "voltooid").forEach(a => {
      if (!stats[a.staff_member]) stats[a.staff_member] = { naam: a.staff_member, omzet: 0, afspraken: 0 };
      stats[a.staff_member].omzet += a.price || 0;
      stats[a.staff_member].afspraken++;
    });
    return Object.values(stats).sort((a, b) => b.omzet - a.omzet);
  }, [appointments]);

  const totalRevenue = appointments.filter(a => a.status === "voltooid").reduce((s, a) => s + (a.price || 0), 0);
  const completedCount = appointments.filter(a => a.status === "voltooid").length;
  const avgOrderValue = completedCount > 0 ? Math.round(totalRevenue / completedCount) : 0;
  const peakDay = revenueByDay.reduce((max, d) => d.omzet > max.omzet ? d : max, revenueByDay[0]);
  const peakHour = bookingsByHour.reduce((max, h) => h.boekingen > max.boekingen ? h : max, bookingsByHour[0]);

  const CustomTooltip = ({ active, payload, label }) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-card border border-border rounded-xl px-3 py-2 shadow-lg text-sm">
        <p className="text-muted-foreground text-xs mb-1">{label}</p>
        {payload.map((p, i) => (
          <p key={i} className="font-semibold" style={{ color: p.color }}>
            {p.name}: {p.dataKey === "omzet" || p.dataKey === "gem" ? "€" : ""}{p.value?.toLocaleString("nl-NL")}
          </p>
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Summary stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Totale omzet", value: `€${totalRevenue.toLocaleString("nl-NL")}`, icon: Euro, color: "text-primary bg-primary/10" },
          { label: "Gem. orderbedrag", value: `€${avgOrderValue}`, icon: TrendingUp, color: "text-emerald-600 bg-emerald-100" },
          { label: "Drukste dag", value: peakDay?.dag || "—", icon: Hash, color: "text-amber-600 bg-amber-100" },
          { label: "Drukste uur", value: peakHour?.uur || "—", icon: Clock, color: "text-violet-600 bg-violet-100" },
        ].map((s) => (
          <div key={s.label} className="bg-card rounded-2xl border border-border/50 p-5">
            <div className={`w-10 h-10 rounded-xl ${s.color} flex items-center justify-center mb-3`}>
              <s.icon className="w-5 h-5" />
            </div>
            <p className="text-2xl font-bold text-foreground">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue by day of week */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Omzet per weekdag</h3>
          <p className="text-xs text-muted-foreground mb-5">Welke dag brengt de meeste omzet op</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={revenueByDay}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,92%)" />
              <XAxis dataKey="dag" tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" tickFormatter={v => `€${v}`} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="omzet" fill="hsl(230,65%,28%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Bookings per hour */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Boekingen per uur</h3>
          <p className="text-xs text-muted-foreground mb-5">Op welke tijden klanten het meest boeken</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={bookingsByHour}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,92%)" />
              <XAxis dataKey="uur" tick={{ fontSize: 10 }} stroke="hsl(220,10%,65%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="boekingen" fill="hsl(38,92%,50%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Avg order trend */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Gem. orderbedrag trend</h3>
          <p className="text-xs text-muted-foreground mb-5">Ontwikkeling gemiddelde besteding per maand</p>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={avgOrderTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,92%)" />
              <XAxis dataKey="maand" tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" tickFormatter={v => `€${v}`} />
              <Tooltip content={<CustomTooltip />} />
              <Line type="monotone" dataKey="gem" name="Gem. order" stroke="hsl(160,60%,45%)" strokeWidth={2.5} dot={{ r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Staff performance */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Medewerker prestaties</h3>
          <p className="text-xs text-muted-foreground mb-5">Omzet en afspraken per medewerker</p>
          {staffStats.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-10">Geen medewerkergegevens beschikbaar</p>
          ) : (
            <div className="space-y-3">
              {staffStats.map((s, i) => (
                <div key={s.naam} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center text-xs font-bold text-primary flex-shrink-0">
                    #{i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-foreground">{s.naam}</span>
                      <span className="text-sm font-bold text-primary">€{s.omzet.toLocaleString("nl-NL")}</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${(s.omzet / staffStats[0].omzet) * 100}%` }}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.afspraken} afspraken</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}