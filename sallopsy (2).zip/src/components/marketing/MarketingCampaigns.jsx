import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Send, Plus, Users, Mail, Star, Clock, CheckCircle2, Loader2, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

const SEGMENTS = [
  { value: "all", label: "Alle klanten", icon: Users },
  { value: "vip", label: "VIP klanten", icon: Star },
  { value: "inactive", label: "Inactieve klanten", icon: Clock },
  { value: "active", label: "Actieve klanten", icon: CheckCircle2 },
];

const EMAIL_TEMPLATES = [
  {
    label: "Welkomstkorting",
    subject: "Welkom bij Sallopsy – Jouw eerste bezoek met korting!",
    body: "Beste {naam},\n\nWelkom bij Sallopsy! Als nieuwe klant ontvang je 10% korting op je volgende behandeling.\n\nBoek snel via onze app of bel ons op.\n\nWarm welkom,\nHet team van Sallopsy",
  },
  {
    label: "Terugkomactie",
    subject: "We missen je! Speciaal aanbod voor jou",
    body: "Beste {naam},\n\nWe hebben je al een tijdje niet gezien en dat vinden we zonde! Als welkomstgeschenk krijg jij bij je volgende bezoek een gratis behandeling naar keuze.\n\nBel of boek online — wij zien je graag terug!\n\nMet vriendelijke groet,\nSallopsy",
  },
  {
    label: "Seizoensaanbieding",
    subject: "🌸 Zomeractie – Speciaal voor onze vaste klanten",
    body: "Beste {naam},\n\nDe zomer is in aantocht en dat vieren we! Profiteer deze maand van onze speciale zomeraanbiedingen.\n\n✨ 15% korting op alle kleurbehandelingen\n✨ Gratis hoofdmassage bij elke knipbeurt\n\nGeldig t/m 31 juli. Reserveer nu!\n\nMet zonnige groeten,\nHet Sallopsy team",
  },
];

const WHATSAPP_TEMPLATES = [
  {
    label: "Welkomstkorting",
    body: "Hoi {naam}! 👋 Welkom bij *Sallopsy*! Als nieuwe klant krijg je *10% korting* op je eerste behandeling. Boek snel een afspraak! 💇‍♀️",
  },
  {
    label: "Terugkomactie",
    body: "Hoi {naam}! 😊 We missen je bij *Sallopsy*! Kom terug en ontvang een *gratis behandeling* naar keuze. Bel of app ons voor een afspraak! ✨",
  },
  {
    label: "Seizoensaanbieding",
    body: "Hoi {naam}! 🌸 *Zomeractie bij Sallopsy!*\n\n✨ 15% korting op kleurbehandelingen\n✨ Gratis hoofdmassage bij knipbeurt\n\nGeldig t/m 31 juli. Reserveer nu! 📅",
  },
];

const WA_SEGMENT_DESCS = {
  all: "Alle klanten met een telefoonnummer",
  vip: "Alleen VIP-klanten met een telefoonnummer",
  inactive: "Inactieve klanten met een telefoonnummer",
  active: "Actieve klanten met een telefoonnummer",
};

const EMAIL_SEGMENT_DESCS = {
  all: "Alle klanten met een e-mailadres",
  vip: "Alleen VIP-klanten met een e-mailadres",
  inactive: "Inactieve klanten met een e-mailadres",
  active: "Actieve klanten met een e-mailadres",
};

export default function MarketingCampaigns({ clients }) {
  const [channel, setChannel] = useState("email");
  const [showCompose, setShowCompose] = useState(false);
  const [segment, setSegment] = useState("all");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [sending, setSending] = useState(false);
  const [lastSent, setLastSent] = useState(null); // { count, channel }

  const getEmailClients = (seg) => {
    const base = seg === "vip" ? clients.filter(c => c.status === "vip")
      : seg === "inactive" ? clients.filter(c => c.status === "inactive")
      : seg === "active" ? clients.filter(c => c.status === "active")
      : clients;
    return base.filter(c => c.email);
  };

  const getWaClients = (seg) => {
    const base = seg === "vip" ? clients.filter(c => c.status === "vip")
      : seg === "inactive" ? clients.filter(c => c.status === "inactive")
      : seg === "active" ? clients.filter(c => c.status === "active")
      : clients;
    return base.filter(c => c.phone);
  };

  const getTargetClients = (seg) => channel === "email" ? getEmailClients(seg) : getWaClients(seg);
  const targetClients = getTargetClients(segment);
  const templates = channel === "email" ? EMAIL_TEMPLATES : WHATSAPP_TEMPLATES;

  const openCompose = (seg = "all", ch = channel) => {
    setChannel(ch);
    setSegment(seg);
    setSubject("");
    setBody("");
    setShowCompose(true);
  };

  const applyTemplate = (t) => {
    if (t.subject !== undefined) setSubject(t.subject);
    setBody(t.body);
  };

  const handleSend = async () => {
    if (channel === "email" && (!subject || !body)) return toast.error("Vul onderwerp en bericht in");
    if (channel === "whatsapp" && !body) return toast.error("Vul het bericht in");
    if (targetClients.length === 0) return toast.error(`Geen klanten met ${channel === "email" ? "e-mailadres" : "telefoonnummer"} in dit segment`);

    setSending(true);
    let sent = 0;

    if (channel === "email") {
      for (const client of targetClients) {
        const personalizedBody = body.replace(/\{naam\}/g, client.first_name || "klant");
        await base44.integrations.Core.SendEmail({
          to: client.email,
          subject,
          from_name: "Sallopsy",
          body: personalizedBody,
        });
        sent++;
      }
    } else {
      // WhatsApp: open wa.me links in bulk (browser-based approach)
      for (const client of targetClients) {
        const personalizedMsg = body.replace(/\{naam\}/g, client.first_name || "klant");
        const phone = client.phone.replace(/\D/g, "");
        const url = `https://wa.me/${phone}?text=${encodeURIComponent(personalizedMsg)}`;
        window.open(url, "_blank");
        sent++;
        // small delay to avoid popup blockers blocking all
        await new Promise(r => setTimeout(r, 400));
      }
    }

    setSending(false);
    setLastSent({ count: sent, channel });
    setShowCompose(false);
    toast.success(`Campagne gestart voor ${sent} klanten!`);
  };

  return (
    <div className="space-y-6">
      {/* Header with channel toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold text-foreground">Campagnes</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Stuur gerichte berichten via e-mail of WhatsApp</p>
        </div>
        <div className="flex items-center gap-3">
          <Tabs value={channel} onValueChange={(v) => setChannel(v)}>
            <TabsList>
              <TabsTrigger value="email" className="gap-1.5 text-xs">
                <Mail className="w-3.5 h-3.5" /> E-mail
              </TabsTrigger>
              <TabsTrigger value="whatsapp" className="gap-1.5 text-xs">
                <MessageCircle className="w-3.5 h-3.5 text-green-500" /> WhatsApp
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <Button size="sm" onClick={() => openCompose("all", channel)}>
            <Plus className="w-4 h-4 mr-1" /> Nieuwe campagne
          </Button>
        </div>
      </div>

      {/* Success banner */}
      {lastSent && (
        <div className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-50 border border-emerald-200">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <p className="text-sm font-medium text-emerald-800">
            Laatste {lastSent.channel === "email" ? "e-mailcampagne" : "WhatsApp-campagne"} gestart voor {lastSent.count} klanten
          </p>
        </div>
      )}

      {/* WhatsApp info banner */}
      {channel === "whatsapp" && (
        <div className="flex items-start gap-3 p-4 rounded-2xl bg-green-50 border border-green-200">
          <MessageCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-green-800">WhatsApp campagnes</p>
            <p className="text-xs text-green-700 mt-0.5">Voor elke klant wordt een WhatsApp-venster geopend met het gepersonaliseerde bericht. Zorg dat je browser pop-ups toestaat voor deze pagina.</p>
          </div>
        </div>
      )}

      {/* Segment cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {SEGMENTS.map((seg) => {
          const count = getTargetClients(seg.value).length;
          const desc = channel === "email" ? EMAIL_SEGMENT_DESCS[seg.value] : WA_SEGMENT_DESCS[seg.value];
          return (
            <div
              key={seg.value}
              className="bg-card rounded-2xl border border-border/50 p-5 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
              onClick={() => openCompose(seg.value, channel)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${channel === "whatsapp" ? "bg-green-100" : "bg-primary/10"}`}>
                  <seg.icon className={`w-5 h-5 ${channel === "whatsapp" ? "text-green-600" : "text-primary"}`} />
                </div>
                <Badge variant="secondary" className="text-xs">{count} klanten</Badge>
              </div>
              <h4 className="text-sm font-semibold text-foreground">{seg.label}</h4>
              <p className="text-xs text-muted-foreground mt-1">{desc}</p>
              <Button size="sm" variant="outline" className="mt-3 h-8 text-xs w-full">
                {channel === "whatsapp"
                  ? <><MessageCircle className="w-3 h-3 mr-1 text-green-500" /> WhatsApp starten</>
                  : <><Mail className="w-3 h-3 mr-1" /> E-mail starten</>
                }
              </Button>
            </div>
          );
        })}
      </div>

      {/* Templates */}
      <div className="bg-card rounded-2xl border border-border/50 p-6">
        <h3 className="text-base font-semibold text-foreground mb-1">
          {channel === "email" ? "E-mail templates" : "WhatsApp templates"}
        </h3>
        <p className="text-xs text-muted-foreground mb-4">Gebruik een kant-en-klare template als startpunt</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {templates.map((t) => (
            <div
              key={t.label}
              className="p-4 rounded-xl border border-border/50 bg-muted/30 hover:bg-muted/60 cursor-pointer transition-colors"
              onClick={() => { applyTemplate(t); setShowCompose(true); }}
            >
              <p className="text-sm font-semibold text-foreground mb-1">{t.label}</p>
              <p className="text-xs text-muted-foreground line-clamp-2">{t.body.split("\n")[0]}</p>
              <Button size="sm" variant="ghost" className="mt-2 h-7 text-xs px-2">Gebruiken →</Button>
            </div>
          ))}
        </div>
      </div>

      {/* Compose dialog */}
      <Dialog open={showCompose} onOpenChange={setShowCompose}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display text-xl flex items-center gap-2">
              {channel === "whatsapp"
                ? <><MessageCircle className="w-5 h-5 text-green-500" /> Nieuwe WhatsApp-campagne</>
                : <><Mail className="w-5 h-5 text-primary" /> Nieuwe e-mailcampagne</>
              }
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-1">
            {/* Channel toggle inside dialog */}
            <div className="space-y-1.5">
              <Label>Kanaal</Label>
              <Tabs value={channel} onValueChange={setChannel}>
                <TabsList className="w-full">
                  <TabsTrigger value="email" className="flex-1 gap-1.5 text-xs">
                    <Mail className="w-3.5 h-3.5" /> E-mail
                  </TabsTrigger>
                  <TabsTrigger value="whatsapp" className="flex-1 gap-1.5 text-xs">
                    <MessageCircle className="w-3.5 h-3.5 text-green-500" /> WhatsApp
                  </TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            <div className="space-y-1.5">
              <Label>Doelgroep</Label>
              <Select value={segment} onValueChange={setSegment}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SEGMENTS.map(s => (
                    <SelectItem key={s.value} value={s.value}>
                      {s.label} ({getTargetClients(s.value).length} klanten)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {targetClients.length} klanten ontvangen dit bericht
              </p>
            </div>

            {/* Template picker */}
            <div className="space-y-1.5">
              <Label>Template</Label>
              <div className="flex flex-wrap gap-2">
                {templates.map(t => (
                  <Button key={t.label} size="sm" variant="outline" className="h-7 text-xs" onClick={() => applyTemplate(t)}>
                    {t.label}
                  </Button>
                ))}
              </div>
            </div>

            {channel === "email" && (
              <div className="space-y-1.5">
                <Label>Onderwerp *</Label>
                <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="bijv. Speciale aanbieding voor jou!" />
              </div>
            )}

            <div className="space-y-1.5">
              <Label>Bericht *</Label>
              <Textarea
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder={channel === "whatsapp"
                  ? "Hoi {naam}! 👋 Schrijf hier je WhatsApp-bericht..."
                  : "Schrijf hier je bericht... Gebruik {naam} voor persoonlijke aanpassing."
                }
                rows={7}
              />
              <p className="text-xs text-muted-foreground">
                Tip: gebruik <code className="bg-muted px-1 rounded">{"{naam}"}</code> voor automatische personalisatie
              </p>
            </div>

            <div className="flex justify-end gap-3 pt-1">
              <Button variant="outline" onClick={() => setShowCompose(false)}>Annuleren</Button>
              <Button
                onClick={handleSend}
                disabled={sending || targetClients.length === 0}
                className={channel === "whatsapp" ? "bg-green-600 hover:bg-green-700 text-white" : ""}
              >
                {sending
                  ? <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  : channel === "whatsapp"
                    ? <MessageCircle className="w-4 h-4 mr-2" />
                    : <Send className="w-4 h-4 mr-2" />
                }
                {sending ? "Bezig..." : `Versturen naar ${targetClients.length} klanten`}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}