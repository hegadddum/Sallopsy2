import React, { useMemo } from "react";
import { TrendingUp, TrendingDown, Users, Euro, Repeat, Star } from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend
} from "recharts";
import { format, subMonths, startOfMonth, endOfMonth } from "date-fns";
import { nl } from "date-fns/locale";

const COLORS = ["hsl(230,65%,28%)", "hsl(38,92%,50%)", "hsl(160,60%,45%)", "hsl(280,65%,60%)", "hsl(340,75%,55%)"];

const CustomTooltip = ({ active, payload, label, prefix = "€" }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-xl px-3 py-2 shadow-lg text-sm">
      <p className="text-muted-foreground text-xs mb-1">{label}</p>
      {payload.map((p, i) => (
        <p key={i} className="font-semibold" style={{ color: p.color }}>
          {prefix}{typeof p.value === "number" ? p.value.toLocaleString("nl-NL") : p.value}
        </p>
      ))}
    </div>
  );
};

export default function MarketingOverview({ appointments, clients, loyaltyTx }) {
  const now = new Date();

  const monthlyData = useMemo(() => {
    return Array.from({ length: 6 }, (_, i) => {
      const d = subMonths(now, 5 - i);
      const key = format(d, "yyyy-MM");
      const label = format(d, "MMM", { locale: nl });
      const appts = appointments.filter(a => a.date?.startsWith(key));
      const completed = appts.filter(a => a.status === "voltooid");
      const revenue = completed.reduce((s, a) => s + (a.price || 0), 0);
      const newClients = clients.filter(c => c.created_date?.startsWith(key)).length;
      return { label, omzet: revenue, afspraken: appts.length, nieuw: newClients, voltooid: completed.length };
    });
  }, [appointments, clients]);

  const thisMonth = format(now, "yyyy-MM");
  const lastMonth = format(subMonths(now, 1), "yyyy-MM");

  const thisRevenue = appointments.filter(a => a.date?.startsWith(thisMonth) && a.status === "voltooid").reduce((s, a) => s + (a.price || 0), 0);
  const lastRevenue = appointments.filter(a => a.date?.startsWith(lastMonth) && a.status === "voltooid").reduce((s, a) => s + (a.price || 0), 0);
  const revenueGrowth = lastRevenue > 0 ? ((thisRevenue - lastRevenue) / lastRevenue * 100).toFixed(1) : 0;

  const thisNewClients = clients.filter(c => c.created_date?.startsWith(thisMonth)).length;
  const lastNewClients = clients.filter(c => c.created_date?.startsWith(lastMonth)).length;
  const clientGrowth = lastNewClients > 0 ? ((thisNewClients - lastNewClients) / lastNewClients * 100).toFixed(1) : 0;

  const completedAll = appointments.filter(a => a.status === "voltooid");
  const uniqueClientIds = new Set(completedAll.map(a => a.client_id).filter(Boolean));
  const returningClients = [...uniqueClientIds].filter(id => completedAll.filter(a => a.client_id === id).length > 1).length;
  const retentionRate = uniqueClientIds.size > 0 ? ((returningClients / uniqueClientIds.size) * 100).toFixed(0) : 0;

  const vipCount = clients.filter(c => c.status === "vip").length;

  // Service popularity
  const serviceCounts = appointments.reduce((acc, a) => {
    if (a.service_name) acc[a.service_name] = (acc[a.service_name] || 0) + 1;
    return acc;
  }, {});
  const serviceData = Object.entries(serviceCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([name, value]) => ({ name: name.length > 18 ? name.slice(0, 18) + "…" : name, value }));

  const kpis = [
    { label: "Omzet deze maand", value: `€${thisRevenue.toLocaleString("nl-NL")}`, change: revenueGrowth, icon: Euro, color: "text-primary bg-primary/10" },
    { label: "Nieuwe klanten", value: thisNewClients, change: clientGrowth, icon: Users, color: "text-emerald-600 bg-emerald-100" },
    { label: "Retentiegraad", value: `${retentionRate}%`, icon: Repeat, color: "text-violet-600 bg-violet-100" },
    { label: "VIP klanten", value: vipCount, icon: Star, color: "text-amber-600 bg-amber-100" },
  ];

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => {
          const isPositive = parseFloat(kpi.change) >= 0;
          return (
            <div key={kpi.label} className="bg-card rounded-2xl border border-border/50 p-5">
              <div className={`w-10 h-10 rounded-xl ${kpi.color} flex items-center justify-center mb-3`}>
                <kpi.icon className="w-5 h-5" />
              </div>
              <p className="text-2xl font-bold text-foreground">{kpi.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5 mb-2">{kpi.label}</p>
              {kpi.change !== undefined && (
                <div className={`inline-flex items-center gap-1 text-xs font-medium ${isPositive ? "text-emerald-600" : "text-red-500"}`}>
                  {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {isPositive ? "+" : ""}{kpi.change}% t.o.v. vorige maand
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue trend */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Omzettrend</h3>
          <p className="text-xs text-muted-foreground mb-5">Afgelopen 6 maanden</p>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyData}>
              <defs>
                <linearGradient id="omzetGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(230,65%,28%)" stopOpacity={0.25} />
                  <stop offset="95%" stopColor="hsl(230,65%,28%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,92%)" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" tickFormatter={v => `€${v}`} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="omzet" stroke="hsl(230,65%,28%)" strokeWidth={2.5} fill="url(#omzetGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* New clients + appointments bar */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Groei per maand</h3>
          <p className="text-xs text-muted-foreground mb-5">Nieuwe klanten & afspraken</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthlyData} barGap={4}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,92%)" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <Tooltip content={<CustomTooltip prefix="" />} />
              <Bar dataKey="nieuw" name="Nieuwe klanten" fill="hsl(160,60%,45%)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="afspraken" name="Afspraken" fill="hsl(230,65%,28%)" radius={[4, 4, 0, 0]} opacity={0.7} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Service popularity */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Populairste diensten</h3>
          <p className="text-xs text-muted-foreground mb-5">Op basis van alle afspraken</p>
          {serviceData.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-10">Nog geen data</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={serviceData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                  {serviceData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => [`${v} afspraken`]} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Conversion funnel */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Conversietrechter</h3>
          <p className="text-xs text-muted-foreground mb-5">Afspraken pipeline</p>
          {(() => {
            const total = appointments.length || 1;
            const statuses = [
              { label: "Gepland", count: appointments.filter(a => a.status === "gepland").length, color: "bg-blue-500" },
              { label: "Bevestigd", count: appointments.filter(a => a.status === "bevestigd").length, color: "bg-emerald-500" },
              { label: "Voltooid", count: appointments.filter(a => a.status === "voltooid").length, color: "bg-primary" },
              { label: "Geannuleerd", count: appointments.filter(a => a.status === "geannuleerd").length, color: "bg-red-400" },
              { label: "No-show", count: appointments.filter(a => a.status === "no_show").length, color: "bg-amber-400" },
            ];
            return (
              <div className="space-y-3">
                {statuses.map((s) => (
                  <div key={s.label}>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-foreground font-medium">{s.label}</span>
                      <span className="text-muted-foreground">{s.count} ({((s.count / total) * 100).toFixed(0)}%)</span>
                    </div>
                    <div className="h-2.5 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full ${s.color} rounded-full transition-all`} style={{ width: `${(s.count / total) * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>
      </div>
    </div>
  );
}