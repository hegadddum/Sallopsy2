import React, { useMemo } from "react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Clock, AlertCircle, CheckCircle2, TrendingUp } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from "recharts";
import { format, subDays, differenceInDays } from "date-fns";
import { nl } from "date-fns/locale";

export default function MarketingRetention({ appointments, clients }) {
  const now = new Date();

  // Visit frequency buckets
  const clientStats = useMemo(() => {
    return clients.map(c => {
      const clientAppts = appointments
        .filter(a => a.client_id === c.id && a.status === "voltooid")
        .sort((a, b) => new Date(b.date) - new Date(a.date));

      const visitCount = clientAppts.length;
      const lastVisit = clientAppts[0]?.date ? new Date(clientAppts[0].date) : null;
      const daysSince = lastVisit ? differenceInDays(now, lastVisit) : null;
      const totalSpent = clientAppts.reduce((s, a) => s + (a.price || 0), 0);

      let risk = "nieuw";
      if (visitCount > 0) {
        if (daysSince <= 30) risk = "actief";
        else if (daysSince <= 60) risk = "risico";
        else risk = "inactief";
      }

      return { ...c, visitCount, lastVisit, daysSince, totalSpent, risk };
    });
  }, [clients, appointments]);

  const riskCounts = {
    actief: clientStats.filter(c => c.risk === "actief").length,
    risico: clientStats.filter(c => c.risk === "risico").length,
    inactief: clientStats.filter(c => c.risk === "inactief").length,
    nieuw: clientStats.filter(c => c.risk === "nieuw").length,
  };

  // Avg days between visits per client
  const avgIntervals = useMemo(() => {
    const buckets = { "1-7 dagen": 0, "8-14 dagen": 0, "15-30 dagen": 0, "31-60 dagen": 0, "60+ dagen": 0 };
    clientStats.forEach(c => {
      if (c.daysSince === null) return;
      if (c.daysSince <= 7) buckets["1-7 dagen"]++;
      else if (c.daysSince <= 14) buckets["8-14 dagen"]++;
      else if (c.daysSince <= 30) buckets["15-30 dagen"]++;
      else if (c.daysSince <= 60) buckets["31-60 dagen"]++;
      else buckets["60+ dagen"]++;
    });
    return Object.entries(buckets).map(([label, count]) => ({ label, count }));
  }, [clientStats]);

  const riskConfig = {
    actief: { color: "bg-emerald-100 text-emerald-700", label: "Actief (< 30 dagen)", icon: CheckCircle2, iconColor: "text-emerald-500" },
    risico: { color: "bg-amber-100 text-amber-700", label: "Risico (31-60 dagen)", icon: AlertCircle, iconColor: "text-amber-500" },
    inactief: { color: "bg-red-100 text-red-700", label: "Inactief (60+ dagen)", icon: Clock, iconColor: "text-red-500" },
    nieuw: { color: "bg-blue-100 text-blue-700", label: "Nieuw (geen bezoek)", icon: TrendingUp, iconColor: "text-blue-500" },
  };

  const atRiskClients = clientStats.filter(c => c.risk === "risico" || c.risk === "inactief").slice(0, 8);

  return (
    <div className="space-y-6">
      {/* Risk summary */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Object.entries(riskConfig).map(([key, cfg]) => (
          <div key={key} className="bg-card rounded-2xl border border-border/50 p-5">
            <div className="flex items-center gap-2 mb-3">
              <cfg.icon className={`w-5 h-5 ${cfg.iconColor}`} />
              <span className="text-xs text-muted-foreground">{cfg.label}</span>
            </div>
            <p className="text-3xl font-bold text-foreground">{riskCounts[key]}</p>
            <p className="text-xs text-muted-foreground mt-1">klanten</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Visit recency chart */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Laatste bezoek verdeling</h3>
          <p className="text-xs text-muted-foreground mb-5">Hoeveel dagen geleden klanten voor het laatst kwamen</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={avgIntervals}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,92%)" />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} stroke="hsl(220,10%,65%)" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(220,10%,65%)" />
              <Tooltip formatter={(v) => [`${v} klanten`]} />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {avgIntervals.map((_, i) => (
                  <Cell key={i} fill={["hsl(160,60%,45%)", "hsl(160,60%,45%)", "hsl(38,92%,50%)", "hsl(340,75%,55%)", "hsl(0,70%,55%)"][i]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* At-risk clients list */}
        <div className="bg-card rounded-2xl border border-border/50 p-6">
          <h3 className="text-base font-semibold text-foreground mb-1">Klanten die teruggewonnen moeten worden</h3>
          <p className="text-xs text-muted-foreground mb-4">Risico & inactieve klanten</p>
          {atRiskClients.length === 0 ? (
            <div className="text-center py-10">
              <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-400 mb-2" />
              <p className="text-sm text-muted-foreground">Alle klanten zijn recent actief!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {atRiskClients.map((c) => {
                const initials = `${(c.first_name || "")[0] || ""}${(c.last_name || "")[0] || ""}`.toUpperCase();
                const cfg = riskConfig[c.risk];
                return (
                  <div key={c.id} className="flex items-center gap-3">
                    <Avatar className="w-9 h-9 flex-shrink-0">
                      <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">{initials}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{c.first_name} {c.last_name || ""}</p>
                      <p className="text-xs text-muted-foreground">
                        {c.daysSince !== null ? `${c.daysSince} dagen geleden` : "Nog nooit bezocht"} · {c.visitCount} bezoeken
                      </p>
                    </div>
                    <Badge className={`text-xs ${cfg.color} border-0`}>{c.risk}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Top clients by value */}
      <div className="bg-card rounded-2xl border border-border/50 p-6">
        <h3 className="text-base font-semibold text-foreground mb-1">Top klanten op omzet</h3>
        <p className="text-xs text-muted-foreground mb-5">Meest waardevolle klanten (afgeronde afspraken)</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {clientStats
            .filter(c => c.totalSpent > 0)
            .sort((a, b) => b.totalSpent - a.totalSpent)
            .slice(0, 6)
            .map((c, i) => {
              const initials = `${(c.first_name || "")[0] || ""}${(c.last_name || "")[0] || ""}`.toUpperCase();
              return (
                <div key={c.id} className="flex items-center gap-3 p-3 rounded-xl bg-muted/40">
                  <span className="text-sm font-bold text-muted-foreground w-5">#{i + 1}</span>
                  <Avatar className="w-9 h-9 flex-shrink-0">
                    <AvatarFallback className="bg-primary/10 text-primary text-xs font-semibold">{initials}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{c.first_name} {c.last_name || ""}</p>
                    <p className="text-xs text-muted-foreground">{c.visitCount} bezoeken</p>
                  </div>
                  <p className="text-sm font-bold text-primary flex-shrink-0">€{c.totalSpent.toLocaleString("nl-NL")}</p>
                </div>
              );
            })}
        </div>
      </div>
    </div>
  );
}