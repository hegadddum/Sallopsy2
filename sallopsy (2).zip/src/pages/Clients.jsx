import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle
} from "@/components/ui/dialog";
import { Plus, Search, Users, MoreHorizontal, Pencil, Trash2, Phone, Mail, Star, Send, Eye, Download, Loader2 } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Link } from "react-router-dom";
import ClientForm from "@/components/clients/ClientForm";

const statusConfig = {
  active: { label: "Actief", color: "bg-emerald-100 text-emerald-700" },
  inactive: { label: "Inactief", color: "bg-muted text-muted-foreground" },
  vip: { label: "VIP", color: "bg-amber-100 text-amber-700" },
};

export default function Clients() {
  const [showForm, setShowForm] = useState(false);
  const [editingClient, setEditingClient] = useState(null);
  const [search, setSearch] = useState("");
  const [exporting, setExporting] = useState(false);
  const queryClient = useQueryClient();

  const handleExport = async () => {
    setExporting(true);
    const response = await base44.functions.invoke('exportReport', { type: 'clients', period: 'all' });
    const blob = new Blob([response.data], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'klanten-rapport.pdf';
    a.click();
    URL.revokeObjectURL(url);
    setExporting(false);
  };

  const { data: clients = [], isLoading } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list("-created_date", 200),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Client.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["clients"] }); setShowForm(false); },
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Client.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["clients"] }); setShowForm(false); setEditingClient(null); },
  });
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Client.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["clients"] }),
  });

  const handleSave = async (data) => {
    if (editingClient) {
      await updateMutation.mutateAsync({ id: editingClient.id, data });
    } else {
      await createMutation.mutateAsync(data);
    }
  };

  const filtered = clients.filter((c) => {
    const name = `${c.first_name} ${c.last_name || ""}`.toLowerCase();
    return name.includes(search.toLowerCase()) || (c.phone || "").includes(search);
  });

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Klanten</h1>
          <p className="text-muted-foreground mt-1">{clients.length} klanten in totaal</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleExport} disabled={exporting}>
            {exporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
            Exporteren
          </Button>
          <Button onClick={() => { setEditingClient(null); setShowForm(true); }} className="bg-primary">
            <Plus className="w-4 h-4 mr-2" /> Klant toevoegen
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Zoek op naam of telefoon..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="bg-card rounded-2xl border border-border/50 p-6 animate-pulse">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-muted rounded-full" />
                <div className="space-y-2">
                  <div className="h-4 w-24 bg-muted rounded" />
                  <div className="h-3 w-32 bg-muted rounded" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Users className="w-16 h-16 mx-auto mb-4 text-muted-foreground/20" />
          <p className="text-muted-foreground">Geen klanten gevonden</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((client) => {
            const initials = `${(client.first_name || "")[0] || ""}${(client.last_name || "")[0] || ""}`.toUpperCase();
            const status = statusConfig[client.status] || statusConfig.active;
            return (
              <div key={client.id} className="bg-card rounded-2xl border border-border/50 p-6 hover:shadow-lg hover:shadow-black/5 transition-all duration-300 group">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      {client.avatar_url && <img src={client.avatar_url} alt={client.first_name} className="w-full h-full object-cover rounded-full" />}
                      <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                        {initials}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-foreground">{client.first_name} {client.last_name || ""}</p>
                      <Badge className={`text-xs mt-1 ${status.color}`}>
                        {client.status === "vip" && <Star className="w-3 h-3 mr-1" />}
                        {status.label}
                      </Badge>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link to={`/clients/${client.id}`}>
                          <Eye className="w-4 h-4 mr-2" /> Profiel bekijken
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link to={`/clients/${client.id}`} state={{ openMail: true }}>
                          <Send className="w-4 h-4 mr-2" /> E-mail sturen
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => { setEditingClient(client); setShowForm(true); }}>
                        <Pencil className="w-4 h-4 mr-2" /> Bewerken
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => deleteMutation.mutate(client.id)}>
                        <Trash2 className="w-4 h-4 mr-2" /> Verwijderen
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="space-y-2 text-sm">
                  {client.phone && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="w-3.5 h-3.5" />
                      <span>{client.phone}</span>
                    </div>
                  )}
                  {client.email && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="w-3.5 h-3.5" />
                      <span className="truncate">{client.email}</span>
                    </div>
                  )}
                </div>

                {(client.total_visits > 0 || client.total_spent > 0) && (
                  <div className="flex items-center gap-4 mt-4 pt-4 border-t border-border/50">
                    <div>
                      <p className="text-xs text-muted-foreground">Bezoeken</p>
                      <p className="text-sm font-semibold">{client.total_visits || 0}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Uitgegeven</p>
                      <p className="text-sm font-semibold">€{(client.total_spent || 0).toFixed(0)}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {editingClient ? "Klant bewerken" : "Nieuwe klant"}
            </DialogTitle>
          </DialogHeader>
          <ClientForm
            client={editingClient}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditingClient(null); }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}