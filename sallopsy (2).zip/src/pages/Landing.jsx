import React from "react";
import Navbar from "@/components/landing/Navbar";
import HeroSection from "@/components/landing/HeroSection";
import FeaturesSection from "@/components/landing/FeaturesSection";
import PricingSection from "@/components/landing/PricingSection";
import WhySection from "@/components/landing/WhySection";
import GallerySection from "@/components/landing/GallerySection";
import ProductsShowcase from "@/components/landing/ProductsShowcase";
import PaymentMethods from "@/components/landing/PaymentMethods";
import Nis2Section from "@/components/landing/Nis2Section";
import TestimonialsSection from "@/components/landing/TestimonialsSection";
import FaqSection from "@/components/landing/FaqSection";
import FooterSection from "@/components/landing/FooterSection";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <HeroSection />
      <GallerySection />
      <FeaturesSection />
      <ProductsShowcase />
      <TestimonialsSection />
      <PricingSection />
      <WhySection />
      <PaymentMethods />
      <FaqSection />
      <Nis2Section />
      <FooterSection />
    </div>
  );
}