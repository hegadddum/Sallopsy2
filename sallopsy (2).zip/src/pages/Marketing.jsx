import React, { useState, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart2, TrendingUp, Users, Mail, Gift, Target } from "lucide-react";
import MarketingOverview from "@/components/marketing/MarketingOverview";
import MarketingCampaigns from "@/components/marketing/MarketingCampaigns";
import MarketingRetention from "@/components/marketing/MarketingRetention";
import MarketingChannels from "@/components/marketing/MarketingChannels";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

export default function Marketing() {
  const [tab, setTab] = useState("overzicht");

  const { data: appointments = [] } = useQuery({
    queryKey: ["appointments"],
    queryFn: () => base44.entities.Appointment.list("-date", 1000),
  });
  const { data: clients = [] } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list("-created_date", 500),
  });
  const { data: loyaltyTx = [] } = useQuery({
    queryKey: ["loyalty-transactions"],
    queryFn: () => base44.entities.LoyaltyTransaction.list("-created_date", 1000),
  });

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Marketing Analytics</h1>
          <p className="text-muted-foreground mt-1">
            {format(new Date(), "MMMM yyyy", { locale: nl })} · Volledig overzicht van je groeistrategie
          </p>
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="overzicht" className="text-xs sm:text-sm">
              <BarChart2 className="w-3.5 h-3.5 mr-1" />Overzicht
            </TabsTrigger>
            <TabsTrigger value="retentie" className="text-xs sm:text-sm">
              <Users className="w-3.5 h-3.5 mr-1" />Retentie
            </TabsTrigger>
            <TabsTrigger value="kanalen" className="text-xs sm:text-sm">
              <Target className="w-3.5 h-3.5 mr-1" />Kanalen
            </TabsTrigger>
            <TabsTrigger value="campagnes" className="text-xs sm:text-sm">
              <Mail className="w-3.5 h-3.5 mr-1" />Campagnes
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {tab === "overzicht" && <MarketingOverview appointments={appointments} clients={clients} loyaltyTx={loyaltyTx} />}
      {tab === "retentie" && <MarketingRetention appointments={appointments} clients={clients} />}
      {tab === "kanalen" && <MarketingChannels appointments={appointments} clients={clients} />}
      {tab === "campagnes" && <MarketingCampaigns clients={clients} />}
    </div>
  );
}