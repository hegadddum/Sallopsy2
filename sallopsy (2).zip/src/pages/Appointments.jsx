import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle
} from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Plus, Search, Calendar, MoreHorizontal, Pencil, Trash2, ChevronLeft, ChevronRight, Mail, CheckCircle, Download, Loader2 as LoaderIcon } from "lucide-react";
import AppointmentForm from "@/components/appointments/AppointmentForm";
import WeekCalendar from "@/components/appointments/WeekCalendar";
import { format, addWeeks, subWeeks, startOfWeek } from "date-fns";
import { nl } from "date-fns/locale";
import { toast } from "sonner";

const statusColors = {
  gepland: "bg-blue-100 text-blue-700",
  bevestigd: "bg-emerald-100 text-emerald-700",
  voltooid: "bg-muted text-muted-foreground",
  geannuleerd: "bg-red-100 text-red-700",
  no_show: "bg-amber-100 text-amber-700",
};

async function sendConfirmationEmail(appt) {
  if (!appt.client_email && !appt.email) return;
  const to = appt.client_email || appt.email;
  await base44.integrations.Core.SendEmail({
    to,
    subject: `Afspraakbevestiging — ${appt.service_name} op ${appt.date}`,
    from_name: "S.O.S. Salon",
    body: `Beste ${appt.client_name},\n\nJe afspraak is bevestigd!\n\n📅 Datum: ${appt.date}\n🕐 Tijd: ${appt.time}\n✂️ Dienst: ${appt.service_name}${appt.duration ? ` (${appt.duration} min)` : ""}\n💶 Prijs: €${appt.price || 0}\n\nTot dan!\n\nHet S.O.S. Salon team`,
  });
}

export default function Appointments() {
  const [view, setView] = useState("agenda");
  const [showForm, setShowForm] = useState(false);
  const [editingAppt, setEditingAppt] = useState(null);
  const [search, setSearch] = useState("");
  const [weekStart, setWeekStart] = useState(startOfWeek(new Date(), { weekStartsOn: 1 }));
  const [prefillSlot, setPrefillSlot] = useState(null);
  const [exporting, setExporting] = useState(false);
  const queryClient = useQueryClient();

  const handleExport = async () => {
    setExporting(true);
    const response = await base44.functions.invoke('exportReport', { type: 'appointments', period: 'month' });
    const blob = new Blob([response.data], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'afspraken-rapport.pdf';
    a.click();
    URL.revokeObjectURL(url);
    setExporting(false);
  };

  const { data: appointments = [], isLoading } = useQuery({
    queryKey: ["appointments"],
    queryFn: () => base44.entities.Appointment.list("-date", 500),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Appointment.create(data),
    onSuccess: async (newAppt) => {
      queryClient.invalidateQueries({ queryKey: ["appointments"] });
      setShowForm(false);
      setPrefillSlot(null);
      // Auto send confirmation if status is 'bevestigd'
      if (newAppt.status === "bevestigd" && (newAppt.client_email || newAppt.email)) {
        await sendConfirmationEmail(newAppt);
        toast.success("Afspraak aangemaakt & bevestiging verstuurd");
      } else {
        toast.success("Afspraak aangemaakt");
      }
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Appointment.update(id, data),
    onSuccess: async (updated, { previousStatus }) => {
      queryClient.invalidateQueries({ queryKey: ["appointments"] });
      setShowForm(false);
      setEditingAppt(null);
      // Send email if status changed TO 'bevestigd'
      if (updated.status === "bevestigd" && previousStatus !== "bevestigd" && (updated.client_email || updated.email)) {
        await sendConfirmationEmail(updated);
        toast.success("Afspraak bijgewerkt & bevestiging verstuurd");
      } else {
        toast.success("Afspraak bijgewerkt");
      }
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Appointment.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["appointments"] });
      toast.success("Afspraak verwijderd");
    },
  });

  const handleSave = async (data) => {
    if (editingAppt) {
      await updateMutation.mutateAsync({ id: editingAppt.id, data, previousStatus: editingAppt.status });
    } else {
      await createMutation.mutateAsync(data);
    }
  };

  const handleConfirm = async (appt) => {
    await updateMutation.mutateAsync({ id: appt.id, data: { ...appt, status: "bevestigd" }, previousStatus: appt.status });
  };

  const handleSlotClick = (date, time) => {
    setPrefillSlot({ date, time });
    setEditingAppt(null);
    setShowForm(true);
  };

  const filtered = appointments.filter((a) =>
    (a.client_name || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.service_name || "").toLowerCase().includes(search.toLowerCase())
  );

  const weekLabel = `${format(weekStart, "d MMM", { locale: nl })} – ${format(new Date(weekStart.getTime() + 6 * 86400000), "d MMM yyyy", { locale: nl })}`;

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Afspraken</h1>
          <p className="text-muted-foreground mt-1">Beheer je agenda</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={handleExport} disabled={exporting}>
            {exporting ? <LoaderIcon className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
            Exporteren
          </Button>
          <Button onClick={() => { setEditingAppt(null); setPrefillSlot(null); setShowForm(true); }} className="bg-primary">
            <Plus className="w-4 h-4 mr-2" /> Nieuwe afspraak
          </Button>
        </div>
      </div>

      <Tabs value={view} onValueChange={setView} className="mb-4">
        <TabsList>
          <TabsTrigger value="agenda">
            <Calendar className="w-4 h-4 mr-1.5" /> Agenda
          </TabsTrigger>
          <TabsTrigger value="lijst">
            <Search className="w-4 h-4 mr-1.5" /> Lijst
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {view === "agenda" ? (
        <>
          {/* Week navigation */}
          <div className="flex items-center gap-3 mb-4">
            <Button variant="outline" size="icon" onClick={() => setWeekStart(subWeeks(weekStart, 1))}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={() => setWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }))}>
              Vandaag
            </Button>
            <Button variant="outline" size="icon" onClick={() => setWeekStart(addWeeks(weekStart, 1))}>
              <ChevronRight className="w-4 h-4" />
            </Button>
            <span className="text-sm font-medium text-foreground ml-1">{weekLabel}</span>
          </div>
          {isLoading ? (
            <div className="bg-card rounded-2xl border border-border/50 h-96 animate-pulse" />
          ) : (
            <WeekCalendar
              appointments={appointments}
              weekStart={weekStart}
              onAppointmentClick={(appt) => { setEditingAppt(appt); setShowForm(true); }}
              onSlotClick={handleSlotClick}
            />
          )}
        </>
      ) : (
        /* List view */
        <div className="bg-card rounded-2xl border border-border/50 overflow-hidden">
          <div className="p-4 border-b border-border/50">
            <div className="relative max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Zoek op klant of dienst..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Datum & Tijd</TableHead>
                  <TableHead>Klant</TableHead>
                  <TableHead>Dienst</TableHead>
                  <TableHead>Prijs</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-16"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array(5).fill(0).map((_, i) => (
                    <TableRow key={i}>
                      {Array(6).fill(0).map((_, j) => (
                        <TableCell key={j}><div className="h-4 w-24 bg-muted rounded animate-pulse" /></TableCell>
                      ))}
                    </TableRow>
                  ))
                ) : filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                      <Calendar className="w-12 h-12 mx-auto mb-3 text-muted-foreground/30" />
                      Geen afspraken gevonden
                    </TableCell>
                  </TableRow>
                ) : (
                  filtered.map((appt) => (
                    <TableRow key={appt.id} className="hover:bg-muted/30">
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">{appt.date ? format(new Date(appt.date), "d MMM yyyy", { locale: nl }) : ""}</p>
                          <p className="text-xs text-muted-foreground">{appt.time}</p>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{appt.client_name}</TableCell>
                      <TableCell>
                        <span className="text-sm">{appt.service_name}</span>
                        {appt.duration && <span className="text-xs text-muted-foreground ml-1">({appt.duration}m)</span>}
                      </TableCell>
                      <TableCell className="font-medium">{appt.price ? `€${appt.price}` : "—"}</TableCell>
                      <TableCell>
                        <Badge className={statusColors[appt.status] || "bg-muted"}>{appt.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            {appt.status === "gepland" && (
                              <DropdownMenuItem onClick={() => handleConfirm(appt)}>
                                <CheckCircle className="w-4 h-4 mr-2 text-emerald-600" /> Bevestigen
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => { setEditingAppt(appt); setShowForm(true); }}>
                              <Pencil className="w-4 h-4 mr-2" /> Bewerken
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-destructive" onClick={() => deleteMutation.mutate(appt.id)}>
                              <Trash2 className="w-4 h-4 mr-2" /> Verwijderen
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      <Dialog open={showForm} onOpenChange={(open) => { setShowForm(open); if (!open) { setEditingAppt(null); setPrefillSlot(null); } }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {editingAppt ? "Afspraak bewerken" : "Nieuwe afspraak"}
            </DialogTitle>
          </DialogHeader>
          <AppointmentForm
            appointment={editingAppt || prefillSlot}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditingAppt(null); setPrefillSlot(null); }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}