import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowLeft, Phone, Mail, Star, Calendar, Euro, Clock, Send, Pencil, Loader2, Trophy, Gift, MessageCircle } from "lucide-react";
import ClientForm from "@/components/clients/ClientForm";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { toast } from "sonner";

const statusConfig = {
  active: { label: "Actief", color: "bg-emerald-100 text-emerald-700" },
  inactive: { label: "Inactief", color: "bg-muted text-muted-foreground" },
  vip: { label: "VIP", color: "bg-amber-100 text-amber-700" },
};

const apptStatusColors = {
  gepland: "bg-blue-100 text-blue-700",
  bevestigd: "bg-emerald-100 text-emerald-700",
  voltooid: "bg-muted text-muted-foreground",
  geannuleerd: "bg-red-100 text-red-700",
  no_show: "bg-amber-100 text-amber-700",
};

export default function ClientProfile() {
  const { id } = useParams();
  const queryClient = useQueryClient();
  const [showEdit, setShowEdit] = useState(false);
  const [showMail, setShowMail] = useState(false);
  const [mailSubject, setMailSubject] = useState("");
  const [mailBody, setMailBody] = useState("");
  const [sendingMail, setSendingMail] = useState(false);

  const { data: client, isLoading } = useQuery({
    queryKey: ["client", id],
    queryFn: async () => {
      const all = await base44.entities.Client.filter({ id });
      return all[0] || null;
    },
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ["client-appointments", id],
    queryFn: () => base44.entities.Appointment.filter({ client_id: id }, "-date", 50),
    enabled: !!id,
  });

  const { data: loyaltyTx = [] } = useQuery({
    queryKey: ["client-loyalty", id],
    queryFn: () => base44.entities.LoyaltyTransaction.filter({ client_id: id }, "-created_date", 100),
    enabled: !!id,
  });

  const totalLoyaltyPoints = loyaltyTx.reduce((s, tx) => s + (tx.points || 0), 0);
  const loyaltyTiers = [
    { name: "Brons", min: 0, max: 299, color: "text-amber-700" },
    { name: "Zilver", min: 300, max: 699, color: "text-slate-500" },
    { name: "Goud", min: 700, max: 1499, color: "text-yellow-600" },
    { name: "Platina", min: 1500, max: Infinity, color: "text-violet-600" },
  ];
  const tier = loyaltyTiers.find(t => totalLoyaltyPoints >= t.min && totalLoyaltyPoints <= t.max) || loyaltyTiers[0];

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Client.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["client", id] });
      queryClient.invalidateQueries({ queryKey: ["clients"] });
      setShowEdit(false);
      toast.success("Klant bijgewerkt");
    },
  });

  const handleSendMail = async () => {
    if (!client?.email) return toast.error("Klant heeft geen e-mailadres");
    if (!mailSubject || !mailBody) return toast.error("Vul onderwerp en bericht in");
    setSendingMail(true);
    await base44.integrations.Core.SendEmail({
      to: client.email,
      subject: mailSubject,
      from_name: "Sallopsy",
      body: mailBody,
    });
    setSendingMail(false);
    setShowMail(false);
    setMailSubject("");
    setMailBody("");
    toast.success("E-mail verstuurd naar " + client.email);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!client) {
    return (
      <div className="text-center py-20">
        <p className="text-muted-foreground">Klant niet gevonden</p>
        <Link to="/clients"><Button variant="outline" className="mt-4">Terug naar klanten</Button></Link>
      </div>
    );
  }

  const initials = `${(client.first_name || "")[0] || ""}${(client.last_name || "")[0] || ""}`.toUpperCase();
  const status = statusConfig[client.status] || statusConfig.active;
  const totalRevenue = appointments.filter(a => a.status === "voltooid").reduce((s, a) => s + (a.price || 0), 0);
  const lastAppt = appointments[0];

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <Link to="/clients" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-4">
          <ArrowLeft className="w-4 h-4" /> Terug naar klanten
        </Link>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              {client.avatar_url && <img src={client.avatar_url} alt={client.first_name} className="w-full h-full object-cover rounded-full" />}
              <AvatarFallback className="bg-primary/10 text-primary font-bold text-xl">{initials}</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="font-display text-2xl font-bold text-foreground">
                {client.first_name} {client.last_name || ""}
              </h1>
              <Badge className={`text-xs mt-1 ${status.color}`}>
                {client.status === "vip" && <Star className="w-3 h-3 mr-1" />}
                {status.label}
              </Badge>
            </div>
          </div>
          <div className="flex gap-2 flex-wrap">
            {client.phone && (
              <a
                href={`https://wa.me/${client.phone.replace(/[^0-9]/g, "")}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" className="text-emerald-600 border-emerald-200 hover:bg-emerald-50">
                  <MessageCircle className="w-4 h-4 mr-2" /> WhatsApp
                </Button>
              </a>
            )}
            <Button variant="outline" onClick={() => setShowMail(true)}>
              <Send className="w-4 h-4 mr-2" /> Stuur e-mail
            </Button>
            <Button onClick={() => setShowEdit(true)}>
              <Pencil className="w-4 h-4 mr-2" /> Bewerken
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: info */}
        <div className="space-y-4">
          {/* Contact */}
          <div className="bg-card rounded-2xl border border-border/50 p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Contactgegevens</h3>
            <div className="space-y-3 text-sm">
              {client.phone && (
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Phone className="w-4 h-4 flex-shrink-0" />
                  <span>{client.phone}</span>
                </div>
              )}
              {client.email && (
                <div className="flex items-center gap-3 text-muted-foreground">
                  <Mail className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{client.email}</span>
                </div>
              )}
              {!client.phone && !client.email && (
                <p className="text-muted-foreground">Geen contactgegevens</p>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="bg-card rounded-2xl border border-border/50 p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Statistieken</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-primary/5 rounded-xl p-3 text-center">
                <Calendar className="w-5 h-5 text-primary mx-auto mb-1" />
                <p className="text-xl font-bold text-foreground">{appointments.length}</p>
                <p className="text-xs text-muted-foreground">Afspraken</p>
              </div>
              <div className="bg-accent/10 rounded-xl p-3 text-center">
                <Euro className="w-5 h-5 text-accent mx-auto mb-1" />
                <p className="text-xl font-bold text-foreground">€{totalRevenue.toFixed(0)}</p>
                <p className="text-xs text-muted-foreground">Totaal uitgegeven</p>
              </div>
            </div>
            {lastAppt && (
              <div className="mt-3 pt-3 border-t border-border/50 flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="w-3.5 h-3.5" />
                Laatste bezoek: {format(new Date(lastAppt.date), "d MMM yyyy", { locale: nl })}
              </div>
            )}
          </div>

          {/* Loyalty */}
          <div className="bg-card rounded-2xl border border-border/50 p-5">
            <h3 className="text-sm font-semibold text-foreground mb-3">Loyaliteitspunten</h3>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Trophy className={`w-5 h-5 ${tier.color}`} />
                <span className={`text-sm font-semibold ${tier.color}`}>{tier.name}</span>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-primary">{totalLoyaltyPoints}</p>
                <p className="text-xs text-muted-foreground">punten</p>
              </div>
            </div>
            {totalLoyaltyPoints >= 100 && (
              <div className="mt-3 flex items-center gap-2 px-3 py-2 rounded-xl bg-accent/10">
                <Gift className="w-4 h-4 text-accent" />
                <p className="text-xs font-medium text-accent">{Math.floor(totalLoyaltyPoints / 100)} beloning(en) beschikbaar</p>
              </div>
            )}
          </div>

          {/* Notes */}
          {client.notes && (
            <div className="bg-card rounded-2xl border border-border/50 p-5">
              <h3 className="text-sm font-semibold text-foreground mb-2">Notities</h3>
              <p className="text-sm text-muted-foreground whitespace-pre-wrap">{client.notes}</p>
            </div>
          )}
        </div>

        {/* Right: appointment history */}
        <div className="lg:col-span-2 bg-card rounded-2xl border border-border/50 p-5">
          <h3 className="text-lg font-semibold text-foreground mb-4">Afspraakgeschiedenis</h3>
          {appointments.length === 0 ? (
            <div className="text-center py-12">
              <Calendar className="w-12 h-12 mx-auto mb-3 text-muted-foreground/20" />
              <p className="text-sm text-muted-foreground">Geen afspraken gevonden</p>
            </div>
          ) : (
            <div className="space-y-2">
              {appointments.map((appt) => (
                <div key={appt.id} className="flex items-center justify-between p-3 rounded-xl hover:bg-muted/40 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-foreground">{appt.service_name}</p>
                      <p className="text-xs text-muted-foreground">
                        {appt.date ? format(new Date(appt.date), "d MMM yyyy", { locale: nl }) : ""} · {appt.time}
                        {appt.staff_member ? ` · ${appt.staff_member}` : ""}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-semibold text-foreground">{appt.price ? `€${appt.price}` : "—"}</span>
                    <Badge className={`text-xs ${apptStatusColors[appt.status] || "bg-muted"}`}>{appt.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Edit dialog */}
      <Dialog open={showEdit} onOpenChange={setShowEdit}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Klant bewerken</DialogTitle>
          </DialogHeader>
          <ClientForm
            client={client}
            onSave={(data) => updateMutation.mutateAsync(data)}
            onCancel={() => setShowEdit(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Marketing mail dialog */}
      <Dialog open={showMail} onOpenChange={setShowMail}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">E-mail sturen aan {client.first_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            {!client.email && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-sm text-amber-700">
                Deze klant heeft geen e-mailadres. Voeg er eerst een toe.
              </div>
            )}
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Aan</label>
              <p className="text-sm text-muted-foreground">{client.email || "—"}</p>
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Onderwerp</label>
              <input
                className="w-full h-9 rounded-md border border-input bg-transparent px-3 py-1 text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                value={mailSubject}
                onChange={(e) => setMailSubject(e.target.value)}
                placeholder="bijv. Speciale aanbieding voor jou!"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">Bericht</label>
              <Textarea
                value={mailBody}
                onChange={(e) => setMailBody(e.target.value)}
                placeholder={`Beste ${client.first_name},\n\n`}
                rows={6}
              />
            </div>
            <div className="flex justify-end gap-3 pt-1">
              <Button variant="outline" onClick={() => setShowMail(false)}>Annuleren</Button>
              <Button onClick={handleSendMail} disabled={sendingMail || !client.email}>
                {sendingMail ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Send className="w-4 h-4 mr-2" />}
                Versturen
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}