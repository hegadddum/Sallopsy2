import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Euro, Users, Calendar, TrendingUp, BarChart2 } from "lucide-react";
import StatsCard from "@/components/dashboard/StatsCard";
import TodayAppointments from "@/components/dashboard/TodayAppointments";
import RevenueStats from "@/components/dashboard/RevenueStats";
import RevenueChart from "@/components/dashboard/RevenueChart";
import CalendarByStaff from "@/components/dashboard/CalendarByStaff";
import RevenueForecast from "@/components/dashboard/RevenueForecast";
import ProductForecast from "@/components/dashboard/ProductForecast";
import CustomerInsights from "@/components/dashboard/CustomerInsights";
import StockOptimization from "@/components/dashboard/StockOptimization";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useMutation, useQueryClient } from "@tanstack/react-query";

export default function Dashboard() {
  const [tab, setTab] = useState("overzicht");

  const { data: appointments = [], isLoading: loadingAppts } = useQuery({
    queryKey: ["appointments"],
    queryFn: () => base44.entities.Appointment.list("-date", 500),
  });

  const { data: clients = [] } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list("-created_date", 200),
  });

  const { data: staffMembers = [] } = useQuery({
    queryKey: ["staffMembers"],
    queryFn: () => base44.entities.StaffMember.list(),
  });

  const queryClient = useQueryClient();

  const updateAppointmentMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      return await base44.entities.Appointment.update(id, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["appointments"] });
    },
  });

  const now = new Date();
  const thisMonth = format(now, "yyyy-MM");
  const lastMonthDate = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const lastMonth = format(lastMonthDate, "yyyy-MM");

  const monthAppointments = appointments.filter((a) => a.date?.startsWith(thisMonth));
  const completedThisMonth = monthAppointments.filter((a) => a.status === "voltooid");
  const monthRevenue = completedThisMonth.reduce((sum, a) => sum + (a.price || 0), 0);

  const lastMonthCompleted = appointments.filter((a) => a.date?.startsWith(lastMonth) && a.status === "voltooid");
  const lastMonthRevenue = lastMonthCompleted.reduce((sum, a) => sum + (a.price || 0), 0);
  const revenueChange = lastMonthRevenue > 0 ? Math.round(((monthRevenue - lastMonthRevenue) / lastMonthRevenue) * 100) : null;

  const activeClients = clients.filter((c) => c.status !== "inactive").length;
  const lastMonthClients = clients.filter((c) => {
    const d = c.created_date ? new Date(c.created_date) : null;
    return d && format(d, "yyyy-MM") === lastMonth;
  }).length;
  const thisMonthNewClients = clients.filter((c) => {
    const d = c.created_date ? new Date(c.created_date) : null;
    return d && format(d, "yyyy-MM") === thisMonth;
  }).length;
  const clientChange = lastMonthClients > 0 ? Math.round(((thisMonthNewClients - lastMonthClients) / lastMonthClients) * 100) : null;

  const today = format(now, "yyyy-MM-dd");
  const todayCount = appointments.filter((a) => a.date === today).length;

  const avgOrder = completedThisMonth.length > 0
    ? monthRevenue / completedThisMonth.length
    : 0;
  const lastAvgOrder = lastMonthCompleted.length > 0
    ? lastMonthRevenue / lastMonthCompleted.length
    : 0;
  const avgOrderChange = lastAvgOrder > 0 ? Math.round(((avgOrder - lastAvgOrder) / lastAvgOrder) * 100) : null;

  const fmtChange = (val) => val === null ? undefined : val >= 0 ? `+${val}%` : `${val}%`;

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            {format(new Date(), "EEEE d MMMM yyyy", { locale: nl })}
          </p>
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="overzicht">Overzicht</TabsTrigger>
            <TabsTrigger value="statistieken">
              <BarChart2 className="w-4 h-4 mr-1.5" />Statistieken
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatsCard
          icon={Euro}
          label="Omzet deze maand"
          value={`€${monthRevenue.toLocaleString("nl-NL", { minimumFractionDigits: 0 })}`}
          change={fmtChange(revenueChange)}
          gradient="from-blue-500 to-indigo-600"
        />
        <StatsCard
          icon={Calendar}
          label="Afspraken vandaag"
          value={todayCount.toString()}
          gradient="from-emerald-500 to-teal-600"
        />
        <StatsCard
          icon={Users}
          label="Actieve klanten"
          value={activeClients.toString()}
          change={fmtChange(clientChange)}
          gradient="from-amber-500 to-orange-600"
        />
        <StatsCard
          icon={TrendingUp}
          label="Gem. orderbedrag"
          value={`€${avgOrder.toFixed(0)}`}
          change={fmtChange(avgOrderChange)}
          gradient="from-violet-500 to-purple-600"
        />
      </div>

      {tab === "overzicht" ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TodayAppointments appointments={appointments} isLoading={loadingAppts} />
            <div className="bg-card rounded-2xl border border-border/50 p-6">
              <h3 className="text-lg font-semibold text-foreground mb-1">Omzet deze week</h3>
              <p className="text-sm text-muted-foreground mb-4">Afgeronde afspraken</p>
              {/* inline mini chart */}
              <WeekMiniChart appointments={appointments} />
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <RevenueForecast />
            <ProductForecast />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CustomerInsights />
            <StockOptimization />
          </div>
          <CalendarByStaff 
            appointments={appointments} 
            staffMembers={staffMembers}
            onAppointmentUpdate={(id, data) => {
              updateAppointmentMutation.mutate({ id, data });
            }}
          />
        </div>
      ) : (
        <RevenueStats appointments={appointments} />
      )}
    </div>
  );
}

// Small inline week revenue chart
function WeekMiniChart({ appointments }) {
  const last7 = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const ds = d.toISOString().split("T")[0];
    const rev = appointments
      .filter((a) => a.date === ds && a.status === "voltooid")
      .reduce((s, a) => s + (a.price || 0), 0);
    last7.push({ dag: ["Zo", "Ma", "Di", "Wo", "Do", "Vr", "Za"][d.getDay()], omzet: rev });
  }
  const tooltip = ({ active, payload }) => {
    if (active && payload?.length) {
      return (
        <div className="bg-card border border-border rounded-xl px-3 py-2 shadow-lg text-sm">
          <p className="font-semibold">€{payload[0].value.toFixed(2)}</p>
        </div>
      );
    }
    return null;
  };
  return (
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={last7}>
        <defs>
          <linearGradient id="wg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="hsl(230,65%,28%)" stopOpacity={0.3} />
            <stop offset="95%" stopColor="hsl(230,65%,28%)" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,15%,90%)" />
        <XAxis dataKey="dag" tick={{ fontSize: 12 }} stroke="hsl(220,10%,60%)" />
        <YAxis tick={{ fontSize: 12 }} stroke="hsl(220,10%,60%)" tickFormatter={(v) => `€${v}`} />
        <Tooltip content={tooltip} />
        <Area type="monotone" dataKey="omzet" stroke="hsl(230,65%,28%)" strokeWidth={2.5} fill="url(#wg)" />
      </AreaChart>
    </ResponsiveContainer>
  );
}