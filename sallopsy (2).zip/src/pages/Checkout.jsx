import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Search, Euro, CheckCircle2, CreditCard, Banknote, Globe, Calendar, Clock, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { nl } from "date-fns/locale";
import { toast } from "sonner";

const paymentMethods = [
  { value: "contant", label: "Contant", icon: Banknote },
  { value: "pin", label: "Pin / Betaalpas", icon: CreditCard },
  { value: "online", label: "Online betaling", icon: Globe },
];

export default function Checkout() {
  const [search, setSearch] = useState("");
  const [checkoutAppt, setCheckoutAppt] = useState(null);
  const [paymentMethod, setPaymentMethod] = useState("pin");
  const [customPrice, setCustomPrice] = useState("");
  const [processing, setProcessing] = useState(false);
  const queryClient = useQueryClient();

  const today = format(new Date(), "yyyy-MM-dd");

  const { data: appointments = [], isLoading } = useQuery({
    queryKey: ["checkout-appointments"],
    queryFn: () => base44.entities.Appointment.filter({ date: today }, "time", 100),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Appointment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["checkout-appointments"] });
      queryClient.invalidateQueries({ queryKey: ["appointments"] });
    },
  });

  const unpaid = appointments.filter(a => a.status !== "geannuleerd" && a.status !== "no_show" && !a.paid);
  const paid = appointments.filter(a => a.paid);

  const filtered = unpaid.filter(a =>
    (a.client_name || "").toLowerCase().includes(search.toLowerCase()) ||
    (a.service_name || "").toLowerCase().includes(search.toLowerCase())
  );

  const openCheckout = (appt) => {
    setCheckoutAppt(appt);
    setPaymentMethod("pin");
    setCustomPrice(appt.price?.toString() || "");
  };

  const handleCheckout = async () => {
    if (!checkoutAppt) return;
    setProcessing(true);
    const finalPrice = parseFloat(customPrice) || checkoutAppt.price || 0;
    await updateMutation.mutateAsync({
      id: checkoutAppt.id,
      data: {
        ...checkoutAppt,
        status: "voltooid",
        paid: true,
        payment_method: paymentMethod,
        price: finalPrice,
      },
    });
    setCheckoutAppt(null);
    setProcessing(false);
    toast.success(`✅ Betaling van €${finalPrice} verwerkt via ${paymentMethod}`);
  };

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-foreground">Kassa</h1>
        <p className="text-muted-foreground mt-1">Vandaag — {format(new Date(), "EEEE d MMMM", { locale: nl })}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-card rounded-2xl border border-border/50 p-4 text-center">
          <p className="text-2xl font-bold text-foreground">{unpaid.length}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Nog af te rekenen</p>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-4 text-center">
          <p className="text-2xl font-bold text-emerald-600">{paid.length}</p>
          <p className="text-xs text-muted-foreground mt-0.5">Betaald vandaag</p>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-4 text-center">
          <p className="text-2xl font-bold text-primary">
            €{paid.reduce((s, a) => s + (a.price || 0), 0).toFixed(0)}
          </p>
          <p className="text-xs text-muted-foreground mt-0.5">Omzet vandaag</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-sm mb-6">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Zoek klant of dienst..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
      </div>

      {isLoading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-20 bg-muted rounded-2xl animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-emerald-400/50" />
          <p className="text-muted-foreground">Alle afspraken zijn afgerekend!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(appt => (
            <div key={appt.id} className="bg-card rounded-2xl border border-border/50 p-4 flex items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">{appt.client_name}</p>
                  <p className="text-sm text-muted-foreground">{appt.service_name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Clock className="w-3 h-3 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">{appt.time}</span>
                    {appt.staff_member && <span className="text-xs text-muted-foreground">· {appt.staff_member}</span>}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-lg font-bold text-foreground">€{appt.price || 0}</p>
                  <Badge className="text-xs bg-amber-100 text-amber-700">{appt.status}</Badge>
                </div>
                <Button onClick={() => openCheckout(appt)} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                  <Euro className="w-4 h-4 mr-2" /> Afrekenen
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Paid today */}
      {paid.length > 0 && (
        <div className="mt-8">
          <h3 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Betaald vandaag</h3>
          <div className="space-y-2">
            {paid.map(appt => (
              <div key={appt.id} className="bg-muted/30 rounded-xl p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                  <div>
                    <p className="text-sm font-medium text-foreground">{appt.client_name} — {appt.service_name}</p>
                    <p className="text-xs text-muted-foreground">{appt.time} · {appt.payment_method || "onbekend"}</p>
                  </div>
                </div>
                <p className="text-sm font-bold text-emerald-600">€{appt.price || 0}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Checkout dialog */}
      <Dialog open={!!checkoutAppt} onOpenChange={(o) => !o && setCheckoutAppt(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">Afrekenen</DialogTitle>
          </DialogHeader>
          {checkoutAppt && (
            <div className="space-y-4 pt-1">
              <div className="bg-muted/30 rounded-xl p-4">
                <p className="font-semibold text-foreground">{checkoutAppt.client_name}</p>
                <p className="text-sm text-muted-foreground">{checkoutAppt.service_name} · {checkoutAppt.time}</p>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Bedrag (€)</label>
                <Input
                  type="number"
                  step="0.01"
                  value={customPrice}
                  onChange={(e) => setCustomPrice(e.target.value)}
                  className="text-lg font-bold"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium">Betaalmethode</label>
                <div className="grid grid-cols-3 gap-2">
                  {paymentMethods.map(m => (
                    <button
                      key={m.value}
                      type="button"
                      onClick={() => setPaymentMethod(m.value)}
                      className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border-2 transition-all text-xs font-medium ${
                        paymentMethod === m.value
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-border bg-background text-muted-foreground hover:border-primary/30"
                      }`}
                    >
                      <m.icon className="w-5 h-5" />
                      {m.label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 pt-1">
                <Button variant="outline" className="flex-1" onClick={() => setCheckoutAppt(null)}>Annuleren</Button>
                <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white" onClick={handleCheckout} disabled={processing}>
                  {processing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                  Betaling bevestigen
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}