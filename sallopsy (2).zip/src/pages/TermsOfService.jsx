import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, FileText } from "lucide-react";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";

const sections = [
  {
    title: "1. Definities",
    content: `"Sallopsy": Sallopsy B.V., gevestigd te Amsterdam.
"Dienst": het Sallopsy platform, inclusief alle functies en pagina's.
"Gebruiker": iedere persoon of onderneming die gebruik maakt van de Dienst.
"Abonnement": de gekozen betaalde of gratis proefperiode.`,
  },
  {
    title: "2. Toepasselijkheid",
    content: `Deze algemene voorwaarden zijn van toepassing op alle overeenkomsten tussen Sallopsy en Gebruikers. Door gebruik te maken van de Dienst gaat u akkoord met deze voorwaarden. Afwijkende voorwaarden zijn alleen geldig als schriftelijk overeengekomen.`,
  },
  {
    title: "3. Dienstverlening",
    content: `Sallopsy biedt een Software-as-a-Service (SaaS) platform voor salonbeheer. Wij streven naar een beschikbaarheid van 99,9% per jaar. Gepland onderhoud wordt minimaal 24 uur van tevoren aangekondigd. Wij zijn niet aansprakelijk voor storingen buiten onze macht.`,
  },
  {
    title: "4. Abonnementen & Betaling",
    content: `Abonnementen worden maandelijks of jaarlijks vooraf gefactureerd. Bij niet-tijdige betaling kan de toegang worden opgeschort na een betalingstermijn van 14 dagen. Prijswijzigingen worden minimaal 30 dagen van tevoren gecommuniceerd. De gratis proefperiode van 14 dagen vereist geen betaalmiddel.`,
  },
  {
    title: "5. Opzegging",
    content: `U kunt uw abonnement op elk moment opzeggen via het dashboard. Opzegging gaat in aan het einde van de lopende betaalperiode. Er worden geen resterende dagen terugbetaald tenzij anders overeengekomen. Na opzegging heeft u 30 dagen de tijd om uw data te exporteren.`,
  },
  {
    title: "6. Gebruik van de Dienst",
    content: `Het is niet toegestaan de Dienst te gebruiken voor:
• Illegale activiteiten.
• Het versturen van spam of ongewenste berichten.
• Het hacken of verstoren van het platform.
• Het doorverkopen van de Dienst zonder toestemming.
Sallopsy behoudt het recht accounts te blokkeren bij misbruik.`,
  },
  {
    title: "7. Eigendom & Intellectueel Eigendom",
    content: `Alle rechten op het platform, de software en de huisstijl zijn eigendom van Sallopsy B.V. Uw eigen data (klanten, afspraken, producten) blijft te allen tijde eigendom van u. Wij verlenen u een niet-exclusieve licentie om de Dienst te gebruiken.`,
  },
  {
    title: "8. Aansprakelijkheid",
    content: `Sallopsy is niet aansprakelijk voor indirecte schade, gevolgschade of gederfde winst. Onze aansprakelijkheid is te allen tijde beperkt tot het bedrag dat u in de afgelopen 12 maanden aan abonnementskosten heeft betaald. Wij zijn niet verantwoordelijk voor het gebruik van de Dienst door derden.`,
  },
  {
    title: "9. Privacy",
    content: `Wij gaan zorgvuldig om met uw persoonsgegevens conform ons Privacybeleid en de AVG. Raadpleeg ons volledige Privacybeleid op de daarvoor bestemde pagina.`,
  },
  {
    title: "10. Toepasselijk recht",
    content: `Op deze voorwaarden is Nederlands recht van toepassing. Geschillen worden bij voorkeur in overleg opgelost. Indien nodig zijn de rechtbanken in Amsterdam bevoegd. Laatste update: juni 2026.`,
  },
];

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-3xl mx-auto px-6 pt-32 pb-20">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-10">
          <ArrowLeft className="w-4 h-4" />
          Terug naar home
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-semibold px-4 py-2 rounded-full mb-6">
            <FileText className="w-4 h-4" />
            Juridisch document
          </div>
          <h1 className="font-display text-4xl font-bold text-foreground mb-4">Algemene Voorwaarden</h1>
          <p className="text-muted-foreground">Laatste update: juni 2026</p>
        </motion.div>

        <div className="space-y-8">
          {sections.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
            >
              <h2 className="font-bold text-foreground text-lg mb-3">{s.title}</h2>
              <p className="text-muted-foreground text-sm leading-relaxed whitespace-pre-line">{s.content}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <FooterSection />
    </div>
  );
}