import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Loader2, Save, Building2, Clock, Globe, ExternalLink, Upload, ImageIcon } from "lucide-react";
import { toast } from "sonner";

export default function Settings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [profileId, setProfileId] = useState(null);
  const [form, setForm] = useState({
    salon_name: "",
    salon_address: "",
    salon_phone: "",
    salon_email: "",
    opening_hours: "",
    website: "",
    logo_url: "",
    booking_link_active: true,
  });

  useEffect(() => {
    const load = async () => {
      const profiles = await base44.entities.SalonProfile.list("salon_name", 1);
      if (profiles.length > 0) {
        setProfileId(profiles[0].id);
        setForm({ ...form, ...profiles[0] });
      }
      setLoading(false);
    };
    load();
  }, []);

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((f) => ({ ...f, logo_url: file_url }));
    setUploading(false);
  };

  const handleSave = async () => {
    setSaving(true);
    if (profileId) {
      await base44.entities.SalonProfile.update(profileId, form);
    } else {
      const created = await base44.entities.SalonProfile.create(form);
      setProfileId(created.id);
    }
    toast.success("Instellingen opgeslagen");
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-foreground">Instellingen</h1>
        <p className="text-muted-foreground mt-1">Beheer je saloninformatie</p>
      </div>

      <div className="max-w-2xl space-y-6">
        <Card className="rounded-2xl border-border/50">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                <Building2 className="w-5 h-5 text-primary" />
              </div>
              <div>
                <CardTitle>Salongegevens</CardTitle>
                <CardDescription>Gedeeld profiel — zichtbaar voor alle medewerkers</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Logo */}
            <div className="space-y-2">
              <Label>Logo</Label>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-xl border-2 border-dashed border-border bg-muted/30 flex items-center justify-center overflow-hidden">
                  {form.logo_url ? <img src={form.logo_url} alt="logo" className="w-full h-full object-contain p-1" /> : <ImageIcon className="w-7 h-7 text-muted-foreground/40" />}
                </div>
                <label htmlFor="logo-upload" className="cursor-pointer">
                  <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-border bg-background hover:bg-muted/50 transition-colors text-sm font-medium w-fit">
                    {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                    {uploading ? "Uploaden..." : "Logo uploaden"}
                  </div>
                </label>
                <input id="logo-upload" type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} disabled={uploading} />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Salonnaam</Label>
                <Input value={form.salon_name} onChange={(e) => setForm({ ...form, salon_name: e.target.value })} placeholder="Mijn Salon" />
              </div>
              <div className="space-y-2">
                <Label>Telefoon</Label>
                <Input value={form.salon_phone} onChange={(e) => setForm({ ...form, salon_phone: e.target.value })} placeholder="+31 6 12345678" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Adres</Label>
              <Input value={form.salon_address} onChange={(e) => setForm({ ...form, salon_address: e.target.value })} placeholder="Straatnaam 123, Amsterdam" />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>E-mail</Label>
                <Input type="email" value={form.salon_email} onChange={(e) => setForm({ ...form, salon_email: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Website</Label>
                <Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="www.mijnsalon.nl" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Online boekingspagina */}
        <Card className="rounded-2xl border-border/50">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 flex items-center justify-center">
                <Globe className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <CardTitle>Online boekingspagina</CardTitle>
                <CardDescription>Deel deze link met klanten om online te boeken</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 border border-border">
              <code className="flex-1 text-sm text-foreground font-mono truncate">{window.location.origin}/boeken</code>
              <Button variant="outline" size="sm" onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/boeken`); toast.success("Link gekopieerd!"); }}>
                Kopiëren
              </Button>
              <a href="/boeken" target="_blank">
                <Button variant="outline" size="icon"><ExternalLink className="w-4 h-4" /></Button>
              </a>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={form.booking_link_active} onCheckedChange={(v) => setForm({ ...form, booking_link_active: v })} />
              <Label>Boekingspagina actief</Label>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-2xl border-border/50">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
                <Clock className="w-5 h-5 text-accent" />
              </div>
              <div>
                <CardTitle>Openingstijden</CardTitle>
                <CardDescription>Wanneer is je salon open</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              value={form.opening_hours}
              onChange={(e) => setForm({ ...form, opening_hours: e.target.value })}
              placeholder={"Ma-Vr: 09:00 - 18:00\nZa: 09:00 - 17:00\nZo: Gesloten"}
              rows={4}
            />
          </CardContent>
        </Card>

        <Button onClick={handleSave} disabled={saving} className="bg-primary">
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          Opslaan
        </Button>
      </div>
    </div>
  );
}