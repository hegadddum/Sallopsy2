import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Gift, Star, TrendingUp, Plus, Minus, Search, Trophy, Loader2, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { nl } from "date-fns/locale";

// Points config
const POINTS_PER_EURO = 1;         // 1 punt per €1 uitgegeven
const REWARD_THRESHOLD = 100;      // 100 punten = 1 beloning

const tiers = [
  { name: "Brons", min: 0, max: 299, color: "bg-amber-700", textColor: "text-amber-700", bg: "bg-amber-50" },
  { name: "Zilver", min: 300, max: 699, color: "bg-slate-400", textColor: "text-slate-500", bg: "bg-slate-50" },
  { name: "Goud", min: 700, max: 1499, color: "bg-yellow-500", textColor: "text-yellow-600", bg: "bg-yellow-50" },
  { name: "Platina", min: 1500, max: Infinity, color: "bg-violet-500", textColor: "text-violet-600", bg: "bg-violet-50" },
];

function getTier(points) {
  return tiers.find(t => points >= t.min && points <= t.max) || tiers[0];
}

function ClientLoyaltyCard({ client, totalPoints, onAdjust }) {
  const tier = getTier(totalPoints);
  const initials = `${(client.first_name || "")[0] || ""}${(client.last_name || "")[0] || ""}`.toUpperCase();
  const rewards = Math.floor(totalPoints / REWARD_THRESHOLD);

  return (
    <div className={`bg-card rounded-2xl border border-border/50 p-5 hover:shadow-lg hover:shadow-black/5 transition-all duration-300`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <Avatar className="w-11 h-11">
            <AvatarFallback className="bg-primary/10 text-primary font-semibold text-sm">{initials}</AvatarFallback>
          </Avatar>
          <div>
            <p className="font-semibold text-foreground text-sm">{client.first_name} {client.last_name || ""}</p>
            <Badge className={`text-xs mt-0.5 ${tier.textColor} ${tier.bg} border-0`}>
              <Trophy className="w-3 h-3 mr-1" />{tier.name}
            </Badge>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-primary">{totalPoints}</p>
          <p className="text-xs text-muted-foreground">punten</p>
        </div>
      </div>

      {/* Progress to next tier */}
      {tier.max !== Infinity && (
        <div className="mb-3">
          <div className="flex justify-between text-xs text-muted-foreground mb-1">
            <span>{tier.name}</span>
            <span>{tiers[tiers.indexOf(tier) + 1]?.name}</span>
          </div>
          <div className="h-1.5 bg-muted rounded-full overflow-hidden">
            <div
              className={`h-full ${tier.color} rounded-full transition-all`}
              style={{ width: `${Math.min(100, ((totalPoints - tier.min) / (tier.max - tier.min)) * 100)}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">{tier.max - totalPoints} punten tot {tiers[tiers.indexOf(tier) + 1]?.name}</p>
        </div>
      )}

      {rewards > 0 && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-accent/10 mb-3">
          <Gift className="w-4 h-4 text-accent" />
          <p className="text-xs font-medium text-accent">{rewards} beloning{rewards > 1 ? "en" : ""} beschikbaar!</p>
        </div>
      )}

      <div className="flex gap-2">
        <Button size="sm" variant="outline" className="flex-1 h-8 text-xs" onClick={() => onAdjust(client, "inwisselen")}>
          <Minus className="w-3 h-3 mr-1" /> Inwisselen
        </Button>
        <Button size="sm" className="flex-1 h-8 text-xs" onClick={() => onAdjust(client, "verdienen")}>
          <Plus className="w-3 h-3 mr-1" /> Punten geven
        </Button>
      </div>
    </div>
  );
}

function AdjustDialog({ client, type, onClose, onConfirm }) {
  const [points, setPoints] = useState("");
  const [description, setDescription] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!points || parseInt(points) <= 0) return toast.error("Voer een geldig aantal punten in");
    setSaving(true);
    await onConfirm({
      client_id: client.id,
      client_name: `${client.first_name} ${client.last_name || ""}`,
      points: type === "inwisselen" ? -Math.abs(parseInt(points)) : Math.abs(parseInt(points)),
      type,
      description: description || (type === "verdienen" ? "Handmatig toegevoegd" : "Handmatig ingewisseld"),
    });
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {type === "verdienen" ? "Punten toekennen" : "Punten inwisselen"} — {client.first_name}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 pt-1">
          <div className="space-y-1.5">
            <Label>Aantal punten</Label>
            <Input type="number" min="1" value={points} onChange={(e) => setPoints(e.target.value)} placeholder="bijv. 50" required />
          </div>
          <div className="space-y-1.5">
            <Label>Omschrijving</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} placeholder={type === "verdienen" ? "bijv. Kleurbehandeling €65" : "bijv. Gratis behandeling €30"} />
          </div>
          <div className="flex justify-end gap-3 pt-1">
            <Button type="button" variant="outline" onClick={onClose}>Annuleren</Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Bevestigen
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function Loyalty() {
  const [search, setSearch] = useState("");
  const [adjustTarget, setAdjustTarget] = useState(null); // { client, type }
  const queryClient = useQueryClient();

  const { data: clients = [] } = useQuery({
    queryKey: ["clients"],
    queryFn: () => base44.entities.Client.list("-created_date", 200),
  });

  const { data: transactions = [] } = useQuery({
    queryKey: ["loyalty-transactions"],
    queryFn: () => base44.entities.LoyaltyTransaction.list("-created_date", 1000),
  });

  const createTx = useMutation({
    mutationFn: (data) => base44.entities.LoyaltyTransaction.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["loyalty-transactions"] });
      toast.success("Punten bijgewerkt");
    },
  });

  // Calculate total points per client
  const pointsByClient = transactions.reduce((acc, tx) => {
    acc[tx.client_id] = (acc[tx.client_id] || 0) + (tx.points || 0);
    return acc;
  }, {});

  const filtered = clients.filter((c) => {
    const name = `${c.first_name} ${c.last_name || ""}`.toLowerCase();
    return name.includes(search.toLowerCase());
  });

  const totalPoints = Object.values(pointsByClient).reduce((s, p) => s + p, 0);
  const redeemable = clients.filter(c => (pointsByClient[c.id] || 0) >= REWARD_THRESHOLD).length;

  // Recent transactions
  const recentTx = transactions.slice(0, 10);

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Loyaliteitssysteem</h1>
          <p className="text-muted-foreground mt-1">Beheer punten en beloningen voor klanten</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          { label: "Deelnemende klanten", value: clients.length, icon: Star, color: "text-primary bg-primary/10" },
          { label: "Totaal punten uitgegeven", value: totalPoints.toLocaleString(), icon: TrendingUp, color: "text-emerald-600 bg-emerald-100" },
          { label: "Beloningen beschikbaar", value: redeemable, icon: Gift, color: "text-accent bg-accent/10" },
          { label: "Platina klanten", value: clients.filter(c => getTier(pointsByClient[c.id] || 0).name === "Platina").length, icon: Trophy, color: "text-violet-600 bg-violet-100" },
        ].map((stat) => (
          <div key={stat.label} className="bg-card rounded-2xl border border-border/50 p-4">
            <div className={`w-9 h-9 rounded-xl ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="w-4 h-4" />
            </div>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Tier legend */}
      <div className="flex flex-wrap gap-3 mb-6">
        {tiers.map(t => (
          <div key={t.name} className={`flex items-center gap-2 px-3 py-1.5 rounded-xl ${t.bg} border border-border/30`}>
            <div className={`w-2.5 h-2.5 rounded-full ${t.color}`} />
            <span className={`text-xs font-medium ${t.textColor}`}>{t.name}</span>
            <span className="text-xs text-muted-foreground">{t.min}–{t.max === Infinity ? "∞" : t.max} punten</span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Client cards */}
        <div className="xl:col-span-2">
          <div className="flex items-center gap-3 mb-4">
            <div className="relative flex-1 max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input placeholder="Zoek klant..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filtered.map((client) => (
              <ClientLoyaltyCard
                key={client.id}
                client={client}
                totalPoints={pointsByClient[client.id] || 0}
                onAdjust={(c, type) => setAdjustTarget({ client: c, type })}
              />
            ))}
          </div>
        </div>

        {/* Recent transactions */}
        <div className="bg-card rounded-2xl border border-border/50 p-5 h-fit">
          <h3 className="text-sm font-semibold text-foreground mb-4">Recente transacties</h3>
          {recentTx.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">Nog geen transacties</p>
          ) : (
            <div className="space-y-3">
              {recentTx.map((tx) => (
                <div key={tx.id} className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${tx.points > 0 ? "bg-emerald-100" : "bg-red-100"}`}>
                    {tx.points > 0
                      ? <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                      : <ArrowDownRight className="w-4 h-4 text-red-500" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">{tx.client_name}</p>
                    <p className="text-xs text-muted-foreground truncate">{tx.description}</p>
                    {tx.created_date && (
                      <p className="text-xs text-muted-foreground/60">
                        {format(new Date(tx.created_date), "d MMM", { locale: nl })}
                      </p>
                    )}
                  </div>
                  <span className={`text-sm font-bold flex-shrink-0 ${tx.points > 0 ? "text-emerald-600" : "text-red-500"}`}>
                    {tx.points > 0 ? "+" : ""}{tx.points}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {adjustTarget && (
        <AdjustDialog
          client={adjustTarget.client}
          type={adjustTarget.type}
          onClose={() => setAdjustTarget(null)}
          onConfirm={(data) => createTx.mutateAsync(data)}
        />
      )}
    </div>
  );
}