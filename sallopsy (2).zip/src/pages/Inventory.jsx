import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow
} from "@/components/ui/table";
import { Plus, Search, Package, MoreHorizontal, Pencil, Trash2, AlertTriangle, Loader2, Minus, Upload, ImageIcon } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";

const categoryLabels = {
  shampoo: "Shampoo",
  conditioner: "Conditioner",
  styling: "Styling",
  kleur: "Kleurproducten",
  verzorging: "Verzorging",
  gereedschap: "Gereedschap",
  overig: "Overig",
};

const categoryColors = {
  shampoo: "bg-blue-100 text-blue-700",
  conditioner: "bg-cyan-100 text-cyan-700",
  styling: "bg-violet-100 text-violet-700",
  kleur: "bg-pink-100 text-pink-700",
  verzorging: "bg-emerald-100 text-emerald-700",
  gereedschap: "bg-amber-100 text-amber-700",
  overig: "bg-muted text-muted-foreground",
};

function ProductForm({ product, onSave, onCancel }) {
  const [form, setForm] = useState({
    name: "", brand: "", category: "overig", sku: "",
    stock: 0, min_stock: 5, price_buy: 0, price_sell: 0,
    unit: "stuk", notes: "", is_active: true, image_url: "",
    ...product,
  });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm((f) => ({ ...f, image_url: file_url }));
    setUploading(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        {/* Image upload */}
        <div className="col-span-2 space-y-1.5">
          <Label>Productafbeelding</Label>
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-xl border-2 border-dashed border-border flex items-center justify-center bg-muted/30 flex-shrink-0 overflow-hidden">
              {form.image_url ? (
                <img src={form.image_url} alt="product" className="w-full h-full object-cover rounded-xl" />
              ) : (
                <ImageIcon className="w-8 h-8 text-muted-foreground/40" />
              )}
            </div>
            <div className="flex-1">
              <label htmlFor="img-upload" className="cursor-pointer">
                <div className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-background hover:bg-muted/50 transition-colors text-sm font-medium w-fit">
                  {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  {uploading ? "Uploaden..." : "Afbeelding uploaden"}
                </div>
              </label>
              <input id="img-upload" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
              {form.image_url && (
                <button type="button" onClick={() => setForm((f) => ({ ...f, image_url: "" }))} className="mt-1.5 text-xs text-destructive hover:underline">
                  Verwijderen
                </button>
              )}
            </div>
          </div>
        </div>
        <div className="col-span-2 space-y-1.5">
          <Label>Naam *</Label>
          <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
        </div>
        <div className="space-y-1.5">
          <Label>Merk</Label>
          <Input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} />
        </div>
        <div className="space-y-1.5">
          <Label>Categorie</Label>
          <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(categoryLabels).map(([k, v]) => <SelectItem key={k} value={k}>{v}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label>Artikelnummer</Label>
          <Input value={form.sku} onChange={(e) => setForm({ ...form, sku: e.target.value })} placeholder="SKU-001" />
        </div>
        <div className="space-y-1.5">
          <Label>Eenheid</Label>
          <Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} placeholder="stuk" />
        </div>
        <div className="space-y-1.5">
          <Label>Huidige voorraad</Label>
          <Input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: parseInt(e.target.value) || 0 })} />
        </div>
        <div className="space-y-1.5">
          <Label>Minimale voorraad</Label>
          <Input type="number" value={form.min_stock} onChange={(e) => setForm({ ...form, min_stock: parseInt(e.target.value) || 0 })} />
        </div>
        <div className="space-y-1.5">
          <Label>Inkoopprijs (€)</Label>
          <Input type="number" step="0.01" value={form.price_buy} onChange={(e) => setForm({ ...form, price_buy: parseFloat(e.target.value) || 0 })} />
        </div>
        <div className="space-y-1.5">
          <Label>Verkoopprijs (€)</Label>
          <Input type="number" step="0.01" value={form.price_sell} onChange={(e) => setForm({ ...form, price_sell: parseFloat(e.target.value) || 0 })} />
        </div>
        <div className="col-span-2 space-y-1.5">
          <Label>Notities</Label>
          <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} />
        </div>
        <div className="col-span-2 flex items-center gap-3">
          <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
          <Label>Product actief</Label>
        </div>
      </div>
      <div className="flex justify-end gap-3 pt-1">
        <Button type="button" variant="outline" onClick={onCancel}>Annuleren</Button>
        <Button type="submit" disabled={saving}>
          {saving && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          {product ? "Bijwerken" : "Toevoegen"}
        </Button>
      </div>
    </form>
  );
}

export default function Inventory() {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState("");
  const [adjustId, setAdjustId] = useState(null);
  const [adjustQty, setAdjustQty] = useState(0);
  const queryClient = useQueryClient();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["products"],
    queryFn: () => base44.entities.Product.list("name", 300),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Product.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["products"] }); setShowForm(false); toast.success("Product toegevoegd"); },
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Product.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["products"] }); setShowForm(false); setEditing(null); toast.success("Product bijgewerkt"); },
  });
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Product.delete(id),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["products"] }); toast.success("Product verwijderd"); },
  });

  const handleSave = async (data) => {
    if (editing) await updateMutation.mutateAsync({ id: editing.id, data });
    else await createMutation.mutateAsync(data);
  };

  const handleAdjust = async (product, delta) => {
    const newStock = Math.max(0, (product.stock || 0) + delta);
    await updateMutation.mutateAsync({ id: product.id, data: { ...product, stock: newStock } });
  };

  const filtered = products.filter((p) =>
    (p.name || "").toLowerCase().includes(search.toLowerCase()) ||
    (p.brand || "").toLowerCase().includes(search.toLowerCase())
  );

  const lowStock = products.filter((p) => p.is_active && (p.stock || 0) < (p.min_stock || 5));

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Voorraad</h1>
          <p className="text-muted-foreground mt-1">{products.length} producten</p>
        </div>
        <Button onClick={() => { setEditing(null); setShowForm(true); }}>
          <Plus className="w-4 h-4 mr-2" /> Product toevoegen
        </Button>
      </div>

      {/* Low stock warning */}
      {lowStock.length > 0 && (
        <div className="mb-6 p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-amber-800">Lage voorraad ({lowStock.length} producten)</p>
            <p className="text-sm text-amber-700 mt-0.5">{lowStock.map(p => p.name).join(", ")}</p>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="mb-4">
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Zoek op naam of merk..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-10" />
        </div>
      </div>

      {/* Table */}
      <div className="bg-card rounded-2xl border border-border/50 overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Product</TableHead>
                <TableHead>Categorie</TableHead>
                <TableHead>Voorraad</TableHead>
                <TableHead>Inkoop</TableHead>
                <TableHead>Verkoop</TableHead>
                <TableHead className="w-32">Aanpassen</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <TableRow key={i}>
                    {Array(7).fill(0).map((_, j) => (
                      <TableCell key={j}><div className="h-4 w-20 bg-muted rounded animate-pulse" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-14 text-muted-foreground">
                    <Package className="w-12 h-12 mx-auto mb-3 text-muted-foreground/20" />
                    Geen producten gevonden
                  </TableCell>
                </TableRow>
              ) : filtered.map((p) => {
                const isLow = (p.stock || 0) < (p.min_stock || 5);
                return (
                  <TableRow key={p.id} className="hover:bg-muted/30">
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg border border-border bg-muted/30 flex-shrink-0 overflow-hidden">
                          {p.image_url ? (
                            <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center">
                              <Package className="w-4 h-4 text-muted-foreground/30" />
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-foreground">{p.name}</p>
                          {p.brand && <p className="text-xs text-muted-foreground">{p.brand}</p>}
                          {p.sku && <p className="text-xs text-muted-foreground/60">{p.sku}</p>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={`text-xs ${categoryColors[p.category] || "bg-muted text-muted-foreground"}`}>
                        {categoryLabels[p.category] || p.category}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-semibold ${isLow ? "text-amber-600" : "text-foreground"}`}>
                          {p.stock || 0} {p.unit || "stuk"}
                        </span>
                        {isLow && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
                      </div>
                      <p className="text-xs text-muted-foreground">min. {p.min_stock || 5}</p>
                    </TableCell>
                    <TableCell className="text-sm">{p.price_buy ? `€${p.price_buy}` : "—"}</TableCell>
                    <TableCell className="text-sm font-medium">{p.price_sell ? `€${p.price_sell}` : "—"}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => handleAdjust(p, -1)}>
                          <Minus className="w-3 h-3" />
                        </Button>
                        <span className="w-8 text-center text-sm font-medium">{p.stock || 0}</span>
                        <Button variant="outline" size="icon" className="h-7 w-7" onClick={() => handleAdjust(p, 1)}>
                          <Plus className="w-3 h-3" />
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon"><MoreHorizontal className="w-4 h-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => { setEditing(p); setShowForm(true); }}>
                            <Pencil className="w-4 h-4 mr-2" /> Bewerken
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive" onClick={() => deleteMutation.mutate(p.id)}>
                            <Trash2 className="w-4 h-4 mr-2" /> Verwijderen
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      <Dialog open={showForm} onOpenChange={(o) => { setShowForm(o); if (!o) setEditing(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">{editing ? "Product bewerken" : "Nieuw product"}</DialogTitle>
          </DialogHeader>
          <ProductForm product={editing} onSave={handleSave} onCancel={() => { setShowForm(false); setEditing(null); }} />
        </DialogContent>
      </Dialog>
    </div>
  );
}