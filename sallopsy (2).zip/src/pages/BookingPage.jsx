import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";

import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Scissors, Clock, Euro, CheckCircle2, Calendar, ChevronLeft, ChevronRight, User, Loader2, Home } from "lucide-react";
import { format, addDays, startOfDay, isBefore } from "date-fns";
import { nl } from "date-fns/locale";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

const TIME_SLOTS = [
  "09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30",
  "13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30",
];

const categoryLabels = {
  knippen: "Knippen", kleuren: "Kleuren", styling: "Styling",
  verzorging: "Verzorging", baard: "Baard", overig: "Overig",
};

export default function BookingPage() {
  const [step, setStep] = useState(1); // 1=dienst, 2=datum/tijd, 3=gegevens, 4=bevestigd
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [currentWeekStart, setCurrentWeekStart] = useState(startOfDay(new Date()));
  const [form, setForm] = useState({ name: "", email: "", phone: "", notes: "" });
  const [submitting, setSubmitting] = useState(false);

  const { data: services = [] } = useQuery({
    queryKey: ["public-services"],
    queryFn: () => base44.entities.Service.filter({ is_active: true }, "name", 100),
  });

  const { data: existingAppointments = [] } = useQuery({
    queryKey: ["public-appointments", selectedDate],
    queryFn: () => selectedDate
      ? base44.entities.Appointment.filter({ date: selectedDate }, "time", 100)
      : Promise.resolve([]),
    enabled: !!selectedDate,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Appointment.create(data),
  });

  const takenSlots = existingAppointments.map(a => a.time);
  const days = Array.from({ length: 14 }, (_, i) => addDays(new Date(), i + 1));

  const handleBook = async () => {
    if (!form.name || !form.phone) return toast.error("Vul je naam en telefoonnummer in");
    setSubmitting(true);
    const appt = await createMutation.mutateAsync({
      client_name: form.name,
      client_email: form.email,
      service_id: selectedService.id,
      service_name: selectedService.name,
      date: selectedDate,
      time: selectedTime,
      duration: selectedService.duration,
      price: selectedService.price,
      status: "gepland",
      notes: form.notes,
    });
    // Stuur bevestigingsmail als e-mail is opgegeven
    if (form.email) {
      await base44.functions.invoke("sendBookingConfirmation", { appointment: { ...appt, client_email: form.email, client_name: form.name } });
    }
    setStep(4);
    setSubmitting(false);
  };

  const grouped = services.reduce((acc, s) => {
    if (!acc[s.category]) acc[s.category] = [];
    acc[s.category].push(s);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-background">
      <Link to="/" className="fixed top-6 right-6 z-50">
        <Button variant="outline" size="icon" className="rounded-full shadow-lg hover:bg-secondary">
          <Home className="w-5 h-5" />
        </Button>
      </Link>

      {/* Header */}
      <div className="bg-primary text-primary-foreground py-8 px-6">
        <div className="max-w-2xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
              <Scissors className="w-5 h-5" />
            </div>
            <h1 className="font-display text-2xl font-bold">Online Boeken</h1>
          </div>
          <p className="text-primary-foreground/70 text-sm">Kies een dienst, datum en tijd</p>
          {/* Steps */}
          <div className="flex items-center gap-2 mt-6">
            {["Dienst", "Datum & Tijd", "Gegevens", "Bevestigd"].map((s, i) => (
              <React.Fragment key={s}>
                <div className={`flex items-center gap-1.5 text-xs font-medium px-2 py-1 rounded-full ${step > i + 1 ? "bg-white/30 text-white" : step === i + 1 ? "bg-white text-primary" : "bg-white/10 text-white/50"}`}>
                  {step > i + 1 ? <CheckCircle2 className="w-3 h-3" /> : <span>{i + 1}</span>}
                  <span className="hidden sm:inline">{s}</span>
                </div>
                {i < 3 && <div className={`flex-1 h-0.5 ${step > i + 1 ? "bg-white/50" : "bg-white/20"}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-6 py-8">
        <AnimatePresence mode="wait">
          {/* Step 1: Dienst */}
          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <h2 className="text-xl font-bold text-foreground mb-6">Kies een behandeling</h2>
              {Object.entries(grouped).map(([cat, svcs]) => (
                <div key={cat} className="mb-6">
                  <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">{categoryLabels[cat] || cat}</h3>
                  <div className="space-y-2">
                    {svcs.map(s => (
                      <button
                        key={s.id}
                        onClick={() => { setSelectedService(s); setStep(2); }}
                        className="w-full text-left p-4 rounded-2xl border border-border bg-card hover:border-primary/50 hover:shadow-md transition-all"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-foreground">{s.name}</p>
                            {s.description && <p className="text-sm text-muted-foreground mt-0.5 line-clamp-1">{s.description}</p>}
                          </div>
                          <div className="text-right flex-shrink-0 ml-4">
                            <p className="font-bold text-foreground">€{s.price}</p>
                            <p className="text-xs text-muted-foreground">{s.duration} min</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </motion.div>
          )}

          {/* Step 2: Datum & Tijd */}
          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <button onClick={() => setStep(1)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
                <ChevronLeft className="w-4 h-4" /> Terug
              </button>
              <div className="bg-primary/5 rounded-2xl p-4 mb-6 flex items-center gap-3">
                <Scissors className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-semibold text-foreground">{selectedService?.name}</p>
                  <p className="text-sm text-muted-foreground">€{selectedService?.price} · {selectedService?.duration} min</p>
                </div>
              </div>
              <h2 className="text-xl font-bold text-foreground mb-4">Kies een datum</h2>
              <div className="grid grid-cols-4 sm:grid-cols-7 gap-2 mb-6">
                {days.map(d => {
                  const ds = format(d, "yyyy-MM-dd");
                  return (
                    <button
                      key={ds}
                      onClick={() => { setSelectedDate(ds); setSelectedTime(null); }}
                      className={`p-2 rounded-xl text-center transition-all border ${selectedDate === ds ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50"}`}
                    >
                      <p className="text-xs font-medium">{format(d, "EEE", { locale: nl })}</p>
                      <p className="text-sm font-bold">{format(d, "d")}</p>
                      <p className="text-xs opacity-70">{format(d, "MMM", { locale: nl })}</p>
                    </button>
                  );
                })}
              </div>
              {selectedDate && (
                <>
                  <h2 className="text-xl font-bold text-foreground mb-4">Kies een tijdstip</h2>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-2 mb-6">
                    {TIME_SLOTS.map(t => {
                      const taken = takenSlots.includes(t);
                      return (
                        <button
                          key={t}
                          disabled={taken}
                          onClick={() => setSelectedTime(t)}
                          className={`py-2 px-3 rounded-xl text-sm font-medium transition-all border ${taken ? "bg-muted text-muted-foreground/40 cursor-not-allowed border-transparent" : selectedTime === t ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-primary/50"}`}
                        >
                          {t}
                        </button>
                      );
                    })}
                  </div>
                  {selectedTime && (
                    <Button className="w-full" onClick={() => setStep(3)}>
                      Doorgaan <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </>
              )}
            </motion.div>
          )}

          {/* Step 3: Gegevens */}
          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <button onClick={() => setStep(2)} className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6">
                <ChevronLeft className="w-4 h-4" /> Terug
              </button>
              <div className="bg-primary/5 rounded-2xl p-4 mb-6">
                <div className="flex items-center gap-3 mb-2">
                  <Scissors className="w-5 h-5 text-primary" />
                  <p className="font-semibold text-foreground">{selectedService?.name}</p>
                </div>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {selectedDate && format(new Date(selectedDate), "d MMMM yyyy", { locale: nl })}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {selectedTime}</span>
                  <span className="flex items-center gap-1"><Euro className="w-3.5 h-3.5" /> {selectedService?.price}</span>
                </div>
              </div>
              <h2 className="text-xl font-bold text-foreground mb-6">Jouw gegevens</h2>
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label>Naam *</Label>
                  <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Volledige naam" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Telefoon *</Label>
                    <Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+31 6 12345678" />
                  </div>
                  <div className="space-y-1.5">
                    <Label>E-mail</Label>
                    <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="optioneel" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Notities</Label>
                  <Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Bijzonderheden, wensen..." rows={3} />
                </div>
                <Button className="w-full h-12 text-base font-semibold" onClick={handleBook} disabled={submitting}>
                  {submitting ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <CheckCircle2 className="w-5 h-5 mr-2" />}
                  Afspraak bevestigen
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 4: Bevestigd */}
          {step === 4 && (
            <motion.div key="step4" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
              <div className="w-20 h-20 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 className="w-10 h-10 text-emerald-600" />
              </div>
              <h2 className="font-display text-2xl font-bold text-foreground mb-2">Afspraak bevestigd!</h2>
              <p className="text-muted-foreground mb-6">Je ontvangt een bevestiging via e-mail.</p>
              <div className="bg-card rounded-2xl border border-border/50 p-6 text-left mb-8 max-w-sm mx-auto">
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-3">
                    <Scissors className="w-4 h-4 text-primary" />
                    <span className="font-medium">{selectedService?.name}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Calendar className="w-4 h-4 text-primary" />
                    <span>{selectedDate && format(new Date(selectedDate), "d MMMM yyyy", { locale: nl })}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-primary" />
                    <span>{selectedTime}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Euro className="w-4 h-4 text-primary" />
                    <span>€{selectedService?.price}</span>
                  </div>
                </div>
              </div>
              <Button variant="outline" onClick={() => { setStep(1); setSelectedService(null); setSelectedDate(null); setSelectedTime(null); setForm({ name: "", email: "", phone: "", notes: "" }); }}>
                Nieuwe afspraak maken
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}