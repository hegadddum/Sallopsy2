import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, UserPlus, Settings, CalendarCheck, TrendingUp, CheckCircle2, Home } from "lucide-react";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";
import { useLanguage } from "@/lib/LanguageContext";

const stepIcons = [UserPlus, Settings, CalendarCheck, TrendingUp];
const stepColors = [
  "from-blue-500 to-blue-600",
  "from-violet-500 to-violet-600",
  "from-amber-500 to-amber-600",
  "from-emerald-500 to-emerald-600",
];

const stepsNl = [
  { key: "step1", detail: ["Gratis 14-daagse proefperiode", "Geen creditcard vereist", "Direct toegang tot alle features"] },
  { key: "step2", detail: ["Onbeperkt diensten toevoegen", "Eigen boekingslink & widget", "Medewerkers en roosters beheren"] },
  { key: "step3", detail: ["Automatische SMS & WhatsApp reminders", "Betalingen direct bij boeking", "No-show bescherming"] },
  { key: "step4", detail: ["AI-gestuurde klantretentie", "Gepersonaliseerde aanbiedingen", "Maandelijkse omzetrapportages"] },
];

export default function HowItWorks() {
  const { t } = useLanguage();

  const steps = stepsNl.map((s, i) => ({
    icon: stepIcons[i],
    title: t[`${s.key}Title`],
    desc: t[`${s.key}Desc`],
    detail: s.detail,
    color: stepColors[i],
  }));

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <Link to="/" className="fixed top-6 right-6 z-50 lg:hidden">
        <Button variant="outline" size="icon" className="rounded-full shadow-lg hover:bg-secondary">
          <Home className="w-5 h-5" />
        </Button>
      </Link>

      <main className="pt-32 pb-24 px-6">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-20"
          >
            <span className="text-sm font-semibold text-accent uppercase tracking-widest">{t.howItWorks}</span>
            <h1 className="font-display text-4xl sm:text-5xl font-bold text-foreground mt-4">
              {t.howTitle}
            </h1>
            <p className="mt-4 text-xl text-muted-foreground">{t.howSubtitle}</p>
          </motion.div>

          {/* Steps */}
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 via-violet-500 via-amber-500 to-emerald-500 opacity-20 hidden sm:block" />

            <div className="space-y-12">
              {steps.map((step, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="relative flex gap-6 sm:gap-8"
                >
                  {/* Icon */}
                  <div className={`flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg z-10`}>
                    <step.icon className="w-7 h-7 text-white" />
                  </div>

                  {/* Content */}
                  <div className="flex-1 bg-card rounded-3xl border border-border/50 p-6 hover:shadow-lg transition-shadow duration-300">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Stap {i + 1}</span>
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-2">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed mb-4">{step.desc}</p>
                    <ul className="space-y-1.5">
                      {step.detail.map((d, j) => (
                        <li key={j} className="flex items-center gap-2 text-sm text-foreground/80">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
                          {d}
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-20 text-center"
          >
            <div className="bg-gradient-to-r from-primary to-primary/80 rounded-3xl p-10 text-white">
              <h2 className="font-display text-3xl font-bold mb-3">{t.startNow}</h2>
              <p className="text-white/70 mb-8">14 dagen gratis · Geen creditcard · Direct live</p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/register">
                  <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90 h-13 px-8 text-base font-semibold shadow-xl">
                    {t.startNow}
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link to="/#pricing">
                  <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 h-13 px-8 text-base">
                    {t.seePricing}
                  </Button>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      <FooterSection />
    </div>
  );
}