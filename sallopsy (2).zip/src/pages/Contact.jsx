import React, { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Mail, Phone, MapPin, Clock, Send, CheckCircle2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { base44 } from "@/api/base44Client";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) return;
    setSending(true);
    await base44.integrations.Core.SendEmail({
      to: "info@sallopsy.nl",
      from_name: form.name,
      subject: `Contactformulier: ${form.subject || "Geen onderwerp"}`,
      body: `Naam: ${form.name}\nE-mail: ${form.email}\n\nBericht:\n${form.message}`,
    });
    setSent(true);
    setSending(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-5xl mx-auto px-6 pt-32 pb-20">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-10">
          <ArrowLeft className="w-4 h-4" />
          Terug naar home
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <h1 className="font-display text-4xl sm:text-5xl font-bold text-foreground mb-4">Neem contact op</h1>
          <p className="text-lg text-muted-foreground max-w-xl">
            Heb je een vraag, een demo-aanvraag of wil je meer weten? Wij reageren binnen één werkdag.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Info */}
          <div className="lg:col-span-2 space-y-8">
            {[
              { icon: Mail, title: "E-mail", value: "info@sallopsy.nl", sub: "We reageren binnen 24 uur" },
              { icon: Phone, title: "Telefoon", value: "+31 (0)20 123 4567", sub: "Ma-Vr 09:00 - 17:00" },
              { icon: MapPin, title: "Adres", value: "Keizersgracht 123", sub: "1015 CJ Amsterdam" },
              { icon: Clock, title: "Openingstijden", value: "Ma – Vr: 09:00 – 17:00", sub: "Zat & Zon: Gesloten" },
            ].map((item) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-start gap-4"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <item.icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">{item.title}</p>
                  <p className="text-foreground">{item.value}</p>
                  <p className="text-xs text-muted-foreground">{item.sub}</p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-3 bg-card border border-border rounded-2xl p-8"
          >
            {sent ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="w-8 h-8 text-emerald-600" />
                </div>
                <h3 className="font-bold text-foreground text-xl mb-2">Bericht verzonden!</h3>
                <p className="text-muted-foreground">We nemen zo snel mogelijk contact met je op.</p>
                <Button variant="outline" className="mt-6" onClick={() => { setSent(false); setForm({ name: "", email: "", subject: "", message: "" }); }}>
                  Nieuw bericht sturen
                </Button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label>Naam *</Label>
                    <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Jouw naam" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label>E-mail *</Label>
                    <Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} placeholder="jouw@email.nl" required />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Onderwerp</Label>
                  <Input value={form.subject} onChange={(e) => setForm({ ...form, subject: e.target.value })} placeholder="Bijv. Demo aanvragen, vraag over pricing..." />
                </div>
                <div className="space-y-1.5">
                  <Label>Bericht *</Label>
                  <Textarea value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} placeholder="Vertel ons meer..." rows={5} required />
                </div>
                <Button type="submit" disabled={sending} className="w-full h-12 text-base font-semibold">
                  {sending ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Send className="w-5 h-5 mr-2" />}
                  Verstuur bericht
                </Button>
              </form>
            )}
          </motion.div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
}