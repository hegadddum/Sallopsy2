import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ShieldCheck, ArrowLeft, CreditCard, Smartphone, Building2, Globe, Banknote, RefreshCcw } from "lucide-react";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";

const categories = [
  {
    icon: CreditCard,
    title: "Creditcards & Debetkaarten",
    color: "bg-blue-50 text-blue-600",
    methods: [
      { name: "Visa", desc: "Wereldwijd geaccepteerde betaalkaart", global: true },
      { name: "Mastercard", desc: "Internationaal beschikbaar in 210+ landen", global: true },
      { name: "American Express", desc: "Premium kaart populair in de VS en internationaal", global: true },
      { name: "Maestro", desc: "Europese debetkaart van Mastercard", global: false },
      { name: "V PAY", desc: "Europese debetkaart van Visa", global: false },
    ],
  },
  {
    icon: Smartphone,
    title: "Digitale Wallets & Mobiel",
    color: "bg-purple-50 text-purple-600",
    methods: [
      { name: "Apple Pay", desc: "Snel betalen via iPhone of Mac", global: true },
      { name: "Google Pay", desc: "Betalen via Android apparaten", global: true },
      { name: "PayPal", desc: "Veilig online betalen in 200+ landen", global: true },
      { name: "Klarna", desc: "Nu kopen, later betalen optie", global: true },
    ],
  },
  {
    icon: Building2,
    title: "Lokale Betaalmethoden",
    color: "bg-green-50 text-green-600",
    methods: [
      { name: "iDEAL", desc: "Meest gebruikte betaalmethode in Nederland", global: false },
      { name: "Bancontact", desc: "Meest gebruikte betaalmethode in België", global: false },
      { name: "Belfius", desc: "Belgische bank betaaloptie", global: false },
      { name: "KBC/CBC", desc: "Belgische bank betaaloptie", global: false },
      { name: "Giropay", desc: "Populair in Duitsland", global: false },
      { name: "EPS", desc: "Populair in Oostenrijk", global: false },
      { name: "Przelewy24", desc: "Populair in Polen", global: false },
      { name: "Twint", desc: "Populair in Zwitserland", global: false },
      { name: "Sofort", desc: "Directe bankoverschrijving in Europa", global: false },
    ],
  },
  {
    icon: Globe,
    title: "Bankoverschrijving",
    color: "bg-orange-50 text-orange-600",
    methods: [
      { name: "SEPA Overboeking", desc: "Grensoverschrijdende bankoverschrijving in Europa", global: false },
      { name: "SEPA Incasso", desc: "Automatische incasso voor abonnementen", global: false },
    ],
  },
  {
    icon: Banknote,
    title: "Betalen op locatie",
    color: "bg-emerald-50 text-emerald-600",
    methods: [
      { name: "Contant", desc: "Contante betaling in de salon", global: true },
      { name: "PIN / POS Terminal", desc: "Betalen met bankpas via pinterminal", global: true },
      { name: "NFC / Contactloos", desc: "Tik-en-betaal via kaart of telefoon", global: true },
    ],
  },
  {
    icon: RefreshCcw,
    title: "Abonnementen & Automatisch",
    color: "bg-rose-50 text-rose-600",
    methods: [
      { name: "Stripe Subscriptions", desc: "Automatische maandelijkse facturering voor memberships", global: true },
      { name: "Mollie Subscriptions", desc: "Terugkerende betalingen via Mollie", global: true },
    ],
  },
];

export default function PaymentOptions() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="max-w-5xl mx-auto px-6 pt-32 pb-20">
        {/* Header */}
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-10">
          <ArrowLeft className="w-4 h-4" />
          Terug naar home
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 bg-emerald-50 text-emerald-700 text-sm font-semibold px-4 py-2 rounded-full mb-6">
            <ShieldCheck className="w-4 h-4" />
            PCI DSS Compliant · 256-bit SSL · Veilig betalen
          </div>
          <h1 className="font-display text-4xl sm:text-5xl font-bold text-foreground mb-4">
            Betaalmogelijkheden
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Sallopsy ondersteunt alle gangbare betaalmethoden wereldwijd — van iDEAL en Bancontact tot creditcard en Apple Pay. Jouw klanten betalen altijd op de manier die hen het beste uitkomt.
          </p>
        </motion.div>

        {/* Categories */}
        <div className="space-y-12">
          {categories.map((cat, ci) => (
            <motion.div
              key={cat.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: ci * 0.05 }}
            >
              <div className="flex items-center gap-3 mb-6">
                <div className={`w-10 h-10 rounded-xl ${cat.color} flex items-center justify-center`}>
                  <cat.icon className="w-5 h-5" />
                </div>
                <h2 className="text-xl font-bold text-foreground">{cat.title}</h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {cat.methods.map((method) => (
                  <div
                    key={method.name}
                    className="bg-card border border-border rounded-xl p-5 flex items-start gap-4 hover:shadow-md transition-shadow"
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-semibold text-foreground text-sm">{method.name}</p>
                        {method.global && (
                          <span className="text-[10px] bg-blue-50 text-blue-600 font-semibold px-2 py-0.5 rounded-full">Wereldwijd</span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{method.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Security note */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 bg-emerald-50 border border-emerald-200 rounded-2xl p-8 text-center"
        >
          <ShieldCheck className="w-10 h-10 text-emerald-600 mx-auto mb-4" />
          <h3 className="font-bold text-foreground text-lg mb-2">Jouw betalingen zijn veilig</h3>
          <p className="text-muted-foreground text-sm max-w-xl mx-auto">
            Alle betalingen verlopen via PCI DSS gecertificeerde providers (Stripe & Mollie) met 256-bit SSL encryptie. Wij slaan nooit betaalgegevens op onze servers op.
          </p>
        </motion.div>
      </div>

      <FooterSection />
    </div>
  );
}