import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Heart, Target, Zap, Users, Globe, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";

const values = [
  { icon: Heart, title: "Salons eerst", desc: "Elk besluit begint met de vraag: wat helpt saloneigenaren het beste?" },
  { icon: Target, title: "Eenvoud", desc: "Krachtige software hoeft niet ingewikkeld te zijn. Wij maken het simpel." },
  { icon: Zap, title: "Innovatie", desc: "AI en automatisering zijn geen toekomstmuziek — ze zitten al in ons platform." },
  { icon: Shield, title: "Vertrouwen", desc: "Data van onze klanten behandelen wij als onze eigen. Veiligheid en privacy staan voorop." },
  { icon: Users, title: "Community", desc: "Wij bouwen samen met saloneigenaren. Feedback van gebruikers stuurt onze roadmap." },
  { icon: Globe, title: "Internationaal", desc: "Gebouwd voor Nederland en België, maar klaar voor heel Europa." },
];

const team = [
  {
    name: "Lars van Dijk",
    role: "CEO & Mede-oprichter",
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=200&h=200&fit=crop&q=80",
    bio: "Voormalig kapper, nu bouwer van software die kappers helpt.",
  },
  {
    name: "Aisha Müller",
    role: "CTO & Mede-oprichter",
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&q=80",
    bio: "10 jaar ervaring in SaaS-producten bij grote tech-bedrijven.",
  },
  {
    name: "Pieter Janssen",
    role: "Head of Product",
    avatar: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&h=200&fit=crop&q=80",
    bio: "Obsessief bezig met gebruikerservaring en klantonderzoek.",
  },
  {
    name: "Sara Benali",
    role: "Head of Customer Success",
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop&q=80",
    bio: "Zorgt ervoor dat elke salon succesvol aan boord komt.",
  },
];

export default function AboutUs() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-5xl mx-auto px-6 pt-32 pb-20">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-10">
          <ArrowLeft className="w-4 h-4" />
          Terug naar home
        </Link>

        {/* Hero */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-20">
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
            Wij geloven dat elke<br />
            <span className="text-primary">salon kan floreren</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Sallopsy is opgericht in 2023 door Lars en Aisha — een voormalige kapper en een software-ingenieur — met één doel: saloneigenaren bevrijden van administratie zodat zij zich kunnen richten op hun vak en hun klanten.
          </p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-6 mb-20 p-8 bg-card border border-border rounded-2xl"
        >
          {[
            { value: "2023", label: "Opgericht" },
            { value: "500+", label: "Actieve salons" },
            { value: "NL & BE", label: "Aanwezig in" },
            { value: "4.9★", label: "Gemiddelde score" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <p className="text-3xl font-bold text-foreground">{stat.value}</p>
              <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
            </div>
          ))}
        </motion.div>

        {/* Verhaal */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h2 className="font-display text-3xl font-bold text-foreground mb-6">Ons verhaal</h2>
          <div className="prose prose-muted max-w-none space-y-4 text-muted-foreground leading-relaxed">
            <p>Lars werkte jarenlang als kapper in Amsterdam. Elke dag verloor hij kostbare tijd aan het handmatig bijhouden van afspraken in een Excel-sheet, het sturen van herinneringen per WhatsApp en het proberen begrijpen welke producten goed liepen.</p>
            <p>Hij ontmoette Aisha, die als software-ingenieur bij een groot tech-bedrijf werkte. Samen besloten ze: dit kan beter. Veel beter. Ze bouwden de eerste versie van Sallopsy in een garage in Amsterdam-Noord.</p>
            <p>Vandaag gebruiken meer dan 500 salons Sallopsy dagelijks om afspraken te beheren, klanten te binden en slimmer in te kopen. En wij zijn nog maar net begonnen.</p>
          </div>
        </motion.div>

        {/* Waarden */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h2 className="font-display text-3xl font-bold text-foreground mb-8">Onze waarden</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {values.map((v, i) => (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="bg-card border border-border rounded-2xl p-6"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-4">
                  <v.icon className="w-5 h-5 text-primary" />
                </div>
                <h3 className="font-bold text-foreground mb-2">{v.title}</h3>
                <p className="text-sm text-muted-foreground">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Team */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <h2 className="font-display text-3xl font-bold text-foreground mb-8">Het team</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {team.map((member, i) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.07 }}
                className="bg-card border border-border rounded-2xl p-6 text-center"
              >
                <img src={member.avatar} alt={member.name} className="w-20 h-20 rounded-full object-cover mx-auto mb-4" />
                <h3 className="font-bold text-foreground">{member.name}</h3>
                <p className="text-xs text-primary font-semibold mb-2">{member.role}</p>
                <p className="text-xs text-muted-foreground">{member.bio}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center bg-primary rounded-2xl p-12"
        >
          <h2 className="font-display text-3xl font-bold text-primary-foreground mb-4">Sluit je aan bij 500+ salons</h2>
          <p className="text-primary-foreground/80 mb-8">Start vandaag gratis. Geen creditcard nodig.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold px-8">
                Gratis starten
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8">
                Contact opnemen
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
      <FooterSection />
    </div>
  );
}