import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Shield } from "lucide-react";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";

const sections = [
  {
    title: "1. Wie zijn wij?",
    content: `Sallopsy is een product van Sallopsy B.V., gevestigd te Amsterdam, Nederland. Wij ontwikkelen en beheren het Salon Operating System voor salons. Voor vragen over privacy: privacy@sallopsy.nl.`,
  },
  {
    title: "2. Welke gegevens verzamelen wij?",
    content: `Wij verzamelen de volgende persoonsgegevens:
• Accountgegevens: naam, e-mailadres, telefoonnummer bij registratie.
• Gebruiksgegevens: hoe je het platform gebruikt (pagina's, klikken, sessieduur).
• Afspraakgegevens: naam, e-mail en telefoonnummer van eindklanten die via de boekingspagina een afspraak maken.
• Betalingsgegevens: worden uitsluitend verwerkt door onze gecertificeerde betalingsproviders (Stripe, Mollie). Wij bewaren zelf geen betaalgegevens.`,
  },
  {
    title: "3. Waarvoor gebruiken wij uw gegevens?",
    content: `Uw gegevens worden gebruikt voor:
• Het leveren en verbeteren van onze diensten.
• Het versturen van afspraakbevestigingen en -herinneringen.
• Facturering en betalingsverwerking.
• Communicatie over uw account of ondersteuning.
• Wettelijke verplichtingen.`,
  },
  {
    title: "4. Hoe lang bewaren wij uw gegevens?",
    content: `Wij bewaren uw persoonsgegevens niet langer dan noodzakelijk. Accountgegevens worden bewaard zolang uw account actief is. Na opzegging worden gegevens binnen 30 dagen verwijderd, tenzij wettelijke bewaarplichten van toepassing zijn (bijv. 7 jaar voor boekhoudkundige gegevens).`,
  },
  {
    title: "5. Delen wij uw gegevens?",
    content: `Wij delen gegevens alleen met:
• Verwerkers die wij inzetten (bijv. hosting, e-mailproviders, betalingsproviders) — op basis van verwerkersovereenkomsten.
• Overheidsinstanties wanneer wettelijk verplicht.
Wij verkopen uw gegevens nooit aan derden.`,
  },
  {
    title: "6. Uw rechten (AVG/GDPR)",
    content: `Op grond van de AVG heeft u de volgende rechten:
• Inzage: u kunt een overzicht opvragen van uw gegevens.
• Correctie: u kunt onjuiste gegevens laten aanpassen.
• Verwijdering: u kunt vragen uw gegevens te verwijderen.
• Bezwaar: u kunt bezwaar maken tegen verwerking.
• Dataportabiliteit: u kunt uw gegevens opvragen in een machine-leesbaar formaat.
Stuur uw verzoek naar privacy@sallopsy.nl. Wij reageren binnen 30 dagen.`,
  },
  {
    title: "7. Beveiliging",
    content: `Wij nemen technische en organisatorische maatregelen om uw gegevens te beschermen: 256-bit SSL-encryptie, toegangsbeveiliging, regelmatige back-ups en beveiligingstests. Alle data wordt opgeslagen binnen de Europese Unie.`,
  },
  {
    title: "8. Cookies",
    content: `Wij gebruiken functionele cookies (noodzakelijk voor de werking van de site) en analytische cookies (om het gebruik te begrijpen, geanonimiseerd). U kunt cookies beheren via uw browserinstellingen. Zie ook ons Cookiebeleid.`,
  },
  {
    title: "9. Wijzigingen",
    content: `Dit privacybeleid kan worden aangepast. Bij wezenlijke wijzigingen informeren wij u via e-mail of een melding in het platform. De actuele versie is altijd beschikbaar op deze pagina. Laatste update: juni 2026.`,
  },
];

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-3xl mx-auto px-6 pt-32 pb-20">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-10">
          <ArrowLeft className="w-4 h-4" />
          Terug naar home
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary text-sm font-semibold px-4 py-2 rounded-full mb-6">
            <Shield className="w-4 h-4" />
            AVG/GDPR Compliant
          </div>
          <h1 className="font-display text-4xl font-bold text-foreground mb-4">Privacybeleid</h1>
          <p className="text-muted-foreground">Laatste update: juni 2026</p>
        </motion.div>

        <div className="space-y-8">
          {sections.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.04 }}
            >
              <h2 className="font-bold text-foreground text-lg mb-3">{s.title}</h2>
              <p className="text-muted-foreground text-sm leading-relaxed whitespace-pre-line">{s.content}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <FooterSection />
    </div>
  );
}