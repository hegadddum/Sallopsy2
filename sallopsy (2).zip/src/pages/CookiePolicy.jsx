import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowLeft, Cookie } from "lucide-react";
import Navbar from "@/components/landing/Navbar";
import FooterSection from "@/components/landing/FooterSection";

const cookieTypes = [
  {
    name: "Functionele cookies",
    required: true,
    desc: "Noodzakelijk voor de werking van de website. Ze onthouden inlogstatus, taalvoorkeur en winkelmandje. Kunnen niet worden uitgeschakeld.",
    examples: ["auth_token", "language", "cart_session"],
    retention: "Sessie tot max. 30 dagen",
  },
  {
    name: "Analytische cookies",
    required: false,
    desc: "Helpen ons begrijpen hoe bezoekers de site gebruiken, zodat we deze kunnen verbeteren. Gegevens worden geanonimiseerd verwerkt.",
    examples: ["_ga (Google Analytics)", "_gid", "plausible"],
    retention: "Max. 2 jaar",
  },
  {
    name: "Marketingcookies",
    required: false,
    desc: "Worden gebruikt om relevante advertenties te tonen op andere websites. Wij gebruiken deze op dit moment niet actief.",
    examples: ["Geen actieve marketingcookies"],
    retention: "N.v.t.",
  },
];

export default function CookiePolicy() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="max-w-3xl mx-auto px-6 pt-32 pb-20">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-10">
          <ArrowLeft className="w-4 h-4" />
          Terug naar home
        </Link>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-12">
          <div className="inline-flex items-center gap-2 bg-accent/10 text-accent text-sm font-semibold px-4 py-2 rounded-full mb-6">
            <Cookie className="w-4 h-4" />
            Transparantie over cookies
          </div>
          <h1 className="font-display text-4xl font-bold text-foreground mb-4">Cookiebeleid</h1>
          <p className="text-muted-foreground">Laatste update: juni 2026</p>
        </motion.div>

        <div className="space-y-6 mb-12">
          <div>
            <h2 className="font-bold text-foreground text-lg mb-3">Wat zijn cookies?</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Cookies zijn kleine tekstbestanden die door uw browser worden opgeslagen wanneer u onze website bezoekt. Ze helpen de site correct te laten functioneren en geven ons inzicht in het gebruik.
            </p>
          </div>

          <div>
            <h2 className="font-bold text-foreground text-lg mb-3">Welke cookies gebruiken wij?</h2>
          </div>
        </div>

        <div className="space-y-4 mb-12">
          {cookieTypes.map((type, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-card border border-border rounded-2xl p-6"
            >
              <div className="flex items-center gap-3 mb-3">
                <h3 className="font-bold text-foreground">{type.name}</h3>
                <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${type.required ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"}`}>
                  {type.required ? "Verplicht" : "Optioneel"}
                </span>
              </div>
              <p className="text-sm text-muted-foreground mb-4">{type.desc}</p>
              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <p className="font-semibold text-foreground mb-1">Voorbeelden</p>
                  {type.examples.map((ex) => (
                    <p key={ex} className="text-muted-foreground font-mono">{ex}</p>
                  ))}
                </div>
                <div>
                  <p className="font-semibold text-foreground mb-1">Bewaartermijn</p>
                  <p className="text-muted-foreground">{type.retention}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="space-y-6">
          <div>
            <h2 className="font-bold text-foreground text-lg mb-3">Cookies beheren</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              U kunt cookies uitschakelen via uw browserinstellingen. Let op: het uitschakelen van functionele cookies kan de werking van de site beïnvloeden. Raadpleeg de helpfunctie van uw browser voor instructies.
            </p>
          </div>
          <div>
            <h2 className="font-bold text-foreground text-lg mb-3">Vragen?</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Heeft u vragen over ons cookiebeleid? Neem contact op via{" "}
              <a href="mailto:privacy@sallopsy.nl" className="text-primary hover:underline">privacy@sallopsy.nl</a>
              {" "}of bezoek onze{" "}
              <Link to="/contact" className="text-primary hover:underline">contactpagina</Link>.
            </p>
          </div>
        </div>
      </div>
      <FooterSection />
    </div>
  );
}