import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle
} from "@/components/ui/dialog";
import { Plus, Clock, Euro, MoreHorizontal, Pencil, Trash2, Scissors, Loader2 } from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";

const categoryLabels = {
  knippen: "Knippen",
  kleuren: "Kleuren",
  styling: "Styling",
  verzorging: "Verzorging",
  baard: "Baard",
  overig: "Overig",
};

const categoryGradients = {
  knippen: "from-blue-500 to-indigo-600",
  kleuren: "from-pink-500 to-rose-600",
  styling: "from-violet-500 to-purple-600",
  verzorging: "from-emerald-500 to-teal-600",
  baard: "from-amber-500 to-orange-600",
  overig: "from-slate-500 to-gray-600",
};

function ServiceForm({ service, onSave, onCancel }) {
  const [form, setForm] = useState({
    name: "",
    description: "",
    duration: 30,
    price: 0,
    category: "knippen",
    is_active: true,
    ...service,
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    await onSave(form);
    setSaving(false);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <div className="space-y-2">
        <Label>Naam *</Label>
        <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
      </div>
      <div className="space-y-2">
        <Label>Beschrijving</Label>
        <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label>Duur (min) *</Label>
          <Input type="number" value={form.duration} onChange={(e) => setForm({ ...form, duration: parseInt(e.target.value) || 0 })} required />
        </div>
        <div className="space-y-2">
          <Label>Prijs (€) *</Label>
          <Input type="number" step="0.01" value={form.price} onChange={(e) => setForm({ ...form, price: parseFloat(e.target.value) || 0 })} required />
        </div>
        <div className="space-y-2">
          <Label>Categorie</Label>
          <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(categoryLabels).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Switch checked={form.is_active} onCheckedChange={(v) => setForm({ ...form, is_active: v })} />
        <Label>Dienst actief</Label>
      </div>
      <div className="flex justify-end gap-3 pt-2">
        <Button type="button" variant="outline" onClick={onCancel}>Annuleren</Button>
        <Button type="submit" disabled={saving}>
          {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
          {service ? "Bijwerken" : "Dienst toevoegen"}
        </Button>
      </div>
    </form>
  );
}

export default function Services() {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const queryClient = useQueryClient();

  const { data: services = [], isLoading } = useQuery({
    queryKey: ["services"],
    queryFn: () => base44.entities.Service.list("name", 200),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Service.create(data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["services"] }); setShowForm(false); },
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Service.update(id, data),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["services"] }); setShowForm(false); setEditing(null); },
  });
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Service.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["services"] }),
  });

  const handleSave = async (data) => {
    if (editing) {
      await updateMutation.mutateAsync({ id: editing.id, data });
    } else {
      await createMutation.mutateAsync(data);
    }
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-foreground">Diensten</h1>
          <p className="text-muted-foreground mt-1">Beheer je behandelingen en prijzen</p>
        </div>
        <Button onClick={() => { setEditing(null); setShowForm(true); }} className="bg-primary">
          <Plus className="w-4 h-4 mr-2" /> Dienst toevoegen
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-card rounded-2xl border border-border/50 p-6 animate-pulse">
              <div className="h-12 w-12 bg-muted rounded-xl mb-4" />
              <div className="h-5 w-32 bg-muted rounded mb-2" />
              <div className="h-4 w-24 bg-muted rounded" />
            </div>
          ))}
        </div>
      ) : services.length === 0 ? (
        <div className="text-center py-16">
          <Scissors className="w-16 h-16 mx-auto mb-4 text-muted-foreground/20" />
          <p className="text-muted-foreground">Nog geen diensten toegevoegd</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {services.map((service) => (
            <div key={service.id} className="bg-card rounded-2xl border border-border/50 p-6 hover:shadow-lg hover:shadow-black/5 transition-all duration-300 group">
              <div className="flex items-start justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${categoryGradients[service.category] || categoryGradients.overig} flex items-center justify-center`}>
                  <Scissors className="w-5 h-5 text-white" />
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => { setEditing(service); setShowForm(true); }}>
                      <Pencil className="w-4 h-4 mr-2" /> Bewerken
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive" onClick={() => deleteMutation.mutate(service.id)}>
                      <Trash2 className="w-4 h-4 mr-2" /> Verwijderen
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <h3 className="text-lg font-semibold text-foreground">{service.name}</h3>
              {service.description && <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{service.description}</p>}
              
              <div className="flex items-center gap-4 mt-4">
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{service.duration} min</span>
                </div>
                <div className="flex items-center gap-1.5 text-sm font-semibold text-foreground">
                  <Euro className="w-3.5 h-3.5" />
                  <span>{service.price}</span>
                </div>
                <Badge className="text-xs ml-auto" variant="secondary">
                  {categoryLabels[service.category] || service.category}
                </Badge>
              </div>

              {!service.is_active && (
                <Badge className="mt-3 bg-muted text-muted-foreground text-xs">Inactief</Badge>
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {editing ? "Dienst bewerken" : "Nieuwe dienst"}
            </DialogTitle>
          </DialogHeader>
          <ServiceForm
            service={editing}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditing(null); }}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}