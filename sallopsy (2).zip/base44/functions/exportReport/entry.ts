import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const user = await base44.auth.me();
        if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

        const body = await req.json();
        const { type = 'appointments', period = 'month' } = body;

        const doc = new jsPDF();
        const now = new Date();

        // Header
        doc.setFontSize(22);
        doc.setTextColor(30, 41, 99);
        doc.text('Sallopsy Rapport', 20, 22);
        doc.setFontSize(11);
        doc.setTextColor(100, 100, 100);
        doc.text(`Gegenereerd: ${now.toLocaleDateString('nl-NL')} om ${now.toLocaleTimeString('nl-NL', { hour: '2-digit', minute: '2-digit' })}`, 20, 32);

        let y = 48;

        if (type === 'appointments') {
            const appointments = await base44.entities.Appointment.list('-date', 500);
            const filtered = period === 'month'
                ? appointments.filter(a => a.date?.startsWith(now.toISOString().slice(0, 7)))
                : appointments;

            const completed = filtered.filter(a => a.status === 'voltooid');
            const revenue = completed.reduce((s, a) => s + (a.price || 0), 0);

            doc.setFontSize(16);
            doc.setTextColor(30, 41, 99);
            doc.text('Afspraken Overzicht', 20, y); y += 10;

            doc.setFontSize(10);
            doc.setTextColor(80, 80, 80);
            doc.text(`Periode: ${period === 'month' ? 'Deze maand' : 'Alle tijd'}`, 20, y); y += 6;
            doc.text(`Totaal afspraken: ${filtered.length}`, 20, y); y += 6;
            doc.text(`Voltooide afspraken: ${completed.length}`, 20, y); y += 6;
            doc.text(`Totale omzet: €${revenue.toFixed(2)}`, 20, y); y += 6;
            doc.text(`Gemiddelde orderwaarde: €${completed.length > 0 ? (revenue / completed.length).toFixed(2) : '0.00'}`, 20, y); y += 14;

            // Table header
            doc.setFontSize(9);
            doc.setTextColor(30, 41, 99);
            doc.text('Datum', 20, y);
            doc.text('Klant', 50, y);
            doc.text('Dienst', 100, y);
            doc.text('Prijs', 155, y);
            doc.text('Status', 175, y);
            y += 4;
            doc.setDrawColor(200, 200, 200);
            doc.line(20, y, 190, y); y += 6;

            doc.setTextColor(60, 60, 60);
            for (const appt of filtered.slice(0, 50)) {
                if (y > 270) { doc.addPage(); y = 20; }
                doc.text((appt.date || '').slice(0, 10), 20, y);
                doc.text((appt.client_name || '').slice(0, 20), 50, y);
                doc.text((appt.service_name || '').slice(0, 22), 100, y);
                doc.text(`€${appt.price || 0}`, 155, y);
                doc.text(appt.status || '', 175, y);
                y += 7;
            }

        } else if (type === 'clients') {
            const clients = await base44.entities.Client.list('first_name', 500);

            doc.setFontSize(16);
            doc.setTextColor(30, 41, 99);
            doc.text('Klantenlijst', 20, y); y += 10;

            doc.setFontSize(10);
            doc.setTextColor(80, 80, 80);
            doc.text(`Totaal klanten: ${clients.length}`, 20, y); y += 6;
            doc.text(`VIP klanten: ${clients.filter(c => c.status === 'vip').length}`, 20, y); y += 14;

            doc.setFontSize(9);
            doc.setTextColor(30, 41, 99);
            doc.text('Naam', 20, y);
            doc.text('Telefoon', 80, y);
            doc.text('E-mail', 120, y);
            doc.text('Status', 175, y);
            y += 4;
            doc.line(20, y, 190, y); y += 6;

            doc.setTextColor(60, 60, 60);
            for (const c of clients.slice(0, 60)) {
                if (y > 270) { doc.addPage(); y = 20; }
                doc.text(`${c.first_name || ''} ${c.last_name || ''}`.slice(0, 25), 20, y);
                doc.text((c.phone || '—').slice(0, 18), 80, y);
                doc.text((c.email || '—').slice(0, 22), 120, y);
                doc.text(c.status || 'active', 175, y);
                y += 7;
            }
        }

        const pdfBytes = doc.output('arraybuffer');
        return new Response(pdfBytes, {
            status: 200,
            headers: {
                'Content-Type': 'application/pdf',
                'Content-Disposition': `attachment; filename=sallopsy-${type}-rapport.pdf`,
            },
        });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});