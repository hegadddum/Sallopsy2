import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);

        // Get appointments for tomorrow
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const tomorrowStr = tomorrow.toISOString().split('T')[0];

        const appointments = await base44.asServiceRole.entities.Appointment.filter({
            date: tomorrowStr,
            status: "bevestigd"
        });

        let sent = 0;
        let skipped = 0;

        for (const appt of appointments) {
            // First try client_email on the appointment itself
            let emailTo = appt.client_email || null;
            let firstName = appt.client_name || 'klant';

            // Fallback: look up client record
            if (!emailTo && appt.client_id) {
                const clients = await base44.asServiceRole.entities.Client.filter({ id: appt.client_id });
                const client = clients[0];
                if (client?.email) {
                    emailTo = client.email;
                    firstName = client.first_name || firstName;
                }
            }

            if (!emailTo) { skipped++; continue; }

            await base44.asServiceRole.integrations.Core.SendEmail({
                to: emailTo,
                subject: `Herinnering: Uw afspraak morgen bij Sallopsy`,
                from_name: "Sallopsy",
                body: `Beste ${firstName},\n\nDit is een herinnering voor uw afspraak morgen:\n\n📅 Datum: ${appt.date}\n🕐 Tijd: ${appt.time}\n✂️ Behandeling: ${appt.service_name}${appt.staff_member ? `\n👤 Medewerker: ${appt.staff_member}` : ''}\n💰 Prijs: €${appt.price || 0}\n\nWij verwachten u morgen! Mochten er vragen zijn, neem dan gerust contact op.\n\nMet vriendelijke groet,\nHet team van Sallopsy`
            });
            sent++;
        }

        return Response.json({ success: true, sent, skipped, date: tomorrowStr });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});