import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch appointments and products
    const [appointments, products] = await Promise.all([
      base44.asServiceRole.entities.Appointment.list('-date', 500),
      base44.asServiceRole.entities.Product.list()
    ]);

    const now = new Date();
    const last6Months = new Date(now.getFullYear(), now.getMonth() - 6, 1);
    
    const recentAppts = appointments.filter(a => {
      if (!a.date) return false;
      const apptDate = new Date(a.date);
      return apptDate >= last6Months;
    });

    if (recentAppts.length === 0 || products.length === 0) {
      return Response.json({
        productForecast: null,
        message: 'Onvoldoende data beschikbaar'
      });
    }

    // Analyze service patterns and product categories
    const serviceFrequency = {};
    recentAppts.forEach(a => {
      const service = a.service_name || 'onbekend';
      serviceFrequency[service] = (serviceFrequency[service] || 0) + 1;
    });

    const productCategories = {};
    products.forEach(p => {
      if (p.category) {
        productCategories[p.category] = {
          count: (productCategories[p.category]?.count || 0) + 1,
          avgPrice: (productCategories[p.category]?.avgPrice || 0) + (p.price_sell || 0),
          stock: (productCategories[p.category]?.stock || 0) + (p.stock || 0)
        };
      }
    });

    const prompt = `
    Analyseer de volgende salongegevens en voorspel welke verzorgingsproducten en andere producten waarschijnlijk meer vraag zullen hebben.
    
    Top diensten (afgelopen 6 maanden):
    ${Object.entries(serviceFrequency)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([s, c]) => `${s}: ${c} afspraken`)
      .join('\n')}
    
    Huidge producten per categorie:
    ${Object.entries(productCategories)
      .map(([cat, data]) => `${cat}: ${data.count} producten, ${data.stock} stuks voorraad`)
      .join('\n')}
    
    Geef een voorspelling met:
    1. Top 5 producten die waarschijnlijk meer verkocht zullen worden
    2. Categorieën met laag voorraadbeheer risico
    3. Aanbevolen new products gebaseerd op service trends
    4. Specifieke aanbevelingen voor webshop focus
    
    Focus op praktische, concrete aanbevelingen.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          topProducts: {
            type: 'array',
            items: { type: 'string' },
            description: 'Top 5 producten met groeiende vraag'
          },
          lowStockWarnings: {
            type: 'array',
            items: { type: 'string' },
            description: 'Waarschuwingen voor lage voorraden'
          },
          recommendedNewProducts: {
            type: 'array',
            items: { type: 'string' },
            description: 'Aanbevolen nieuwe producten'
          },
          webshopFocus: {
            type: 'array',
            items: { type: 'string' },
            description: 'Aanbevelingen voor webshop marketing'
          },
          demandRating: {
            type: 'string',
            description: 'Verwachte vraagniveau (Laag/Gemiddeld/Hoog)'
          }
        }
      }
    });

    return Response.json({
      productForecast: result,
      analysisData: {
        serviceFrequency,
        productStats: productCategories
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});