import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const [clients, appointments] = await Promise.all([
      base44.asServiceRole.entities.Client.list(),
      base44.asServiceRole.entities.Appointment.list('-date', 500)
    ]);

    if (clients.length === 0) {
      return Response.json({ insights: null, message: 'Geen klanten beschikbaar' });
    }

    // Analyze client data
    const clientStats = clients.map(c => {
      const clientAppts = appointments.filter(a => a.client_id === c.id);
      const completedAppts = clientAppts.filter(a => a.status === 'voltooid');
      const totalSpent = completedAppts.reduce((sum, a) => sum + (a.price || 0), 0);
      
      return {
        name: `${c.first_name} ${c.last_name}`,
        visits: c.total_visits || completedAppts.length,
        spent: totalSpent,
        status: c.status,
        lastVisit: c.last_visit,
        frequency: completedAppts.length > 0 ? (completedAppts.length / Math.max(1, (new Date() - new Date(completedAppts[0].date)) / (1000 * 60 * 60 * 24 * 30))) : 0
      };
    });

    const topClients = clientStats.sort((a, b) => b.spent - a.spent).slice(0, 10);
    const atRiskClients = clientStats.filter(c => c.lastVisit && (new Date() - new Date(c.lastVisit)) / (1000 * 60 * 60 * 24) > 90);

    const prompt = `
    Analyseer deze klantengegevens en geef actionable inzichten:
    
    Top 10 klanten (op omzet):
    ${topClients.map(c => `${c.name}: €${c.spent.toFixed(2)}, ${c.visits} bezoeken, frequentie: ${c.frequency.toFixed(1)} per maand`).join('\n')}
    
    Risicogroep (>90 dagen geen bezoek):
    ${atRiskClients.length} klanten
    
    Totaal klanten: ${clients.length}
    VIP klanten: ${clientStats.filter(c => c.status === 'vip').length}
    
    Geef:
    1. Top 3 klanten voor retentie focus
    2. Groepen voor gericht marketing
    3. Churn risk inschattingen
    4. Upsell mogelijkheden per groep
    
    Wees specifiek en actionable.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          retentionFocus: {
            type: 'array',
            items: { type: 'string' },
            description: 'Klanten voor retentie focus'
          },
          marketingSegments: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                segment: { type: 'string' },
                strategy: { type: 'string' },
                estimatedValue: { type: 'string' }
              }
            },
            description: 'Marketing segmentatie'
          },
          churnRisk: {
            type: 'array',
            items: { type: 'string' },
            description: 'Churn-risico klanten'
          },
          upsellOpportunities: {
            type: 'array',
            items: { type: 'string' },
            description: 'Upsell kansen'
          },
          nextActions: {
            type: 'array',
            items: { type: 'string' },
            description: 'Aanbevolen acties'
          }
        }
      }
    });

    return Response.json({
      insights: result,
      clientStats: {
        topClients,
        atRiskCount: atRiskClients.length,
        totalClients: clients.length,
        vipCount: clientStats.filter(c => c.status === 'vip').length
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});