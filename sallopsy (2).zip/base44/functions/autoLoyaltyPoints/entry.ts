import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const { event } = await req.json();

    if (!event || event.type !== 'update') {
      return Response.json({ message: 'Not an update event' });
    }

    const appointmentId = event.entity_id;
    const appointment = await base44.asServiceRole.entities.Appointment.get(appointmentId);

    if (!appointment || appointment.status !== 'voltooid') {
      return Response.json({ message: 'Appointment not completed' });
    }

    // Check if loyalty already awarded for this appointment
    const existingTx = await base44.asServiceRole.entities.LoyaltyTransaction.filter({
      appointment_id: appointmentId
    });

    if (existingTx.length > 0) {
      return Response.json({ message: 'Loyalty already awarded' });
    }

    // Calculate points: 1 euro = 1 point
    const points = Math.floor(appointment.price || 0);
    if (points > 0) {
      await base44.asServiceRole.entities.LoyaltyTransaction.create({
        client_id: appointment.client_id,
        client_name: appointment.client_name,
        points,
        type: 'verdienen',
        description: `Punten voor ${appointment.service_name}`,
        appointment_id: appointmentId
      });

      return Response.json({
        success: true,
        pointsAwarded: points,
        message: `${points} punten toegekend`
      });
    }

    return Response.json({ message: 'No price set' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});