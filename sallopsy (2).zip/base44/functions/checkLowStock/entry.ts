import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);

        const products = await base44.asServiceRole.entities.Product.list("name", 500);
        const lowStock = products.filter(p => p.is_active && (p.stock || 0) < (p.min_stock || 5));

        if (lowStock.length === 0) {
            return Response.json({ success: true, message: "Geen lage voorraad", count: 0 });
        }

        // Get admin users to notify
        const users = await base44.asServiceRole.entities.User.list();
        const admins = users.filter(u => u.role === 'admin');

        const productList = lowStock.map(p =>
            `• ${p.name}${p.brand ? ` (${p.brand})` : ''}: ${p.stock || 0}/${p.min_stock || 5} ${p.unit || 'stuks'}`
        ).join('\n');

        for (const admin of admins) {
            if (!admin.email) continue;
            await base44.asServiceRole.integrations.Core.SendEmail({
                to: admin.email,
                subject: `⚠️ Lage voorraad melding – ${lowStock.length} product(en) bijna op`,
                from_name: "Sallopsy Voorraad",
                body: `Beste ${admin.full_name || 'beheerder'},\n\nDe volgende producten hebben een lage voorraad:\n\n${productList}\n\nBestuur direct via het voorraadoverzicht in Sallopsy.\n\nMet vriendelijke groet,\nSallopsy Systeem`
            });
        }

        return Response.json({ success: true, count: lowStock.length, products: lowStock.map(p => p.name) });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});