import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const products = await base44.asServiceRole.entities.Product.list();

    // Analyze stock levels
    const critical = [];
    const warning = [];
    const optimal = [];

    products.forEach(p => {
      if (!p.is_active) return;

      const stockPercentage = p.min_stock > 0 ? (p.stock / p.min_stock) * 100 : 100;
      
      if (stockPercentage <= 25) {
        critical.push({
          name: p.name,
          category: p.category,
          current: p.stock,
          minimum: p.min_stock,
          daysToRunOut: p.stock > 0 ? 7 : 0,
          lastUpdate: p.updated_date,
          buyPrice: p.price_buy,
          recommendation: stockPercentage === 0 ? 'URGENT - Bestel onmiddellijk' : 'Bestel snel'
        });
      } else if (stockPercentage <= 60) {
        warning.push({
          name: p.name,
          category: p.category,
          current: p.stock,
          minimum: p.min_stock,
          daysToRunOut: Math.ceil(p.stock / Math.max(1, p.min_stock / 30)),
          recommendation: 'Plan bestelling'
        });
      } else {
        optimal.push({
          name: p.name,
          current: p.stock,
          minimum: p.min_stock
        });
      }
    });

    // Calculate costs and priorities
    const criticalValue = critical.reduce((sum, p) => sum + (p.current * (p.buyPrice || 0)), 0);
    const recommendedOrders = critical.map(p => ({
      product: p.name,
      category: p.category,
      urgency: p.current === 0 ? 'CRITICAL' : 'HIGH',
      suggestedQuantity: (p.minimum * 3) - p.current,
      estimatedCost: ((p.minimum * 3) - p.current) * (p.buyPrice || 0)
    }));

    return Response.json({
      stockStatus: {
        critical: critical.length,
        warning: warning.length,
        optimal: optimal.length,
        criticalValue: criticalValue.toFixed(2),
        totalProducts: products.length
      },
      alerts: {
        critical,
        warning
      },
      recommendations: {
        immediateOrders: recommendedOrders.filter(o => o.urgency === 'CRITICAL'),
        plannedOrders: recommendedOrders.filter(o => o.urgency === 'HIGH'),
        totalEstimatedCost: recommendedOrders.reduce((sum, o) => sum + o.estimatedCost, 0).toFixed(2)
      },
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});