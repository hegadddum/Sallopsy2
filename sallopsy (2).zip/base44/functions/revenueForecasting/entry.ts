import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch appointments from last 12 months
    const appointments = await base44.asServiceRole.entities.Appointment.list('-date', 1000);
    const now = new Date();
    const last12Months = new Date(now.getFullYear() - 1, now.getMonth(), 1);
    
    const filteredAppts = appointments.filter(a => {
      if (!a.date) return false;
      const apptDate = new Date(a.date);
      return apptDate >= last12Months && a.status === 'voltooid' && a.price;
    });

    if (filteredAppts.length === 0) {
      return Response.json({
        forecast: null,
        message: 'Onvoldoende historische data beschikbaar'
      });
    }

    // Prepare data for LLM analysis
    const monthlyRevenue = {};
    filteredAppts.forEach(a => {
      const month = a.date.substring(0, 7);
      monthlyRevenue[month] = (monthlyRevenue[month] || 0) + (a.price || 0);
    });

    const monthlyCount = {};
    filteredAppts.forEach(a => {
      const month = a.date.substring(0, 7);
      monthlyCount[month] = (monthlyCount[month] || 0) + 1;
    });

    const prompt = `
    Analyseer de volgende historische omzet- en afspraakgegevens van een salon en maak een prognose voor de komende 3 maanden.
    
    Maandelijkse omzet (vorig jaar):
    ${Object.entries(monthlyRevenue).map(([m, r]) => `${m}: €${r.toFixed(2)}`).join('\n')}
    
    Aantal afspraken per maand:
    ${Object.entries(monthlyCount).map(([m, c]) => `${m}: ${c} afspraken`).join('\n')}
    
    Huidige maand: ${now.toISOString().substring(0, 7)}
    
    Geef een analyse met:
    1. Duidelijke seizoenspatronen
    2. Verwachte omzet voor de komende 3 maanden
    3. Aanbevelingen om omzet te verhogen
    4. Waarschuwingen voor mogelijke dips
    
    Maak de prognose op basis van trends en seizoensgebonden drukte.`;

    const result = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: 'object',
        properties: {
          nextMonth: { type: 'number', description: 'Verwachte omzet volgende maand' },
          month2: { type: 'number', description: 'Verwachte omzet maand 2' },
          month3: { type: 'number', description: 'Verwachte omzet maand 3' },
          seasonalPattern: { type: 'string', description: 'Seizoenspatroon beschrijving' },
          recommendations: { type: 'array', items: { type: 'string' }, description: 'Aanbevelingen' },
          warnings: { type: 'array', items: { type: 'string' }, description: 'Waarschuwingen' }
        }
      }
    });

    return Response.json({
      forecast: result,
      historicalData: {
        monthlyRevenue,
        monthlyCount
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});