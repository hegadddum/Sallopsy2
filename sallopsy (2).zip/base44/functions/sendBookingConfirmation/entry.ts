import { createClientFromRequest } from 'npm:@base44/sdk@0.8.31';

Deno.serve(async (req) => {
    try {
        const base44 = createClientFromRequest(req);
        const { appointment } = await req.json();

        if (!appointment || !appointment.client_email) {
            return Response.json({ success: false, reason: "No email provided" });
        }

        await base44.asServiceRole.integrations.Core.SendEmail({
            to: appointment.client_email,
            from_name: "Sallopsy",
            subject: `Bevestiging: Uw afspraak op ${appointment.date} om ${appointment.time}`,
            body: `Beste ${appointment.client_name},\n\nUw afspraak is bevestigd! Hieronder vindt u de details:\n\n✂️ Behandeling: ${appointment.service_name}\n📅 Datum: ${appointment.date}\n🕐 Tijd: ${appointment.time}\n⏱️ Duur: ${appointment.duration} minuten\n💰 Prijs: €${appointment.price || 0}\n\nWij kijken ernaar uit u te verwelkomen!\n\nMocht u vragen hebben of de afspraak willen wijzigen, neem dan contact met ons op.\n\nMet vriendelijke groet,\nHet team van Sallopsy\n\n---\nSallopsy – The Salon Operating System\nwww.sallopsy.nl`,
        });

        return Response.json({ success: true });
    } catch (error) {
        return Response.json({ error: error.message }, { status: 500 });
    }
});